# MJ Stack Tracker Phase 9 — Requirement Audit

Audit date: 2026-10-28

## Confirmed from the preceding project artifacts/screenshots

- Phase 0 build/install baseline was reported successful.
- Phase 1 recorded-video selection and playback was reported working.
- The Phase 3 screenshots confirm sequential indexed-frame progress, saved SQLite session history, playback speed controls, a local candidate-event list, and an overlay that follows saved video timestamps approximately.
- The same screenshots show serious false detections/background tracks and changing IDs; the detector is not yet reliable.
- The screenshots show the *old Phase 3 title* and do not show `MARK WORK AREA` or `LOCK INITIAL STACK`. Therefore those screenshots do not prove that Phase 3.1 ROI controls were installed.
- No screenshot or run output provided here proves millimetre calibration, exact piece counts, automatic 3D pose, or split/merge counts.

## Integrated candidate added in this package

- Phase 2/3.1 work-area rectangle, saved by video URI.
- Initial master-stack lock rectangle, saved by video URI with lock timestamp and default count 416 / thickness 0.33 mm. The first successfully decoded analysis frame is seeded from the user-marked box, so seeding does not depend on the contour detector rediscovering the same region.
- Master lineage root `MASTER-001`; child visual IDs `M01-Pxx`; possible split events remain pending review.
- Conservative inventory ledger and conservation invariant:

  `initial + added = visible + occluded + out-of-view + confirmed removed + unassigned`

- Separate line-calibration controls for table plane and stack side.
- Schematic 416-layer model; the tilt slider is manual, not an automatic pose estimate.
- Local review/search/event status controls and JSON/CSV export. Tapping an event now attempts to load its source video and seek to the saved event timestamp; valid URI access still depends on Android/provider permission.
- Unit tests for ledger transitions and basic math.
- A single Phase 9 build workflow to replace phase-by-phase uploads.

## Not yet proven / intentionally not claimed

- Successful compilation of this exact new package: Android SDK/Gradle are not present in this authoring environment. The GitHub Actions run must confirm it.
- Semantic recognition of a stack vs every unrelated bright region in the selected area.
- Persistent identity across arbitrary splits, severe occlusion, or visually identical moving components.
- Automatic exact per-child piece counts.
- Camera-intrinsics-calibrated 3D pose, accurate tilted length/height, or physically verified 0.1 mm-scale measurements.
- Ground-truth accuracy percentage.
- Exact presentation timestamps for every variable-frame-rate video.

## Test gate before calling this production-ready

1. Build succeeds, all JVM tests pass, and APK installs/opens on the Realme phone.
2. App title and controls identify the Phase 9 build, not Phase 3.
3. Initial full-stack selection succeeds and analysis starts from that locked timestamp.
4. Label at least five test clips with real component boxes/IDs/counts; compute false positives, false negatives, ID switches and count error.
5. Verify the ledger under known splits, merges, additions, removals, occlusion, out-of-view and return.
6. Validate calibration using physical measurements at multiple positions/depths and after object tilt.
7. Keep every unverified measurement labelled as a candidate/range and every ambiguous event pending review.
