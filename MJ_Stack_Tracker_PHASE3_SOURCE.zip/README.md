# MJ Stack Tracker — Phase 3

This is a phone-buildable Android Java source archive. Use the matching GitHub Actions workflow `build-phase3.yml` and keep the ZIP name `MJ_Stack_Tracker_PHASE3_SOURCE.zip` exactly as downloaded.

## Phase 3 delivers
- Local recorded-video selection and Media3 playback.
- 16:9 player, white UI, pause/seek.
- Slow review speeds: 0.25x, 0.5x, 0.75x and 1.0x.
- Offline OpenCV contour proposals and frame-to-frame candidate box association.
- Per-frame results saved in local SQLite, including timestamps, candidate boxes, confidence and pending candidate events.
- Continuous progress/history persistence and a timestamp-matched review overlay.

## Accuracy caveat
The current detector is deliberately an **experimental contour proposal detector**, not a trained stack detector. It may detect white table text, highlights or equipment; its percentage is **heuristic tracking confidence**, not measured accuracy. This phase must not be used to claim exact count, 3D measurements or correct split/merge recognition.

See `MJ_STACK_TRACKER_UPDATED_ROADMAP_AND_FORMULAS.md` for the full staged architecture and measurement equations.
