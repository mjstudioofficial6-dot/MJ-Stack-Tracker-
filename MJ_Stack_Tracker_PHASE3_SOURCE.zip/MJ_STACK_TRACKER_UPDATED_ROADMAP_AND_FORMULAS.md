# MJ Stack Tracker — Updated Roadmap, Geometry and Calculation Rules

## Objective
Offline Android app that processes a user-selected recorded video, tracks visually distinct piles through movement/occlusion/split/merge, models up to 416 conceptual layers, saves a persistent event/history ledger, and reports evidence-based estimates rather than unsupported exact counts.

## Data contract
- Inventory starts at 416 logical pieces (editable by the user).
- Nominal individual thickness defaults to 0.33 mm (editable; must be physically verified).
- Track identity, count estimate, physical geometry and visible/occluded state are separate fields.
- Each frame/result is keyed to media time. Saved history is local SQLite only.
- Confidence is not accuracy. True accuracy is computed only against labelled ground-truth frames/events.
- The ledger invariant is: initial total + confirmed additions = visible + occluded + out-of-view + unassigned/pending + confirmed removed.
- No permission to camera, no broad storage permission, no login, analytics, cloud AI, Firebase or runtime server.

## Formula catalogue and validity conditions

### 1) Image point to local table plane
For a calibrated planar surface, homogeneous points are related by a homography:

`lambda * [X, Y, 1]^T = H * [u, v, 1]^T`

where `(u,v)` are image pixels and `(X,Y)` are table-plane coordinates. Estimate `H` from at least four non-collinear corresponding points with known planar positions. This transform is valid for the plane used to calibrate it; it does not by itself recover the height of raised stacks.

### 2) Basic 2D scale on the same plane

`pixels_per_mm = pixel_distance / known_distance_mm`

`distance_mm = pixel_distance / pixels_per_mm`

Use the endpoints in the actual video-content coordinate system, not the whole phone-screen coordinate system. Scale is not valid after zoom/crop change, or across different depths when perspective is significant.

### 3) 3D camera projection

`P_camera = R * P_object + T`

`[u, v, 1]^T ~ K * [R | T] * [X, Y, Z, 1]^T`

`K` is the intrinsic camera matrix; `R,T` are pose. Solve pose only when known object points and their corresponding image points are available and calibration is sufficient. Reprojection residual must be saved as a geometry-quality signal.

### 4) Nominal stack height and count candidate

`H_nominal_mm = N * t_eff_mm`

`N_height = H_measured_mm / t_eff_mm`

For `N=416` and `t_eff=0.33 mm`, `H_nominal=137.28 mm`. This is a theoretical example until physical thickness and compression have been verified. Round to an exact integer only when the uncertainty supports that integer; otherwise save a range.

### 5) Uncertainty propagation for height count

For `N=H/t`, with independent standard uncertainties `sigma_H` and `sigma_t`:

`sigma_N = sqrt((sigma_H/t)^2 + (H*sigma_t/t^2)^2)`

A rough 95% interval is `N +/- 1.96*sigma_N`, clipped to valid count bounds. This approximation assumes the error model is reasonable and must be calibrated from actual test measurements.

### 6) Frame-to-frame bounding-box association

For two boxes A and B:

`IoU = area(A intersect B) / area(A union B)`

A candidate association can combine overlap and centre-distance:

`association = w_iou * IoU + w_dist * max(0, 1 - centre_distance / d_max)`

Weights and thresholds must be tuned on labelled video. A track gap is not proof of removal. Use hysteresis/multi-frame confirmation and preserve state as OCCLUDED or OUT_OF_VIEW when appropriate.

### 7) Layer projection for the 416-layer clone

Each virtual layer is defined in local stack coordinates with `z_i = i * t_eff`. Its 3D corners are transformed by the current stack pose and projected by `K`. Draw the resulting lines only as a model overlay. A virtual line does not prove that a corresponding physical seam is resolvable in the video.

### 8) Confidence vs measured accuracy

- Phase-3 displayed percentage is a heuristic confidence built from contour quality and temporal association. It is not a percent correctness claim.
- Measured accuracy must compare predictions against a manually labelled ground-truth set: exact-count accuracy, mean absolute count error, event precision/recall, tracking ID switches, missed events, false events per minute, processing time and memory/crashes.
- Keep an uncertainty range or PENDING_CONFIRMATION state when evidence is weak.

## Updated phases

### Phase 0 — Build/install proof: PASS
Simple APK built by GitHub Actions and installed on the phone. Preserve as immutable reference.

### Phase 1 — Video player and UI: PASS
Local video selection, 16:9 view, playback, pause, seek, clear, no camera/broad-storage permission. Preserve as immutable reference.

### Phase 2 — Initial calibration prototype: NOT VALIDATED
Old full-scene contour/edge detector selected overly large regions and did not perform mm calibration. Do not use it as ground truth. Keep only as an experimental artifact.

### Phase 3 — Frame analysis, tracking proposals, persistent history: BUILD NEXT
- Sequential indexed-frame scan where available; one bitmap/frame at a time.
- OpenCV contour proposals; temporal box association; track confidence.
- Slow-motion review speeds.
- SQLite frame/session/event records with progress saved continuously.
- Stop/resume-safe history semantics; timestamp-linked review overlay.
- Acceptance is data integrity + no crashes + overlay timestamp linkage, not stack-count accuracy.

### Phase 4 — Exact media timestamps + manual measurement calibration and table geometry
- Add a PTS-accurate decoder using MediaExtractor/MediaCodec so every tracked frame is tied to its actual media presentation timestamp; do not rely on proportional frame-index timestamps for variable-frame-rate footage.
- User marks at least four table-plane reference points and known planar dimensions.
- Compute/validate homography, pixels-per-mm, and reprojection/scale residual.
- Add two-endpoint reference calibration for same-plane distances; reject invalid/zero lengths.
- Explicit calibration invalidation after zoom/crop/perspective changes.
- Keep raised-stack dimensions separate from table-plane calibration.

### Phase 5 — Stack-specific detector and segmentation
- Label frames from representative input videos (stack top, side, base, hands, equipment, table text, occluded stacks).
- Train/validate a small on-device detector/segmenter and bundle model locally.
- Candidate detector gets tested against false positives from logos, table text, bright equipment and hands.
- Keep manual correction fallback for low confidence.

### Phase 6 — Optical-flow tracking and 3D pose
- Feature tracking between adjacent frames, periodic detector refresh, occlusion handling.
- Recover stack pose with calibrated camera/reference geometry where enough information exists.
- Project virtual 416-layer lines along the stack's own 3D axes; never force screen-vertical lines.

### Phase 7 — Count candidates and inventory/event ledger
- Estimate count from calibrated height, side-layer periodicity where genuinely resolved, temporal transfers and initial total.
- Track split/merge/add/remove/move as events with before/after states and conservation constraints.
- Exact count only if combined evidence uncertainty supports it; otherwise candidate range + PENDING_CONFIRMATION.

### Phase 8 — Ground-truth validation and robustness
- Test known stack counts and moves (1/5/10 units), split/merge, occlusion, out-of-view/re-entry, tilt, blur, low light, compression and zoom changes.
- Report exact-count accuracy, MAE, event precision/recall, ID switches, false events/minute, missed events, RAM, speed and crashes.
- No accuracy percentage is called verified until test metrics are available.

### Phase 9 — Release candidate
- Export/backup history, recover incomplete sessions, input validation, bounded RAM, performance tests, APK signing/version checks and offline verification.

## Phase 3 explicit limitations
Classical bright-contour proposals can find text or bright equipment and may fragment or merge piles. This build must not output exact count or claim true accuracy. The next acceptance decision must be based on real screenshots/logs and a labelled sample clip.
