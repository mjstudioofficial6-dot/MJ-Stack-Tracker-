MJ Stack Tracker — Phase 1 UI Fix (version 0.2.1)

Scope:
- Select one local video using the system picker.
- Play video with Media3 ExoPlayer.
- Player uses a landscape 16:9 viewport similar to YouTube on a portrait phone.
- The rest of the app surface is white, with dark/grey text and controls below the video.
- Status/navigation bar insets are handled to avoid the title overlapping the phone status bar.
- Use built-in play/pause/seek controls.
- Clear the selected video.
- No camera permission or broad storage permission.
- No OpenCV, AI, counting, database, OCR, or cloud runtime.

Acceptance test:
1. Build through GitHub Actions.
2. Install APK on Android phone.
3. Confirm the title does not overlap the status bar.
4. Confirm the video area is landscape 16:9 rather than filling most of the screen.
5. Tap Select Video and select a local video.
6. Video appears and plays; pause/play and seek work.
7. Clear returns to the empty state.
8. The area outside the video remains white.
9. Canceling the picker does not crash the app.
