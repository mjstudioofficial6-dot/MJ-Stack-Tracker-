package com.mj.stacktracker;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Insets;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.VideoSize;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.opencv.android.OpenCVLoader;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Phase 3: sequential frame analysis, heuristic contour proposals, local frame history,
 * confidence display, and timestamp-synced review overlay. No count is presented as exact.
 */
public final class MainActivity extends Activity {
    private static final int REQUEST_VIDEO = 1001;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private ExoPlayer player;
    private PlayerView playerView;
    private FrameOverlayView frameOverlay;
    private TextView statusText, progressText, historyText, recentEventsText, scaleText;
    private LinearLayout historyRows, eventRows;
    private LocalHistoryDb historyDb;
    private FrameDetector frameDetector;
    private TrackManager trackManager;
    private Uri selectedUri;
    private volatile long activeSessionId = -1;
    private volatile boolean analysisRunning;
    private final AtomicBoolean stopAnalysis = new AtomicBoolean(false);
    private Thread analysisThread;
    private int sourceWidth = 16, sourceHeight = 9;
    private long lastOverlayTimestamp = -1;
    private String speedLabel = "1.0x";
    private boolean openCvReady;

    private final Runnable overlayPoller = new Runnable() {
        @Override public void run() {
            try { updateOverlayForPlaybackPosition(); } catch (Exception ignored) { }
            mainHandler.postDelayed(this, 350L);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        historyDb = new LocalHistoryDb(this);
        historyDb.markIncompleteSessionsInterrupted();
        boolean cvLoaded;
        try { cvLoaded = OpenCVLoader.initLocal(); }
        catch (Throwable loadError) { cvLoaded = false; }
        openCvReady = cvLoaded;
        frameDetector = new FrameDetector();
        trackManager = new TrackManager();
        buildUi();
        refreshHistory();
        if (!openCvReady) {
            statusText.setText("OpenCV failed to load. Playback still works; analysis is unavailable.");
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.WHITE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        root.setPadding(dp(8), dp(2), dp(8), dp(8));

        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int top, bottom;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets bars=insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                top=bars.top; bottom=bars.bottom;
            } else { top=insets.getSystemWindowInsetTop(); bottom=insets.getSystemWindowInsetBottom(); }
            view.setPadding(dp(8), top+dp(2), dp(8), bottom+dp(8));
            return insets;
        });

        TextView title = new TextView(this);
        title.setText("MJ Stack Tracker — Phase 3");
        title.setTextSize(19); title.setTextColor(0xFF202124); title.setGravity(Gravity.CENTER);
        title.setPadding(dp(6),dp(7),dp(6),dp(7)); root.addView(title);

        int screenWidthPx=getResources().getDisplayMetrics().widthPixels;
        int videoHeightPx=Math.round(screenWidthPx*9f/16f);
        android.widget.FrameLayout videoLayer = new android.widget.FrameLayout(this);
        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerView.setBackgroundColor(Color.BLACK);
        videoLayer.addView(playerView,new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        frameOverlay = new FrameOverlayView(this);
        videoLayer.addView(frameOverlay,new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(videoLayer,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,videoHeightPx));

        LinearLayout row1 = row(root);
        addButton(row1,"SELECT VIDEO",()->openVideoPicker());
        addButton(row1,"ANALYZE FRAMES",()->startAnalysis());
        LinearLayout row2 = row(root);
        addButton(row2,"STOP ANALYSIS",()->stopAnalysis());
        addButton(row2,"CLEAR VIDEO",()->clearVideo());

        TextView speedHeading = label("Review speed — slower playback is supported"); root.addView(speedHeading);
        LinearLayout speedRow = row(root);
        addButton(speedRow,"0.25x",()->setSpeed(0.25f,"0.25x"));
        addButton(speedRow,"0.5x",()->setSpeed(0.5f,"0.5x"));
        addButton(speedRow,"0.75x",()->setSpeed(0.75f,"0.75x"));
        addButton(speedRow,"1.0x",()->setSpeed(1.0f,"1.0x"));

        statusText=label("Select a local recorded video. Analysis runs offline and saves each processed frame.");
        root.addView(statusText);
        progressText=label("Analysis: not started"); root.addView(progressText);
        scaleText=label("Physical scale: NOT CALIBRATED. No mm measurement or exact count is reported in Phase 3.");
        root.addView(scaleText);

        TextView confidenceNote=label("Confidence % is a heuristic image/tracking score, NOT measured accuracy. Ground-truth testing is required for true accuracy.");
        confidenceNote.setTextColor(0xFF8B3A00); root.addView(confidenceNote);

        historyText=label("Saved analysis history (local database)"); historyText.setTextSize(16); historyText.setTextColor(0xFF202124); root.addView(historyText);
        historyRows=new LinearLayout(this); historyRows.setOrientation(LinearLayout.VERTICAL); root.addView(historyRows);

        TextView eventHeading=label("Recent candidate events"); eventHeading.setTextSize(16); eventHeading.setTextColor(0xFF202124); root.addView(eventHeading);
        eventRows=new LinearLayout(this); eventRows.setOrientation(LinearLayout.VERTICAL); root.addView(eventRows);

        TextView details=label("Phase 3: every available indexed video frame is analyzed sequentially on Android 9+; older devices use timestamp samples. OpenCV contour proposals are experimental and may include false detections. Split/merge and verified piece counts are later phases.");
        details.setTextSize(12); details.setTextColor(0xFF5F6368); root.addView(details);

        scroll.addView(root);
        setContentView(scroll);

    }

    private LinearLayout row(LinearLayout parent) {
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER);
        r.setPadding(0,dp(2),0,dp(2)); parent.addView(r,new LinearLayout.LayoutParams(-1,-2)); return r;
    }

    private void addButton(LinearLayout row,String text,Runnable action) {
        Button b=new Button(this); b.setText(text); b.setTextSize(11); b.setAllCaps(false);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(46),1f); lp.setMargins(dp(2),0,dp(2),0); row.addView(b,lp);
        b.setOnClickListener(v->action.run());
    }

    private TextView label(String value) {
        TextView t=new TextView(this); t.setText(value); t.setTextColor(0xFF5F6368); t.setTextSize(13);
        t.setPadding(dp(8),dp(4),dp(8),dp(4)); return t;
    }

    private int dp(int value) { return Math.round(value*getResources().getDisplayMetrics().density); }

    private void openVideoPicker() {
        Intent intent;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent=new Intent(MediaStore.ACTION_PICK_IMAGES); intent.setType("video/*");
        } else {
            intent=new Intent(Intent.ACTION_OPEN_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("video/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        }
        try { startActivityForResult(intent,REQUEST_VIDEO); }
        catch(Exception e) { Toast.makeText(this,"Video picker unavailable.",Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=REQUEST_VIDEO || resultCode!=RESULT_OK || data==null) return;
        Uri uri=data.getData(); if(uri==null) { statusText.setText("No video selected."); return; }
        if(Build.VERSION.SDK_INT<Build.VERSION_CODES.TIRAMISU) {
            try { getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch(SecurityException ignored) { }
        }
        playVideo(uri);
    }

    private void playVideo(Uri uri) {
        if (analysisRunning) { Toast.makeText(this,"Stop the current analysis before switching video.",Toast.LENGTH_LONG).show(); return; }
        releasePlayer(); selectedUri=uri; frameOverlay.clearBoxes(); lastOverlayTimestamp=-1;
        player=new ExoPlayer.Builder(this).build();
        player.addListener(new androidx.media3.common.Player.Listener() {
            @Override public void onVideoSizeChanged(VideoSize videoSize) {
                if(videoSize.width>0 && videoSize.height>0) {
                    sourceWidth=videoSize.width; sourceHeight=videoSize.height;
                    frameOverlay.setSourceSize(sourceWidth,sourceHeight);
                }
            }
        });
        playerView.setPlayer(player); player.setMediaItem(MediaItem.fromUri(uri)); player.prepare();
        statusText.setText("Video loaded. Analyze Frames to create timestamped local history.");
        activeSessionId=historyDb.findLatestSessionForUri(uri.toString());
        scaleText.setText("Physical scale: NOT CALIBRATED. The current contour detector does not produce verified mm dimensions.");
    }

    private void setSpeed(float speed,String label) {
        speedLabel=label;
        if(player!=null) player.setPlaybackParameters(new PlaybackParameters(speed));
        statusText.setText("Review speed set to "+label+". Tracking results are matched by saved video timestamps.");
    }

    private void startAnalysis() {
        if(selectedUri==null) { Toast.makeText(this,"Select a recorded video first.",Toast.LENGTH_SHORT).show(); return; }
        if(!openCvReady) { Toast.makeText(this,"OpenCV did not initialize; build diagnostics are needed.",Toast.LENGTH_LONG).show(); return; }
        if(analysisRunning) { Toast.makeText(this,"Analysis is already running.",Toast.LENGTH_SHORT).show(); return; }
        stopAnalysis.set(false);
        String name=displayName(selectedUri);
        long sessionId=historyDb.createSession(selectedUri.toString(),name);
        activeSessionId=sessionId;
        analysisRunning=true;
        if(player!=null) player.pause();
        statusText.setText("Frame analysis started. Frames are processed sequentially; the phone may run slower than playback.");
        progressText.setText("Analysis: preparing decoder…");
        refreshHistory();
        final Uri uri=selectedUri;
        analysisThread=new Thread(()->runAnalysis(sessionId,uri),"MJ-frame-analysis");
        analysisThread.start();
    }

    private String displayName(Uri uri) {
        String s=uri.getLastPathSegment(); if(s==null || s.trim().isEmpty()) s=uri.toString();
        if(s.length()>60) s=s.substring(s.length()-60); return s;
    }

    private void stopAnalysis() {
        if(!analysisRunning) { statusText.setText("No analysis is running."); return; }
        stopAnalysis.set(true); statusText.setText("Stop requested. The last saved frame remains in history.");
    }

    private void runAnalysis(long sessionId,Uri uri) {
        MediaMetadataRetriever retriever=new MediaMetadataRetriever();
        int processed=0,total=0,width=0,height=0;
        long durationMs=0;
        double confidenceSum=0;
        String finalStatus="COMPLETED";
        String note="OpenCV contour proposals; ground-truth accuracy not measured.";
        TrackManager manager=new TrackManager();
        try {
            retriever.setDataSource(getApplicationContext(),uri);
            durationMs=parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION),0);
            width=(int)parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH),0);
            height=(int)parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT),0);
            int reportedFrames=(int)parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT),0);
            int fps=Math.max(1,(int)Math.round(parseDouble(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE),30.0)));
            boolean indexed=Build.VERSION.SDK_INT>=Build.VERSION_CODES.P && reportedFrames>0;
            total=indexed?reportedFrames:(int)Math.min(120000,Math.max(1,(durationMs*fps)/1000L));
            historyDb.updateMetadata(sessionId,durationMs,width,height,total,"RUNNING");
            final int frameTotal=total, vw=width, vh=height;
            mainHandler.post(()->{ sourceWidth=vw>0?vw:16; sourceHeight=vh>0?vh:9; frameOverlay.setSourceSize(sourceWidth,sourceHeight); scaleText.setText("Physical scale: NOT CALIBRATED. Reference dimensions and 3D pose are not yet verified."); });

            for(int frameIndex=0;frameIndex<total;frameIndex++) {
                if(stopAnalysis.get() || Thread.currentThread().isInterrupted()) { finalStatus="STOPPED"; break; }
                Bitmap frame=null;
                long timestampMs;
                try {
                    if(indexed) {
                        frame=retriever.getFrameAtIndex(frameIndex);
                        timestampMs=durationMs>0 && total>1 ? Math.round((frameIndex/(double)(total-1))*durationMs) : Math.round(frameIndex*1000.0/fps);
                    } else {
                        timestampMs=Math.min(durationMs,Math.round(frameIndex*1000.0/fps));
                        frame=retriever.getFrameAtTime(timestampMs*1000L,MediaMetadataRetriever.OPTION_CLOSEST);
                    }
                } catch(Exception frameError) {
                    frame=null; timestampMs=durationMs>0 && total>1?Math.round((frameIndex/(double)(total-1))*durationMs):Math.round(frameIndex*1000.0/fps);
                }

                List<DetectionCandidate> candidates=frame==null?new ArrayList<>():frameDetector.detect(frame);
                if(frame!=null && !frame.isRecycled()) frame.recycle();
                TrackManager.Update update=manager.update(candidates);
                JSONArray json=toJson(update.visible);
                String frameStatus=frame==null?"FRAME_DECODE_FAILED":(candidates.isEmpty()?"NO_CONFIDENT_CANDIDATE":"CANDIDATES_FOUND");
                historyDb.saveFrame(sessionId,frameIndex,timestampMs,update.visible.size(),update.frameConfidence,frameStatus,json);
                confidenceSum+=update.frameConfidence;
                for(TrackManager.Event event:update.events) {
                    historyDb.saveEvent(sessionId,timestampMs,event.type,event.trackId,event.confidence,"PENDING_REVIEW",event.details);
                }
                processed=frameIndex+1;
                if(processed%5==0 || processed==total) {
                    double avg=confidenceSum/processed;
                    String state=finalStatus.equals("STOPPED")?"STOPPED":"RUNNING";
                    historyDb.updateProgress(sessionId,processed,total,avg,state,note);
                    final int p=processed; final double conf=avg; final int t=total;
                    mainHandler.post(()->{
                        progressText.setText(String.format(Locale.US,"Analysis: %d / %d frames • heuristic tracking confidence %.0f%%",p,t,conf));
                        if (p % 25 == 0 || p == t) refreshHistory();
                    });
                }
            }
            if(stopAnalysis.get() && processed<total) finalStatus="STOPPED";
        } catch(Exception e) {
            finalStatus="ERROR"; note="Analysis error: "+e.getClass().getSimpleName()+" — "+String.valueOf(e.getMessage());
        } finally {
            try { retriever.release(); } catch(Exception ignored) { }
            double avg=processed>0?confidenceSum/processed:0;
            historyDb.updateProgress(sessionId,processed,total,avg,finalStatus,note);
            final int p=processed,t=total; final String fs=finalStatus, fn=note; final double conf=avg;
            mainHandler.post(()->{
                analysisRunning=false;
                statusText.setText(fs.equals("COMPLETED")?"Analysis complete. Review the saved tracking overlay at any video timestamp.":(fs.equals("STOPPED")?"Analysis stopped; all previously saved frames remain in history.":"Analysis did not complete: "+fn));
                progressText.setText(String.format(Locale.US,"Analysis: %d / %d frames • heuristic tracking confidence %.0f%% • %s",p,t,conf,fs));
                refreshHistory();
            });
        }
    }

    private JSONArray toJson(List<TrackManager.TrackedBox> boxes) {
        JSONArray arr=new JSONArray();
        for(TrackManager.TrackedBox b:boxes) {
            try { JSONObject o=new JSONObject(); o.put("id",b.id); o.put("left",b.left); o.put("top",b.top); o.put("right",b.right); o.put("bottom",b.bottom); o.put("confidence",b.confidence); o.put("matched",b.matchedFromPrevious); arr.put(o); }
            catch(Exception ignored) { }
        }
        return arr;
    }

    private void updateOverlayForPlaybackPosition() {
        if(player==null || activeSessionId<=0 || selectedUri==null) return;
        LocalHistoryDb.Observation obs=historyDb.getObservationAtOrBefore(activeSessionId,player.getCurrentPosition());
        if(obs==null || obs.timestampMs==lastOverlayTimestamp) return;
        lastOverlayTimestamp=obs.timestampMs;
        List<TrackManager.TrackedBox> boxes=new ArrayList<>();
        try {
            JSONArray arr=new JSONArray(obs.json);
            for(int i=0;i<arr.length();i++) {
                JSONObject o=arr.getJSONObject(i);
                boxes.add(new TrackManager.TrackedBox(
                        o.optString("id","S?"),(float)o.optDouble("left",0),(float)o.optDouble("top",0),
                        (float)o.optDouble("right",0),(float)o.optDouble("bottom",0),
                        (float)o.optDouble("confidence",0),o.optBoolean("matched",false)));
            }
        } catch(Exception ignored) { boxes.clear(); }
        frameOverlay.setBoxes(boxes,obs.timestampMs);
    }

    private void refreshHistory() {
        if(historyRows==null || historyDb==null) return;
        historyRows.removeAllViews();
        List<LocalHistoryDb.SessionSummary> sessions=historyDb.getRecentSessions(8);
        if(sessions.isEmpty()) {
            historyRows.addView(label("No analysis history yet. Start Analyze Frames to begin persistent local saving."));
        }
        DateFormat format=DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT,Locale.getDefault());
        for(LocalHistoryDb.SessionSummary s:sessions) {
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setBackgroundColor(0xFFF3F5F7); card.setPadding(dp(8),dp(6),dp(8),dp(6));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,dp(3),0,dp(3)); historyRows.addView(card,cp);
            TextView n=label(s.name); n.setTextColor(0xFF202124); n.setTextSize(13); card.addView(n);
            TextView meta=label(format.format(new Date(s.createdAt))+" • "+s.status+" • "+s.processed+" / "+s.total+" frames"); card.addView(meta);
            TextView conf=label(String.format(Locale.US,"Tracking confidence: %.0f%% (heuristic; not verified accuracy)",s.confidence)); conf.setTextColor(s.confidence>=65?0xFF137333:(s.confidence>=40?0xFF9A6700:0xFFB3261E)); card.addView(conf);
            if(s.note!=null && !s.note.isEmpty()) { TextView note=label(s.note); note.setTextSize(11); card.addView(note); }
            Button review=new Button(this); review.setText("Review this video / history"); review.setTextSize(11); review.setOnClickListener(v->{
                String sessionUri = historyDb.getSessionUri(s.id);
                if(selectedUri==null || sessionUri==null || !sessionUri.equals(selectedUri.toString())) {
                    Toast.makeText(this,"Select the original source video to review its saved overlay.",Toast.LENGTH_LONG).show();
                } else { activeSessionId=s.id; lastOverlayTimestamp=-1; frameOverlay.clearBoxes(); player.seekTo(0); }
            }); card.addView(review);
        }
        if(eventRows!=null) {
            eventRows.removeAllViews(); List<LocalHistoryDb.EventSummary> events=historyDb.getRecentEvents(10);
            if(events.isEmpty()) eventRows.addView(label("No candidate events saved yet."));
            for(LocalHistoryDb.EventSummary e:events) {
                TextView item=label(String.format(Locale.US,"%s • %s • %s • confidence %.0f%% • %s",e.sourceName,e.type,e.trackId,e.confidence,e.status));
                eventRows.addView(item);
            }
        }
    }

    private void clearVideo() {
        if(analysisRunning) { Toast.makeText(this,"Stop analysis before clearing the video.",Toast.LENGTH_LONG).show(); return; }
        releasePlayer(); selectedUri=null; activeSessionId=-1; frameOverlay.clearBoxes(); statusText.setText("No video selected."); progressText.setText("Analysis: not started");
    }

    private long parseLong(String s,long fallback) { try{return s==null?fallback:Long.parseLong(s);}catch(Exception e){return fallback;} }
    private double parseDouble(String s,double fallback) { try{return s==null?fallback:Double.parseDouble(s);}catch(Exception e){return fallback;} }

    @Override protected void onResume() { super.onResume(); mainHandler.post(overlayPoller); }
    @Override protected void onPause() { mainHandler.removeCallbacks(overlayPoller); super.onPause(); }
    @Override protected void onStop() { super.onStop(); if(player!=null) player.pause(); }
    @Override protected void onDestroy() {
        mainHandler.removeCallbacks(overlayPoller);
        if(analysisRunning) stopAnalysis.set(true);
        releasePlayer();
        // Do not close SQLite while the background analysis thread may still
        // be saving its final frame. The helper is app-local and releases with
        // the Activity after the worker finishes.
        super.onDestroy();
    }

    private void releasePlayer() { if(player!=null) { player.release(); player=null; } }
}
