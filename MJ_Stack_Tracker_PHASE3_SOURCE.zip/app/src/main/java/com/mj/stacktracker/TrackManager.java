package com.mj.stacktracker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Greedy frame-to-frame association for candidate boxes; not semantic identity proof. */
public final class TrackManager {
    public static final class TrackedBox {
        public final String id;
        public final float left, top, right, bottom, confidence;
        public final boolean matchedFromPrevious;
        TrackedBox(String id, float l, float t, float r, float b, float c, boolean matched) {
            this.id=id; left=l; top=t; right=r; bottom=b; confidence=c; matchedFromPrevious=matched;
        }
    }
    public static final class Event {
        public final String type;
        public final String trackId;
        public final float confidence;
        public final String details;
        Event(String t, String id, float c, String d) { type=t; trackId=id; confidence=c; details=d; }
    }
    public static final class Update {
        public final List<TrackedBox> visible;
        public final List<Event> events;
        public final float frameConfidence;
        Update(List<TrackedBox> boxes, List<Event> events, float confidence) {
            visible=boxes; this.events=events; frameConfidence=confidence;
        }
    }
    private static final int MAX_MISSED_FRAMES = 8;
    private final List<Track> tracks = new ArrayList<>();
    private int nextId = 1;

    public Update update(List<DetectionCandidate> detections) {
        List<Event> events = new ArrayList<>();
        boolean[] usedTrack = new boolean[tracks.size()];
        List<TrackedBox> visible = new ArrayList<>();
        int matchedCount = 0;

        List<DetectionCandidate> ordered = new ArrayList<>(detections);
        ordered.sort(Comparator.comparingDouble((DetectionCandidate c) -> c.detectorScore).reversed());

        for (DetectionCandidate d : ordered) {
            int bestIndex = -1;
            float bestScore = 0f;
            for (int i = 0; i < tracks.size(); i++) {
                if (usedTrack[i]) continue;
                Track tr = tracks.get(i);
                if (tr.missed > MAX_MISSED_FRAMES) continue;
                float score = associationScore(d, tr);
                if (score > bestScore) { bestScore = score; bestIndex = i; }
            }

            Track chosen;
            boolean matched = bestIndex >= 0 && bestScore >= 0.22f;
            if (matched) {
                usedTrack[bestIndex] = true;
                chosen = tracks.get(bestIndex);
                matchedCount++;
                // Smooth jitter, but retain enough new position to follow real motion.
                chosen.left = 0.62f * chosen.left + 0.38f * d.left;
                chosen.top = 0.62f * chosen.top + 0.38f * d.top;
                chosen.right = 0.62f * chosen.right + 0.38f * d.right;
                chosen.bottom = 0.62f * chosen.bottom + 0.38f * d.bottom;
                chosen.confidence = clamp(0.65f * d.detectorScore + 0.35f * bestScore * 100f);
                chosen.missed = 0;
            } else {
                chosen = new Track();
                chosen.id = String.format(java.util.Locale.US, "S%02d", nextId++);
                chosen.left=d.left; chosen.top=d.top; chosen.right=d.right; chosen.bottom=d.bottom;
                chosen.confidence=clamp(d.detectorScore * 0.72f);
                chosen.missed=0;
                tracks.add(chosen);
                // A new visual candidate is not automatically a new physical pile.
                events.add(new Event("NEW_CANDIDATE", chosen.id, chosen.confidence,
                        "Unconfirmed bright-contour candidate; review before treating as a stack."));
                usedTrack = java.util.Arrays.copyOf(usedTrack, tracks.size());
                usedTrack[tracks.size()-1] = true;
            }
            visible.add(new TrackedBox(chosen.id, chosen.left, chosen.top,
                    chosen.right, chosen.bottom, chosen.confidence, matched));
        }

        // Age unmatched tracks; short gaps are retained as possible occlusions.
        for (int i = 0; i < tracks.size(); i++) {
            Track tr = tracks.get(i);
            if (i >= usedTrack.length || !usedTrack[i]) {
                tr.missed++;
                if (tr.missed == MAX_MISSED_FRAMES + 1) {
                    events.add(new Event("TRACK_NOT_VISIBLE", tr.id, tr.confidence,
                            "Candidate absent for multiple frames; may be occluded or out of view, not confirmed removed."));
                }
            }
        }
        for (int i = tracks.size() - 1; i >= 0; i--) {
            if (tracks.get(i).missed > MAX_MISSED_FRAMES + 20) tracks.remove(i);
        }

        float average = 0f;
        for (TrackedBox b : visible) average += b.confidence;
        average = visible.isEmpty() ? 0f : average / visible.size();
        float continuity = detections.isEmpty() ? 0f : (float) matchedCount / detections.size();
        // This is a heuristic confidence score, not empirical accuracy.
        float frameConfidence = visible.isEmpty() ? 0f : clamp(average * (0.78f + 0.22f * continuity));
        return new Update(Collections.unmodifiableList(visible), events, frameConfidence);
    }

    public void reset() { tracks.clear(); nextId=1; }

    private float associationScore(DetectionCandidate d, Track t) {
        float iou = iou(d.left,d.top,d.right,d.bottom,t.left,t.top,t.right,t.bottom);
        float dx = d.centerX() - (t.left+t.right)*0.5f;
        float dy = d.centerY() - (t.top+t.bottom)*0.5f;
        float distance = (float)Math.sqrt(dx*dx + dy*dy);
        float distanceScore = Math.max(0f, 1f - distance / 0.20f);
        // Either overlap or plausible nearby movement can support association.
        return 0.62f * iou + 0.38f * distanceScore;
    }

    private float iou(float al,float at,float ar,float ab,float bl,float bt,float br,float bb) {
        float l=Math.max(al,bl), t=Math.max(at,bt), r=Math.min(ar,br), b=Math.min(ab,bb);
        float inter=Math.max(0f,r-l)*Math.max(0f,b-t);
        float aa=Math.max(0f,ar-al)*Math.max(0f,ab-at);
        float ba=Math.max(0f,br-bl)*Math.max(0f,bb-bt);
        float union=aa+ba-inter;
        return union<=0f?0f:inter/union;
    }
    private float clamp(float x) { return Math.max(0f,Math.min(100f,x)); }

    private static final class Track {
        String id; float left,top,right,bottom,confidence; int missed;
    }
}
