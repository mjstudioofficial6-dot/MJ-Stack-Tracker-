package com.mj.stacktracker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** Transparent timestamp-synced overlay. Boxes are normalized to source-frame dimensions. */
public final class FrameOverlayView extends View {
    private final Paint boxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<TrackManager.TrackedBox> boxes = new ArrayList<>();
    private int sourceWidth = 16;
    private int sourceHeight = 9;
    private long sourceTimestampMs = -1;

    public FrameOverlayView(Context context) {
        super(context);
        setWillNotDraw(false);
        setClickable(false);
        setFocusable(false);
        boxPaint.setStyle(Paint.Style.STROKE);
        boxPaint.setStrokeWidth(dp(2));
        boxPaint.setColor(0xFFFF3D36);
        textPaint.setColor(0xFFFFFFFF);
        textPaint.setTextSize(dp(11));
        textPaint.setFakeBoldText(true);
        bgPaint.setColor(0xBB202124);
        bgPaint.setStyle(Paint.Style.FILL);
    }

    public void setSourceSize(int width, int height) {
        if (width > 0 && height > 0) { sourceWidth=width; sourceHeight=height; invalidate(); }
    }

    public void setBoxes(List<TrackManager.TrackedBox> newBoxes, long timestampMs) {
        boxes.clear();
        if (newBoxes != null) boxes.addAll(newBoxes);
        sourceTimestampMs = timestampMs;
        invalidate();
    }

    public void clearBoxes() { boxes.clear(); sourceTimestampMs=-1; invalidate(); }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float scale=Math.min(getWidth()/(float)Math.max(1,sourceWidth), getHeight()/(float)Math.max(1,sourceHeight));
        float drawnW=sourceWidth*scale, drawnH=sourceHeight*scale;
        float ox=(getWidth()-drawnW)*0.5f, oy=(getHeight()-drawnH)*0.5f;
        for (TrackManager.TrackedBox b : boxes) {
            float l=ox+b.left*drawnW, t=oy+b.top*drawnH, r=ox+b.right*drawnW, bt=oy+b.bottom*drawnH;
            boxPaint.setColor(b.confidence >= 65f ? 0xFF21A366 : (b.confidence >= 40f ? 0xFFFFB300 : 0xFFE53935));
            canvas.drawRect(new RectF(l,t,r,bt),boxPaint);
            String label=b.id+" "+Math.round(b.confidence)+"%";
            float tw=textPaint.measureText(label);
            float labelY=Math.max(oy+dp(14),t-dp(3));
            canvas.drawRect(l,labelY-dp(13),l+tw+dp(8),labelY+dp(3),bgPaint);
            canvas.drawText(label,l+dp(4),labelY,textPaint);
        }
        if (sourceTimestampMs >= 0 && !boxes.isEmpty()) {
            String info="tracking overlay  •  "+(sourceTimestampMs/1000.0)+" s";
            float w=textPaint.measureText(info)+dp(12);
            canvas.drawRect(dp(6),dp(6),dp(6)+w,dp(27),bgPaint);
            canvas.drawText(info,dp(12),dp(21),textPaint);
        }
    }
    private int dp(int value) { return Math.round(value*getResources().getDisplayMetrics().density); }
}
