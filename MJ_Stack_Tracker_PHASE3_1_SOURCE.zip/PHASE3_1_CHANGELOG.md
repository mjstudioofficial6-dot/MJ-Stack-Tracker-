# Phase 3.1 changelog

- Added a draggable, per-video user-marked work-area rectangle (ROI).
- Restricts contour detection to ROI, reducing unrelated background candidates when area selection is correct.
- Maps crop detections back to normalized full-frame coordinates for overlay/history synchronization.
- Tightens contour thresholds, reduces the maximum candidate count, and suppresses overlapping proposals.
- Requires temporal persistence before a candidate becomes a visible track ID.
- Tightens track association using overlap, displacement and box-size similarity.
- Improves saved-history review by trying to reopen the stored source URI and providing a fallback message if access has expired.
- Keeps heuristic confidence clearly separate from measured accuracy.
