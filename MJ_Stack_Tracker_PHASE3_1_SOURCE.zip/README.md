# MJ Stack Tracker — Phase 3.1

This source archive is the next correction build after the Phase 3 screenshots. Use the matching workflow `build-phase3-1.yml` and keep the ZIP filename exactly `MJ_Stack_Tracker_PHASE3_1_SOURCE.zip` at the repository root.

## Phase 3.1 changes
- Mark a work area by dragging a rectangle over the video; the selected area is saved locally for that video URI.
- OpenCV analyzes only the marked area and maps detections to full-frame coordinates.
- Fewer contour candidates, overlap suppression, and persistence-gated visible tracking IDs.
- Tighter frame-to-frame tracking association.
- History review tries to reopen the saved source URI and explains when access has expired.
- Offline runtime; no camera, Firebase, login, runtime AI API, or video upload.

## Use
1. Upload `MJ_Stack_Tracker_PHASE3_1_SOURCE.zip` to the repository root.
2. Upload `build-phase3-1.yml` into `.github/workflows/build-phase3-1.yml`.
3. Run **Build MJ Stack Tracker Phase 3.1** from GitHub Actions.
4. Download artifact `MJ-Stack-Tracker-Phase3.1-debug-apk` and install `app-debug.apk`.
5. Select a recorded video, press **MARK WORK AREA**, and drag around only the table/region where target stacks can move. Exclude the clock, decorations and unrelated objects.
6. Press **ANALYZE FRAMES**. Review several timestamps.

## Limits
This is still an OpenCV contour proposal detector, not a trained semantic stack detector. False detections may remain inside the selected region. Displayed percentages are heuristic confidence, not measured accuracy. This version does not claim calibrated millimetres, exact piece count, verified 3D pose, split/merge accounting, or physical resolution of all 416 layers.

See `PHASE3_1_README.txt` and `MJ_STACK_TRACKER_UPDATED_ROADMAP_AND_FORMULAS.md` for more details.
