MJ STACK TRACKER — PHASE 3.1
Detection/Tracking Correction Build

PURPOSE
This phase fixes the main issues seen in Phase 3 screenshots: background regions were being detected as stacks, many new IDs appeared, and the app analyzed the full image instead of the actual work area.

WHAT CHANGED
1. MARK WORK AREA: after choosing a recorded video, drag a rectangle on the video around the full table/region in which the target stacks can move. Leave clock, decorations and unrelated items outside the rectangle.
2. The rectangle is saved locally for that video URI and appears as a blue outline. RESET AREA clears it.
3. The OpenCV contour detector analyzes only pixels inside the marked area and maps candidate boxes back into the full video coordinate system.
4. Detection is limited to fewer candidates and overlapping proposals are suppressed.
5. A candidate must persist across processed frames before it appears as a confirmed visual tracking ID. This removes some one-frame flicker/noise. It does not prove semantic identity.
6. Track association uses tighter movement/shape gates, so nearby detections are less likely to steal an ID.
7. Review History attempts to reopen its saved source video URI and reports when access has expired.
8. Runtime remains offline. No camera permission, cloud AI, login, Firebase or video upload is added.

HOW TO TEST ON PHONE
1. Upload this ZIP to the repository root using the exact filename MJ_Stack_Tracker_PHASE3_1_SOURCE.zip.
2. Upload build-phase3-1.yml into .github/workflows/build-phase3-1.yml.
3. Open GitHub Actions → Build MJ Stack Tracker Phase 3.1 → Run workflow.
4. Wait for the workflow to finish, then download the artifact named MJ-Stack-Tracker-Phase3.1-debug-apk and install app-debug.apk.
5. Open the app and select the same recorded video used in Phase 3.
6. Tap MARK WORK AREA, then drag a rectangle inside the video around the table area where stacks actually move. Do not include the clock/decorations/background objects. Make the rectangle large enough to include all expected stack movement.
7. Tap ANALYZE FRAMES. Let the video finish. Review multiple timestamps, including when stacks move or split.
8. Compare against the previous screenshots: background boxes should be reduced if the work area excludes them; one-frame detections should be filtered; some IDs should stay stable during small motion.
9. If the ROI excludes any target stack, press RESET AREA and draw a larger/better rectangle.

IMPORTANT LIMITS
- This is still a classical OpenCV contour-proposal detector, not a trained stack-recognition model. A white object inside the chosen region may still be falsely detected.
- The percentage is a heuristic score, not measured accuracy.
- No calibrated millimetres, exact piece count, 3D pose, split/merge ledger or 416-layer physical measurement is claimed in this phase.
- Real build success must be confirmed by the GitHub Actions result. This source package is statically checked here, but Android compilation has not been run in this container.
