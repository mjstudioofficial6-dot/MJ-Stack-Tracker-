package com.mj.stacktracker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** Timestamp-synced boxes and user-defined work-area selection over the video. */
public final class FrameOverlayView extends View {
    public interface OnWorkAreaSelectedListener {
        void onWorkAreaSelected(float left, float top, float right, float bottom);
    }

    private final Paint boxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint roiPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint selectionPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<TrackManager.TrackedBox> boxes = new ArrayList<>();
    private int sourceWidth = 16;
    private int sourceHeight = 9;
    private long sourceTimestampMs = -1;
    private boolean hasWorkArea;
    private float roiLeft, roiTop, roiRight, roiBottom;
    private boolean selectionMode;
    private boolean dragging;
    private float dragLeft, dragTop, dragRight, dragBottom;
    private OnWorkAreaSelectedListener workAreaListener;

    public FrameOverlayView(Context context) {
        super(context);
        setWillNotDraw(false);
        setClickable(false);
        setFocusable(false);
        boxPaint.setStyle(Paint.Style.STROKE);
        boxPaint.setStrokeWidth(dp(2));
        boxPaint.setColor(0xFF21A366);
        textPaint.setColor(0xFFFFFFFF);
        textPaint.setTextSize(dp(11));
        textPaint.setFakeBoldText(true);
        bgPaint.setColor(0xBB202124);
        bgPaint.setStyle(Paint.Style.FILL);
        roiPaint.setStyle(Paint.Style.STROKE);
        roiPaint.setStrokeWidth(dp(2));
        roiPaint.setColor(0xFF00A6D6);
        selectionPaint.setStyle(Paint.Style.STROKE);
        selectionPaint.setStrokeWidth(dp(3));
        selectionPaint.setColor(0xFFFFC107);
    }

    public void setOnWorkAreaSelectedListener(OnWorkAreaSelectedListener listener) {
        workAreaListener = listener;
    }

    public void setSourceSize(int width, int height) {
        if (width > 0 && height > 0) { sourceWidth=width; sourceHeight=height; invalidate(); }
    }

    public void setBoxes(List<TrackManager.TrackedBox> newBoxes, long timestampMs) {
        boxes.clear();
        if (newBoxes != null) boxes.addAll(newBoxes);
        sourceTimestampMs = timestampMs;
        invalidate();
    }

    public void clearBoxes() { boxes.clear(); sourceTimestampMs=-1; invalidate(); }

    public void setWorkArea(float left, float top, float right, float bottom) {
        roiLeft=clamp(Math.min(left,right)); roiTop=clamp(Math.min(top,bottom));
        roiRight=clamp(Math.max(left,right)); roiBottom=clamp(Math.max(top,bottom));
        hasWorkArea=(roiRight-roiLeft)>=0.04f && (roiBottom-roiTop)>=0.04f;
        invalidate();
    }

    public void clearWorkArea() {
        hasWorkArea=false; selectionMode=false; dragging=false; setClickable(false); setFocusable(false); invalidate();
    }

    public boolean hasWorkArea() { return hasWorkArea; }

    public void setSelectionMode(boolean enabled) {
        selectionMode=enabled; dragging=false; setClickable(enabled); setFocusable(enabled); invalidate();
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (!selectionMode) return false;
        float[] p=toNormalized(event.getX(),event.getY(),event.getActionMasked()==MotionEvent.ACTION_DOWN);
        switch(event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (p==null) return false;
                dragLeft=dragRight=p[0]; dragTop=dragBottom=p[1]; dragging=true; invalidate(); return true;
            case MotionEvent.ACTION_MOVE:
                if (!dragging) return false;
                if (p!=null) { dragRight=p[0]; dragBottom=p[1]; invalidate(); }
                return true;
            case MotionEvent.ACTION_UP:
                if (!dragging) return false;
                if (p!=null) { dragRight=p[0]; dragBottom=p[1]; }
                dragging=false;
                float l=Math.min(dragLeft,dragRight), t=Math.min(dragTop,dragBottom);
                float r=Math.max(dragLeft,dragRight), b=Math.max(dragTop,dragBottom);
                if ((r-l)>=0.04f && (b-t)>=0.04f) {
                    setWorkArea(l,t,r,b);
                    setSelectionMode(false);
                    if (workAreaListener!=null) workAreaListener.onWorkAreaSelected(roiLeft,roiTop,roiRight,roiBottom);
                }
                invalidate(); return true;
            case MotionEvent.ACTION_CANCEL:
                dragging=false; invalidate(); return true;
            default: return true;
        }
    }

    private float[] toNormalized(float x,float y,boolean rejectOutside) {
        float scale=Math.min(getWidth()/(float)Math.max(1,sourceWidth),getHeight()/(float)Math.max(1,sourceHeight));
        float drawnW=sourceWidth*scale,drawnH=sourceHeight*scale;
        float ox=(getWidth()-drawnW)*0.5f,oy=(getHeight()-drawnH)*0.5f;
        if(rejectOutside && (x<ox || x>ox+drawnW || y<oy || y>oy+drawnH)) return null;
        return new float[]{clamp((x-ox)/Math.max(1f,drawnW)),clamp((y-oy)/Math.max(1f,drawnH))};
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float scale=Math.min(getWidth()/(float)Math.max(1,sourceWidth), getHeight()/(float)Math.max(1,sourceHeight));
        float drawnW=sourceWidth*scale, drawnH=sourceHeight*scale;
        float ox=(getWidth()-drawnW)*0.5f, oy=(getHeight()-drawnH)*0.5f;

        for (TrackManager.TrackedBox b : boxes) {
            float l=ox+b.left*drawnW, t=oy+b.top*drawnH, r=ox+b.right*drawnW, bt=oy+b.bottom*drawnH;
            boxPaint.setColor(b.confidence >= 65f ? 0xFF21A366 : (b.confidence >= 40f ? 0xFFFFB300 : 0xFFE53935));
            canvas.drawRect(new RectF(l,t,r,bt),boxPaint);
            String label=b.id+" "+Math.round(b.confidence)+"%";
            float tw=textPaint.measureText(label);
            float labelY=Math.max(oy+dp(14),t-dp(3));
            canvas.drawRect(l,labelY-dp(13),l+tw+dp(8),labelY+dp(3),bgPaint);
            canvas.drawText(label,l+dp(4),labelY,textPaint);
        }

        if(hasWorkArea) {
            roiPaint.setColor(selectionMode?0xFFFFC107:0xFF00A6D6);
            canvas.drawRect(new RectF(ox+roiLeft*drawnW,oy+roiTop*drawnH,
                    ox+roiRight*drawnW,oy+roiBottom*drawnH),roiPaint);
            String areaLabel="WORK AREA";
            float tw=textPaint.measureText(areaLabel);
            float lx=ox+roiLeft*drawnW, ly=Math.max(oy+dp(16),oy+roiTop*drawnH-dp(4));
            canvas.drawRect(lx,ly-dp(13),lx+tw+dp(8),ly+dp(3),bgPaint);
            canvas.drawText(areaLabel,lx+dp(4),ly,textPaint);
        }
        if(selectionMode && dragging) {
            float l=Math.min(dragLeft,dragRight),t=Math.min(dragTop,dragBottom);
            float r=Math.max(dragLeft,dragRight),b=Math.max(dragTop,dragBottom);
            canvas.drawRect(new RectF(ox+l*drawnW,oy+t*drawnH,ox+r*drawnW,oy+b*drawnH),selectionPaint);
        }
        if (sourceTimestampMs >= 0 && !boxes.isEmpty()) {
            String info="tracking overlay  •  "+String.format(java.util.Locale.US,"%.3f",sourceTimestampMs/1000.0)+" s";
            float w=textPaint.measureText(info)+dp(12);
            canvas.drawRect(dp(6),dp(6),dp(6)+w,dp(27),bgPaint);
            canvas.drawText(info,dp(12),dp(21),textPaint);
        }
    }

    private float clamp(float value) { return Math.max(0f,Math.min(1f,value)); }
    private int dp(int value) { return Math.round(value*getResources().getDisplayMetrics().density); }
}
