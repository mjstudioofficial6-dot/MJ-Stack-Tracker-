package com.mj.stacktracker;

import org.junit.Test;
import static org.junit.Assert.*;

public class MetricMathTest {
    @Test public void nominalHeightFor416PiecesIs137Point28Mm() {
        assertEquals(137.28, 416 * 0.33, 0.00001);
        assertEquals(416.0, MetricMath.countCandidate(137.28, 0.33), 0.00001);
    }

    @Test public void invalidScaleIsRejected() {
        assertTrue(Double.isNaN(MetricMath.pixelsPerMm(100, 0)));
        assertTrue(Double.isNaN(MetricMath.pixelsToMm(10, 0)));
    }
}
