package com.mj.stacktracker;

import org.junit.Test;
import static org.junit.Assert.*;

public class StackLedgerTest {
    @Test public void initial416IsBalanced() {
        StackLedger ledger = new StackLedger(416);
        assertEquals(416, ledger.getExpectedTotal());
        assertEquals(416, ledger.getVisibleCount());
        assertTrue(ledger.isConserved());
    }

    @Test public void splitDoesNotInventOrLosePieces() {
        StackLedger ledger = new StackLedger(416);
        assertTrue(ledger.registerSplit(416, new int[]{200, 216}));
        assertEquals(416, ledger.getVisibleCount());
        assertTrue(ledger.isConserved());
    }

    @Test public void unknownSplitMovesPiecesToUnassignedAndCanBeAllocated() {
        StackLedger ledger = new StackLedger(416);
        assertTrue(ledger.registerSplit(30, null));
        assertEquals(386, ledger.getVisibleCount());
        assertEquals(30, ledger.getUnassignedCount());
        assertTrue(ledger.isConserved());
        assertTrue(ledger.allocateUnassigned(new int[]{12, 18}));
        assertEquals(416, ledger.getVisibleCount());
        assertEquals(0, ledger.getUnassignedCount());
        assertTrue(ledger.isConserved());
    }

    @Test public void movementBucketsConserveTotal() {
        StackLedger ledger = new StackLedger(416);
        assertTrue(ledger.markOccluded(20));
        assertTrue(ledger.returnFromOcclusion(5));
        assertTrue(ledger.markOutOfView(10));
        assertTrue(ledger.returnFromOutOfView(10));
        assertTrue(ledger.confirmRemoved(3));
        assertTrue(ledger.addPieces(2));
        assertEquals(418, ledger.getExpectedTotal());
        assertEquals(418, ledger.getAccountedTotal());
        assertTrue(ledger.isConserved());
    }

    @Test public void undoRestoresLastLedgerState() {
        StackLedger ledger = new StackLedger(416);
        assertTrue(ledger.confirmRemoved(10));
        assertEquals(406, ledger.getVisibleCount());
        assertTrue(ledger.undoLastLedgerChange());
        assertEquals(416, ledger.getVisibleCount());
        assertEquals(0, ledger.getRemovedCount());
        assertTrue(ledger.isConserved());
    }

    @Test public void badSplitCannotChangeLedger() {
        StackLedger ledger = new StackLedger(416);
        assertFalse(ledger.registerSplit(100, new int[]{40, 59}));
        assertEquals(416, ledger.getVisibleCount());
        assertTrue(ledger.isConserved());
    }
}
