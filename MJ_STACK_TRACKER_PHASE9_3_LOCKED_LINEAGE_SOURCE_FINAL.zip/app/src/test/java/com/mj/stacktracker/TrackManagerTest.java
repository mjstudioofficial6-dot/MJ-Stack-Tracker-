package com.mj.stacktracker;

import org.junit.Test;

import java.util.Collections;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

/** Regression tests for locked-object lineage and false-pile rejection. */
public class TrackManagerTest {
    private static final float[] MASTER = new float[]{0.20f, 0.20f, 0.60f, 0.60f};
    private static DetectionCandidate root() { return new DetectionCandidate(0.20f,0.20f,0.60f,0.60f,99f); }
    private static DetectionCandidate child(float l) { return new DetectionCandidate(l,0.35f,l+0.15f,0.45f,95f); }

    @Test public void unrelatedContourDoesNotCreatePileAndStaleLockBoxIsHidden() {
        TrackManager manager = new TrackManager(true);
        manager.seedMaster(MASTER);
        TrackManager.Update update = manager.update(Collections.singletonList(
                new DetectionCandidate(0.82f, 0.80f, 0.93f, 0.90f, 95f)));
        assertTrue(update.events.isEmpty());
        assertNull(findBox(update, "PILE-01")); // No detection: don't draw a stale locked rectangle.
        assertNull(findBox(update, "PILE-02"));
    }

    @Test public void contourFullyInsideLockedObjectIsNotAChildPile() {
        TrackManager manager = new TrackManager(true);
        manager.seedMaster(MASTER);
        DetectionCandidate inner = new DetectionCandidate(0.36f, 0.30f, 0.49f, 0.40f, 98f);
        for (int i=0; i<8; i++) {
            TrackManager.Update update = manager.update(Arrays.asList(root(), inner));
            assertFalse(containsEvent(update, "CANDIDATE_CONFIRMED", "PILE-02"));
            assertEquals(1, update.visible.size());
            assertEquals("PILE-01", update.visible.get(0).id);
        }
    }

    @Test public void edgeContourThatNeverSeparatesDoesNotBecomePile() {
        TrackManager manager = new TrackManager(true);
        manager.seedMaster(MASTER);
        DetectionCandidate stationary = child(0.55f);
        for (int i=0; i<8; i++) {
            TrackManager.Update update = manager.update(Arrays.asList(root(), stationary));
            assertFalse(containsEvent(update, "CANDIDATE_CONFIRMED", "PILE-02"));
            assertEquals(1, update.visible.size());
        }
    }

    @Test public void childMustTouchLockedObjectThenMoveAwayAndPersist() {
        TrackManager manager = new TrackManager(true);
        manager.seedMaster(MASTER);

        TrackManager.Update first = manager.update(Arrays.asList(root(), child(0.55f)));
        assertTrue(first.events.isEmpty());
        assertEquals(1, first.visible.size());

        TrackManager.Update second = manager.update(Arrays.asList(root(), child(0.62f)));
        assertFalse(containsEvent(second, "CANDIDATE_CONFIRMED", "PILE-02"));

        TrackManager.Update third = manager.update(Arrays.asList(root(), child(0.64f)));
        assertTrue(containsEvent(third, "CANDIDATE_CONFIRMED", "PILE-02"));
        assertNotNull(findBox(third, "PILE-01"));
        assertNotNull(findBox(third, "PILE-02"));
    }

    @Test public void unrelatedSceneObjectsAndNestedContoursCannotSpawnManyPiles() {
        TrackManager manager = new TrackManager(true);
        manager.seedMaster(MASTER);
        DetectionCandidate[] unrelated = new DetectionCandidate[]{
                root(),
                new DetectionCandidate(0.80f, 0.20f, 0.92f, 0.30f, 99f),
                new DetectionCandidate(0.10f, 0.75f, 0.19f, 0.84f, 97f),
                new DetectionCandidate(0.37f, 0.34f, 0.48f, 0.42f, 96f)
        };
        for (int i=0; i<5; i++) {
            TrackManager.Update update = manager.update(Arrays.asList(unrelated));
            assertNotNull(findBox(update, "PILE-01"));
            assertEquals(1, update.visible.size());
            assertFalse(containsEvent(update, "CANDIDATE_CONFIRMED", "PILE-02"));
        }
    }

    private static boolean containsEvent(TrackManager.Update update, String type, String id) {
        for (TrackManager.Event event : update.events) if (type.equals(event.type) && id.equals(event.trackId)) return true;
        return false;
    }
    private static TrackManager.TrackedBox findBox(TrackManager.Update update, String id) {
        for (TrackManager.TrackedBox box : update.visible) if (id.equals(box.id)) return box;
        return null;
    }
}
