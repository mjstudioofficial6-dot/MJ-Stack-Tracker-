package com.mj.stacktracker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

import java.util.Arrays;
import java.util.Locale;

/** Schematic digital view of the known/estimated piles; not a recovered physical 3D model. */
public final class LayerModelView extends View {
    private final Paint facePaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sidePaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint topPaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private int[] pileCounts={416};
    private String[] pileNames={"Pile 1"};
    private boolean[] estimated={false};
    private double thicknessMm=0.33;
    private float tiltDegrees=0f;

    public LayerModelView(Context context) {
        super(context); setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        facePaint.setColor(0xFFDCE4EB); sidePaint.setColor(0xFFC4CFD9); topPaint.setColor(0xFFFFF4CF);
        linePaint.setColor(0xFF526579); linePaint.setStrokeWidth(dp(0.45f));
        textPaint.setColor(0xFF354052); textPaint.setTextSize(dp(9));
    }

    public void setModel(int layerCount,double pieceThicknessMm,float tilt) {
        setPiles(new String[]{"Pile 1"},new int[]{layerCount},new boolean[]{false},pieceThicknessMm,tilt);
    }

    public void setPiles(String[] names,int[] counts,boolean[] isEstimated,double pieceThicknessMm,float tilt) {
        int n=Math.max(1,Math.min(6,counts==null?1:counts.length));
        pileCounts=new int[n];pileNames=new String[n];estimated=new boolean[n];
        for(int i=0;i<n;i++){
            pileCounts[i]=Math.max(0,Math.min(100000,counts==null?416:counts[i]));
            pileNames[i]=names!=null&&i<names.length&&names[i]!=null?names[i]:"Pile "+(i+1);
            estimated[i]=isEstimated!=null&&i<isEstimated.length&&isEstimated[i];
        }
        thicknessMm=pieceThicknessMm>0&&Double.isFinite(pieceThicknessMm)?pieceThicknessMm:0.33;
        tiltDegrees=Math.max(0,Math.min(60,tilt));invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);canvas.drawColor(0xFFF8F9FA);
        float w=getWidth(),h=getHeight();if(w<30||h<35)return;
        int n=pileCounts.length;int max=1;for(int c:pileCounts)max=Math.max(max,c);
        float margin=dp(8),gap=dp(7),depth=Math.min(dp(16),w*0.045f);
        float slotW=(w-2*margin-gap*(n-1))/n;
        float maxBodyH=h*0.58f;
        float bodyBottom=h*0.82f;
        float tilt=(float)Math.sin(Math.toRadians(tiltDegrees))*maxBodyH*0.10f;
        for(int i=0;i<n;i++){
            int count=pileCounts[i];float slotLeft=margin+i*(slotW+gap);
            float bodyW=Math.max(dp(16),slotW-depth-dp(2));
            float bodyH=Math.max(dp(13),maxBodyH*(count/(float)max));
            float left=slotLeft+(slotW-bodyW-depth)*0.5f;
            float bottom=bodyBottom,top=bottom-bodyH;
            float localTilt=tilt*(count/(float)max);
            Path front=new Path();front.moveTo(left+localTilt,top);front.lineTo(left+bodyW+localTilt,top);front.lineTo(left+bodyW,bottom);front.lineTo(left,bottom);front.close();canvas.drawPath(front,facePaint);
            Path side=new Path();side.moveTo(left+bodyW+localTilt,top);side.lineTo(left+bodyW+depth+localTilt*0.45f,top-depth*0.45f);side.lineTo(left+bodyW+depth,bottom-depth*0.45f);side.lineTo(left+bodyW,bottom);side.close();canvas.drawPath(side,sidePaint);
            Path topFace=new Path();topFace.moveTo(left+localTilt,top);topFace.lineTo(left+bodyW+localTilt,top);topFace.lineTo(left+bodyW+depth+localTilt*0.45f,top-depth*0.45f);topFace.lineTo(left+depth+localTilt*0.45f,top-depth*0.45f);topFace.close();canvas.drawPath(topFace,topPaint);
            // A bounded number of visual seams keeps rendering readable on a phone; it is not
            // a promise that every physical layer is visible or individually detected.
            int drawnLines=Math.min(70,Math.max(0,count-1));
            for(int line=1;line<=drawnLines;line++){
                float f=line/(float)(drawnLines+1);float y=bottom-f*bodyH;float shear=localTilt*(1f-f);
                canvas.drawLine(left+shear,y,left+bodyW+shear,y,linePaint);
            }
            String label=pileNames[i]+(estimated[i]?" ~":" ")+count;
            if(textPaint.measureText(label)>slotW) label=(i==0?"P1":"P"+(i+1))+ (estimated[i]?" ~":" ")+count;
            canvas.drawText(label,slotLeft+dp(1),dp(14),textPaint);
        }
        StringBuilder counts=new StringBuilder();
        for(int i=0;i<n;i++){if(i>0)counts.append("   ");counts.append(pileNames[i]).append(estimated[i]?" ≈":" ").append(pileCounts[i]);}
        if(counts.length()>90)counts=new StringBuilder(n+" piles • total displayed pieces "+Arrays.stream(pileCounts).sum());
        textPaint.setTextSize(dp(9));canvas.drawText(counts.toString(),dp(8),h-dp(5),textPaint);
    }
    private float dp(float x){return x*getResources().getDisplayMetrics().density;}
}
