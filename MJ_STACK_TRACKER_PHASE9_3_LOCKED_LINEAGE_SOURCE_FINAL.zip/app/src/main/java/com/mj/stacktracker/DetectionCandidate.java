package com.mj.stacktracker;

/** One image-space candidate proposed by the OpenCV contour detector. */
public final class DetectionCandidate {
    public float left;
    public float top;
    public float right;
    public float bottom;
    /** Heuristic image-shape score from 0 to 100; not ground-truth accuracy. */
    public float detectorScore;
    public String trackId = "";

    public DetectionCandidate(float left, float top, float right, float bottom, float detectorScore) {
        this.left = clamp(left);
        this.top = clamp(top);
        this.right = clamp(right);
        this.bottom = clamp(bottom);
        this.detectorScore = Math.max(0f, Math.min(100f, detectorScore));
    }

    public float centerX() { return (left + right) * 0.5f; }
    public float centerY() { return (top + bottom) * 0.5f; }
    public float width() { return Math.max(0f, right - left); }
    public float height() { return Math.max(0f, bottom - top); }
    public float area() { return width() * height(); }

    private static float clamp(float v) {
        return Math.max(0f, Math.min(1f, v));
    }
}
