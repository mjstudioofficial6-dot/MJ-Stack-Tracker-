package com.mj.stacktracker;

import android.graphics.Bitmap;
import android.util.Log;

import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Phase 3.1 bounded proposal detector. It analyzes only the user-marked work area;
 * proposals still are not semantic proof that a detected region is a real stack.
 */
public final class FrameDetector {
    private static final int MAX_WIDTH = 640;
    private static final int MAX_CANDIDATES = 12;

    public List<DetectionCandidate> detect(Bitmap source, float[] workArea) {
        List<DetectionCandidate> result = new ArrayList<>();
        if (source == null || source.isRecycled() || source.getWidth() < 32 || source.getHeight() < 32
                || workArea == null || workArea.length < 4) return result;

        float left=clamp(Math.min(workArea[0],workArea[2]));
        float top=clamp(Math.min(workArea[1],workArea[3]));
        float right=clamp(Math.max(workArea[0],workArea[2]));
        float bottom=clamp(Math.max(workArea[1],workArea[3]));
        int x0=Math.max(0,Math.min(source.getWidth()-1,Math.round(left*source.getWidth())));
        int y0=Math.max(0,Math.min(source.getHeight()-1,Math.round(top*source.getHeight())));
        int x1=Math.max(x0+1,Math.min(source.getWidth(),Math.round(right*source.getWidth())));
        int y1=Math.max(y0+1,Math.min(source.getHeight(),Math.round(bottom*source.getHeight())));
        int cropW=x1-x0,cropH=y1-y0;
        if(cropW<24 || cropH<24) return result;

        Bitmap crop=null,scaled=null;
        Mat rgba=new Mat(),rgb=new Mat(),hsv=new Mat(),mask=new Mat();
        Mat kernel=null,contourInput=null,hierarchy=new Mat();
        List<MatOfPoint> contours=new ArrayList<>();
        try {
            crop=Bitmap.createBitmap(source,x0,y0,cropW,cropH);
            float roiL=x0/(float)source.getWidth(), roiT=y0/(float)source.getHeight();
            float roiR=x1/(float)source.getWidth(), roiB=y1/(float)source.getHeight();
            float roiW=roiR-roiL,roiH=roiB-roiT;
            float scale=Math.min(1f,MAX_WIDTH/(float)crop.getWidth());
            int w=Math.max(32,Math.round(crop.getWidth()*scale));
            int h=Math.max(32,Math.round(crop.getHeight()*scale));
            scaled=Bitmap.createScaledBitmap(crop,w,h,true);
            Utils.bitmapToMat(scaled,rgba);
            Imgproc.cvtColor(rgba,rgb,Imgproc.COLOR_RGBA2RGB);
            Imgproc.cvtColor(rgb,hsv,Imgproc.COLOR_RGB2HSV);

            // Neutral, bright surfaces are candidate evidence only. Limiting analysis
            // to the user-marked area removes many unrelated background contours.
            Core.inRange(hsv,new Scalar(0,0,92),new Scalar(180,78,255),mask);
            kernel=Imgproc.getStructuringElement(Imgproc.MORPH_RECT,new Size(3,5));
            Imgproc.morphologyEx(mask,mask,Imgproc.MORPH_CLOSE,kernel);
            contourInput=mask.clone();
            Imgproc.findContours(contourInput,contours,hierarchy,Imgproc.RETR_EXTERNAL,Imgproc.CHAIN_APPROX_SIMPLE);

            double imageArea=(double)w*h;
            double minArea=Math.max(85.0,imageArea*0.00038);
            double maxArea=imageArea*0.12;
            for(MatOfPoint contour:contours) {
                double contourArea=Imgproc.contourArea(contour);
                if(contourArea<minArea || contourArea>maxArea) continue;
                Rect r=Imgproc.boundingRect(contour);
                if(r.width<9 || r.height<5) continue;
                if(r.width>w*0.60 || r.height>h*0.60) continue;
                float aspect=r.width/(float)Math.max(1,r.height);
                if(aspect<0.20f || aspect>5.0f) continue;
                double boxArea=Math.max(1.0,(double)r.width*r.height);
                float fill=(float)Math.max(0.0,Math.min(1.0,contourArea/boxArea));
                Rect safe=new Rect(Math.max(0,r.x),Math.max(0,r.y),
                        Math.min(r.width,w-Math.max(0,r.x)),Math.min(r.height,h-Math.max(0,r.y)));
                if(safe.width<=0 || safe.height<=0) continue;
                Mat patch=mask.submat(safe);
                float whiteCoverage=(float)Core.countNonZero(patch)/(float)(safe.width*safe.height);
                patch.release();

                float aspectScore=(aspect>=0.32f && aspect<=3.8f)?1f:0.50f;
                float fillScore=Math.min(1f,fill/0.58f);
                float coverageScore=Math.min(1f,whiteCoverage/0.58f);
                float relativeArea=(float)(boxArea/imageArea);
                float areaScore=(float)Math.max(0.20,Math.min(1.0,relativeArea/0.0035));
                float score=100f*(0.32f*fillScore+0.40f*coverageScore+0.16f*aspectScore+0.12f*areaScore);
                if(score<43f) continue;

                // Convert crop-local pixel coordinates back to normalized full-frame
                // coordinates so player overlay and saved timestamps share one space.
                float l=roiL+(r.x/(float)w)*roiW;
                float t=roiT+(r.y/(float)h)*roiH;
                float rr=roiL+((r.x+r.width)/(float)w)*roiW;
                float bb=roiT+((r.y+r.height)/(float)h)*roiH;
                result.add(new DetectionCandidate(l,t,rr,bb,score));
            }
            result.sort(Comparator.comparingDouble((DetectionCandidate c)->c.detectorScore).reversed());
            return suppressOverlaps(result,MAX_CANDIDATES);
        } catch(Exception error) {
            Log.w("MJStackFrameDetector","ROI contour analysis failed",error);
            return result;
        } finally {
            for(MatOfPoint c:contours) c.release();
            rgba.release(); rgb.release(); hsv.release(); mask.release(); hierarchy.release();
            if(kernel!=null) kernel.release();
            if(contourInput!=null) contourInput.release();
            if(scaled!=null && scaled!=crop && !scaled.isRecycled()) scaled.recycle();
            if(crop!=null && crop!=source && !crop.isRecycled()) crop.recycle();
        }
    }

    private List<DetectionCandidate> suppressOverlaps(List<DetectionCandidate> input,int max) {
        List<DetectionCandidate> kept=new ArrayList<>();
        for(DetectionCandidate candidate:input) {
            boolean duplicate=false;
            for(DetectionCandidate prior:kept) {
                if(iou(candidate,prior)>0.35f) { duplicate=true; break; }
            }
            if(!duplicate) kept.add(candidate);
            if(kept.size()>=max) break;
        }
        return kept;
    }

    private float iou(DetectionCandidate a,DetectionCandidate b) {
        float l=Math.max(a.left,b.left),t=Math.max(a.top,b.top);
        float r=Math.min(a.right,b.right),bt=Math.min(a.bottom,b.bottom);
        float inter=Math.max(0f,r-l)*Math.max(0f,bt-t);
        float union=a.area()+b.area()-inter;
        return union<=0f?0f:inter/union;
    }
    private float clamp(float value) { return Math.max(0f,Math.min(1f,value)); }
}
