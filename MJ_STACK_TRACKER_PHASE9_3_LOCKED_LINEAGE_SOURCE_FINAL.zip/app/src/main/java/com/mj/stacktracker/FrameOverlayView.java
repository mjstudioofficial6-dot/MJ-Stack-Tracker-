package com.mj.stacktracker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Video-coordinate overlay with work-area, master-stack and scale-line selection tools. */
public final class FrameOverlayView extends View {
    public interface OnWorkAreaSelectedListener { void onWorkAreaSelected(float left,float top,float right,float bottom); }
    public interface OnMasterStackSelectedListener { void onMasterStackSelected(float left,float top,float right,float bottom); }
    public interface OnCalibrationLineSelectedListener { void onCalibrationLineSelected(float x1,float y1,float x2,float y2,boolean sideScale); }
    private enum Mode { NONE, WORK_AREA, MASTER_STACK, PLANE_LINE, SIDE_LINE }

    private final Paint boxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint roiPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint masterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint selectionPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<TrackManager.TrackedBox> boxes = new ArrayList<>();
    private int sourceWidth=16, sourceHeight=9;
    private long sourceTimestampMs=-1;
    private boolean hasWorkArea, workAreaVisible=true, hasMasterBox, masterBoxVisible=true, selectionMode, dragging;
    private float roiLeft,roiTop,roiRight,roiBottom;
    private float masterLeft,masterTop,masterRight,masterBottom;
    private float dragLeft,dragTop,dragRight,dragBottom;
    private float lineX1,lineY1,lineX2,lineY2;
    private Mode mode=Mode.NONE;
    private int masterCount=416;
    private double sidePixelsPerMm=Double.NaN;
    private OnWorkAreaSelectedListener workAreaListener;
    private OnMasterStackSelectedListener masterListener;
    private OnCalibrationLineSelectedListener calibrationListener;

    public FrameOverlayView(Context context) {
        super(context); setWillNotDraw(false); setClickable(false); setFocusable(false);
        boxPaint.setStyle(Paint.Style.STROKE); boxPaint.setStrokeWidth(dp(2)); boxPaint.setColor(0xFF21A366);
        textPaint.setColor(0xFFFFFFFF); textPaint.setTextSize(dp(11)); textPaint.setFakeBoldText(true);
        bgPaint.setColor(0xBB202124); bgPaint.setStyle(Paint.Style.FILL);
        roiPaint.setStyle(Paint.Style.STROKE); roiPaint.setStrokeWidth(dp(2)); roiPaint.setColor(0xFF00A6D6);
        masterPaint.setStyle(Paint.Style.STROKE); masterPaint.setStrokeWidth(dp(3)); masterPaint.setColor(0xFFFFC107);
        selectionPaint.setStyle(Paint.Style.STROKE); selectionPaint.setStrokeWidth(dp(3)); selectionPaint.setColor(0xFFFFC107);
        linePaint.setStyle(Paint.Style.STROKE); linePaint.setStrokeWidth(dp(3)); linePaint.setColor(0xFF7C4DFF);
    }

    public void setOnWorkAreaSelectedListener(OnWorkAreaSelectedListener listener) { workAreaListener=listener; }
    public void setOnMasterStackSelectedListener(OnMasterStackSelectedListener listener) { masterListener=listener; }
    public void setOnCalibrationLineSelectedListener(OnCalibrationLineSelectedListener listener) { calibrationListener=listener; }
    public void setSourceSize(int width,int height) { if(width>0&&height>0){sourceWidth=width;sourceHeight=height;invalidate();} }
    public void setBoxes(List<TrackManager.TrackedBox> list,long timestampMs){boxes.clear();if(list!=null)boxes.addAll(list);sourceTimestampMs=timestampMs;invalidate();}
    public void clearBoxes(){boxes.clear();sourceTimestampMs=-1;invalidate();}

    public void setWorkArea(float left,float top,float right,float bottom){
        workAreaVisible=true;
        roiLeft=clamp(Math.min(left,right));roiTop=clamp(Math.min(top,bottom));roiRight=clamp(Math.max(left,right));roiBottom=clamp(Math.max(top,bottom));
        hasWorkArea=(roiRight-roiLeft)>=0.04f&&(roiBottom-roiTop)>=0.04f;invalidate();
    }
    public void clearWorkArea(){hasWorkArea=false;workAreaVisible=false;if(mode==Mode.WORK_AREA)endSelection();invalidate();}
    public void setWorkAreaVisible(boolean visible){workAreaVisible=visible;invalidate();}
    public void cancelSelection(){endSelection();invalidate();}
    public boolean hasWorkArea(){return hasWorkArea;}

    public void setMasterBox(float left,float top,float right,float bottom,int count){
        masterLeft=clamp(Math.min(left,right));masterTop=clamp(Math.min(top,bottom));masterRight=clamp(Math.max(left,right));masterBottom=clamp(Math.max(top,bottom));
        hasMasterBox=(masterRight-masterLeft)>=0.015f&&(masterBottom-masterTop)>=0.015f;masterBoxVisible=true;masterCount=Math.max(0,count);invalidate();
    }
    public void clearMasterBox(){hasMasterBox=false;masterBoxVisible=true;if(mode==Mode.MASTER_STACK)endSelection();invalidate();}
    public void setMasterBoxVisible(boolean visible){masterBoxVisible=visible;invalidate();}
    public boolean hasMasterBox(){return hasMasterBox;}
    public void setMasterCount(int count){masterCount=Math.max(0,count);invalidate();}
    public void setSideScalePixelsPerMm(double value){sidePixelsPerMm=value;invalidate();}

    public void setSelectionMode(boolean enabled){beginMode(enabled?Mode.WORK_AREA:Mode.NONE);}
    public void setMasterSelectionMode(boolean enabled){beginMode(enabled?Mode.MASTER_STACK:Mode.NONE);}
    public void setCalibrationSelectionMode(boolean side){beginMode(side?Mode.SIDE_LINE:Mode.PLANE_LINE);}
    private void beginMode(Mode selected){mode=selected;selectionMode=selected!=Mode.NONE;dragging=false;setClickable(selectionMode);setFocusable(selectionMode);lineX1=lineY1=lineX2=lineY2=0;invalidate();}
    private void endSelection(){mode=Mode.NONE;selectionMode=false;dragging=false;setClickable(false);setFocusable(false);}

    @Override public boolean onTouchEvent(MotionEvent event){
        if(!selectionMode)return false;
        float[] p=toNormalized(event.getX(),event.getY(),event.getActionMasked()==MotionEvent.ACTION_DOWN);
        switch(event.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                if(p==null)return false;
                dragLeft=dragRight=p[0];dragTop=dragBottom=p[1];lineX1=p[0];lineY1=p[1];lineX2=p[0];lineY2=p[1];dragging=true;invalidate();return true;
            case MotionEvent.ACTION_MOVE:
                if(!dragging)return false;
                if(p!=null){dragRight=p[0];dragBottom=p[1];lineX2=p[0];lineY2=p[1];}invalidate();return true;
            case MotionEvent.ACTION_UP:
                if(!dragging)return false;
                if(p!=null){dragRight=p[0];dragBottom=p[1];lineX2=p[0];lineY2=p[1];}
                dragging=false;
                if(mode==Mode.WORK_AREA||mode==Mode.MASTER_STACK){
                    float l=Math.min(dragLeft,dragRight),t=Math.min(dragTop,dragBottom),r=Math.max(dragLeft,dragRight),b=Math.max(dragTop,dragBottom);
                    if((r-l)>=0.04f&&(b-t)>=0.04f){
                        Mode completed=mode;endSelection();
                        if(completed==Mode.WORK_AREA){setWorkArea(l,t,r,b);if(workAreaListener!=null)workAreaListener.onWorkAreaSelected(roiLeft,roiTop,roiRight,roiBottom);}
                        else {setMasterBox(l,t,r,b,masterCount);if(masterListener!=null)masterListener.onMasterStackSelected(masterLeft,masterTop,masterRight,masterBottom);}
                    }
                }else if(mode==Mode.PLANE_LINE||mode==Mode.SIDE_LINE){
                    float dx=(lineX2-lineX1)*sourceWidth,dy=(lineY2-lineY1)*sourceHeight;
                    if(Math.hypot(dx,dy)>=3){boolean side=mode==Mode.SIDE_LINE;endSelection();if(calibrationListener!=null)calibrationListener.onCalibrationLineSelected(lineX1,lineY1,lineX2,lineY2,side);}
                }
                invalidate();return true;
            case MotionEvent.ACTION_CANCEL:dragging=false;invalidate();return true;
            default:return true;
        }
    }

    private float[] toNormalized(float x,float y,boolean rejectOutside){
        float scale=Math.min(getWidth()/(float)Math.max(1,sourceWidth),getHeight()/(float)Math.max(1,sourceHeight));
        float drawnW=sourceWidth*scale,drawnH=sourceHeight*scale;float ox=(getWidth()-drawnW)*0.5f,oy=(getHeight()-drawnH)*0.5f;
        if(rejectOutside&&(x<ox||x>ox+drawnW||y<oy||y>oy+drawnH))return null;
        return new float[]{clamp((x-ox)/Math.max(1f,drawnW)),clamp((y-oy)/Math.max(1f,drawnH))};
    }

    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        float scale=Math.min(getWidth()/(float)Math.max(1,sourceWidth),getHeight()/(float)Math.max(1,sourceHeight));
        float drawnW=sourceWidth*scale,drawnH=sourceHeight*scale,ox=(getWidth()-drawnW)*0.5f,oy=(getHeight()-drawnH)*0.5f;
        for(TrackManager.TrackedBox b:boxes){
            float l=ox+b.left*drawnW,t=oy+b.top*drawnH,r=ox+b.right*drawnW,bt=oy+b.bottom*drawnH;
            boxPaint.setColor(b.confidence>=65f?0xFF21A366:(b.confidence>=40f?0xFFFFB300:0xFFE53935));canvas.drawRect(new RectF(l,t,r,bt),boxPaint);
            String label=b.id+" "+Math.round(b.confidence)+"%";
            if(Double.isFinite(sidePixelsPerMm)&&sidePixelsPerMm>0){double hMm=((b.bottom-b.top)*sourceHeight)/sidePixelsPerMm;label+=" h≈"+String.format(Locale.US,"%.1f",hMm)+"mm";}
            float tw=textPaint.measureText(label),labelY=Math.max(oy+dp(14),t-dp(3));canvas.drawRect(l,labelY-dp(13),l+tw+dp(8),labelY+dp(3),bgPaint);canvas.drawText(label,l+dp(4),labelY,textPaint);
        }
        if(hasWorkArea && workAreaVisible){roiPaint.setColor(mode==Mode.WORK_AREA?0xFFFFC107:0xFF00A6D6);canvas.drawRect(new RectF(ox+roiLeft*drawnW,oy+roiTop*drawnH,ox+roiRight*drawnW,oy+roiBottom*drawnH),roiPaint);drawLabel(canvas,ox+roiLeft*drawnW,oy+roiTop*drawnH,"WORK AREA",0xFF00A6D6);}
        if(hasMasterBox && masterBoxVisible){canvas.drawRect(new RectF(ox+masterLeft*drawnW,oy+masterTop*drawnH,ox+masterRight*drawnW,oy+masterBottom*drawnH),masterPaint);drawLabel(canvas,ox+masterLeft*drawnW,oy+masterTop*drawnH,"LOCKED OBJECT • PILE 1 • "+masterCount,0xFFFFC107);}
        if(selectionMode&&dragging){
            if(mode==Mode.PLANE_LINE||mode==Mode.SIDE_LINE){float x1=ox+lineX1*drawnW,y1=oy+lineY1*drawnH,x2=ox+lineX2*drawnW,y2=oy+lineY2*drawnH;linePaint.setColor(mode==Mode.SIDE_LINE?0xFF7C4DFF:0xFF00897B);canvas.drawLine(x1,y1,x2,y2,linePaint);canvas.drawCircle(x1,y1,dp(4),linePaint);canvas.drawCircle(x2,y2,dp(4),linePaint);}
            else{float l=Math.min(dragLeft,dragRight),t=Math.min(dragTop,dragBottom),r=Math.max(dragLeft,dragRight),b=Math.max(dragTop,dragBottom);canvas.drawRect(new RectF(ox+l*drawnW,oy+t*drawnH,ox+r*drawnW,oy+b*drawnH),selectionPaint);}
        }
        if(sourceTimestampMs>=0&&!boxes.isEmpty()){String info="tracking overlay • "+String.format(Locale.US,"%.3f",sourceTimestampMs/1000.0)+" s";float w=textPaint.measureText(info)+dp(12);canvas.drawRect(dp(6),dp(6),dp(6)+w,dp(27),bgPaint);canvas.drawText(info,dp(12),dp(21),textPaint);}
    }
    private void drawLabel(Canvas c,float x,float y,String text,int color){textPaint.setColor(0xFFFFFFFF);float ty=Math.max(dp(14),y-dp(3));float tw=textPaint.measureText(text);bgPaint.setColor(0xCC202124);c.drawRect(x,ty-dp(13),x+tw+dp(8),ty+dp(3),bgPaint);c.drawText(text,x+dp(4),ty,textPaint);}
    private float clamp(float value){return Math.max(0f,Math.min(1f,value));}
    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
}
