package com.mj.stacktracker;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Conservative conservation ledger for the locked master stack.
 * Every transition preserves: initial + added = visible + occluded + out-of-view + removed + unassigned.
 * This class never guesses piece counts from pixels.
 */
public final class StackLedger {
    private int initialCount;
    private int addedCount;
    private int visibleCount;
    private int occludedCount;
    private int outOfViewCount;
    private int removedCount;
    private int unassignedCount;
    private final List<int[]> undoStates = new ArrayList<>();

    public StackLedger(int initialCount) {
        this.initialCount = Math.max(0, initialCount);
        this.visibleCount = this.initialCount;
    }

    private StackLedger() { }

    public synchronized int getInitialCount() { return initialCount; }
    public synchronized int getAddedCount() { return addedCount; }
    public synchronized int getVisibleCount() { return visibleCount; }
    public synchronized int getOccludedCount() { return occludedCount; }
    public synchronized int getOutOfViewCount() { return outOfViewCount; }
    public synchronized int getRemovedCount() { return removedCount; }
    public synchronized int getUnassignedCount() { return unassignedCount; }
    public synchronized int getExpectedTotal() { return initialCount + addedCount; }
    public synchronized int getAccountedTotal() { return visibleCount + occludedCount + outOfViewCount + removedCount + unassignedCount; }
    public synchronized boolean isConserved() { return getExpectedTotal() == getAccountedTotal(); }

    public synchronized void reset(int count) {
        undoStates.clear();
        initialCount = Math.max(0, count);
        addedCount = 0;
        visibleCount = initialCount;
        occludedCount = 0;
        outOfViewCount = 0;
        removedCount = 0;
        unassignedCount = 0;
    }

    /** Known child counts must sum to the parent count. Null/empty means counts are unknown. */
    public synchronized boolean registerSplit(int parentCount, int[] childCounts) {
        if (parentCount <= 0) return false;
        boolean known = childCounts != null && childCounts.length > 0;
        if (known) {
            int sum = 0;
            for (int value : childCounts) {
                if (value <= 0) return false;
                if (Integer.MAX_VALUE - sum < value) return false;
                sum += value;
            }
            if (sum != parentCount) return false;
            if (unassignedCount >= parentCount) {
                pushUndo();
                unassignedCount -= parentCount;
                visibleCount += parentCount;
                return isConserved();
            }
            if (visibleCount < parentCount) return false;
            pushUndo();
            return isConserved(); // known split reallocates the same visible pieces
        }
        if (visibleCount >= parentCount) {
            pushUndo();
            visibleCount -= parentCount;
            unassignedCount += parentCount;
            return isConserved();
        }
        return unassignedCount >= parentCount;
    }

    /** Allocate all currently unassigned pieces into known visible child stacks. */
    public synchronized boolean allocateUnassigned(int[] childCounts) {
        if (childCounts == null || childCounts.length == 0 || unassignedCount <= 0) return false;
        int sum = 0;
        for (int value : childCounts) {
            if (value <= 0 || Integer.MAX_VALUE - sum < value) return false;
            sum += value;
        }
        if (sum != unassignedCount) return false;
        pushUndo();
        visibleCount += unassignedCount;
        unassignedCount = 0;
        return isConserved();
    }

    public synchronized boolean markOccluded(int count) {
        if (count <= 0 || visibleCount < count) return false;
        pushUndo(); visibleCount -= count; occludedCount += count; return isConserved();
    }

    public synchronized boolean markOutOfView(int count) {
        if (count <= 0 || visibleCount < count) return false;
        pushUndo(); visibleCount -= count; outOfViewCount += count; return isConserved();
    }

    public synchronized boolean returnFromOcclusion(int count) {
        if (count <= 0 || occludedCount < count) return false;
        pushUndo(); occludedCount -= count; visibleCount += count; return isConserved();
    }

    public synchronized boolean returnFromOutOfView(int count) {
        if (count <= 0 || outOfViewCount < count) return false;
        pushUndo(); outOfViewCount -= count; visibleCount += count; return isConserved();
    }

    public synchronized boolean confirmRemoved(int count) {
        if (count <= 0 || visibleCount < count) return false;
        pushUndo(); visibleCount -= count; removedCount += count; return isConserved();
    }

    public synchronized boolean addPieces(int count) {
        if (count <= 0 || Integer.MAX_VALUE - addedCount < count || Integer.MAX_VALUE - visibleCount < count) return false;
        pushUndo(); addedCount += count; visibleCount += count; return isConserved();
    }

    public synchronized boolean undoLastLedgerChange() {
        if (undoStates.isEmpty()) return false;
        int[] s = undoStates.remove(undoStates.size() - 1);
        restore(s);
        return isConserved();
    }

    public synchronized String summary() {
        return "Conservation: " + getExpectedTotal() + " expected = " + getAccountedTotal()
                + " accounted • visible " + visibleCount + " • occluded " + occludedCount
                + " • out-of-view " + outOfViewCount + " • removed " + removedCount
                + " • unassigned " + unassignedCount + (isConserved() ? " • BALANCED" : " • ERROR — stop and review");
    }

    public synchronized String toJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("initial", initialCount); o.put("added", addedCount); o.put("visible", visibleCount);
            o.put("occluded", occludedCount); o.put("outOfView", outOfViewCount);
            o.put("removed", removedCount); o.put("unassigned", unassignedCount);
            JSONArray undo = new JSONArray();
            for (int[] state : undoStates) {
                JSONArray row = new JSONArray();
                for (int value : state) row.put(value);
                undo.put(row);
            }
            o.put("undo", undo);
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    public static StackLedger fromJson(String json, int fallbackCount) {
        if (json == null || json.trim().isEmpty()) return new StackLedger(fallbackCount);
        try {
            JSONObject o = new JSONObject(json);
            StackLedger l = new StackLedger();
            l.initialCount = Math.max(0, o.optInt("initial", fallbackCount));
            l.addedCount = Math.max(0, o.optInt("added", 0));
            l.visibleCount = Math.max(0, o.optInt("visible", l.initialCount));
            l.occludedCount = Math.max(0, o.optInt("occluded", 0));
            l.outOfViewCount = Math.max(0, o.optInt("outOfView", 0));
            l.removedCount = Math.max(0, o.optInt("removed", 0));
            l.unassignedCount = Math.max(0, o.optInt("unassigned", 0));
            JSONArray undo = o.optJSONArray("undo");
            if (undo != null) {
                for (int i = 0; i < undo.length(); i++) {
                    JSONArray row = undo.optJSONArray(i);
                    if (row != null && row.length() == 7) {
                        int[] s = new int[7];
                        for (int j = 0; j < 7; j++) s[j] = row.optInt(j, 0);
                        l.undoStates.add(s);
                    }
                }
            }
            if (!l.isConserved()) return new StackLedger(fallbackCount);
            return l;
        } catch (Exception e) { return new StackLedger(fallbackCount); }
    }

    private void pushUndo() {
        undoStates.add(new int[]{initialCount, addedCount, visibleCount, occludedCount, outOfViewCount, removedCount, unassignedCount});
        while (undoStates.size() > 40) undoStates.remove(0);
    }

    private void restore(int[] s) {
        if (s == null || s.length != 7) return;
        initialCount=s[0]; addedCount=s[1]; visibleCount=s[2]; occludedCount=s[3];
        outOfViewCount=s[4]; removedCount=s[5]; unassignedCount=s[6];
    }
}
