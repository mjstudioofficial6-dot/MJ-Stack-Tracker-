package com.mj.stacktracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Local-only, continuously persisted analysis history. */
public final class LocalHistoryDb extends SQLiteOpenHelper {
    private static final String DB_NAME="mj_stack_tracker_history.db";
    private static final int DB_VERSION=1;

    public LocalHistoryDb(Context context) { super(context,DB_NAME,null,DB_VERSION); setWriteAheadLoggingEnabled(true); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE sessions (_id INTEGER PRIMARY KEY AUTOINCREMENT, source_uri TEXT NOT NULL, source_name TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, status TEXT NOT NULL, video_duration_ms INTEGER NOT NULL DEFAULT 0, video_width INTEGER NOT NULL DEFAULT 0, video_height INTEGER NOT NULL DEFAULT 0, total_frames INTEGER NOT NULL DEFAULT 0, processed_frames INTEGER NOT NULL DEFAULT 0, avg_confidence REAL NOT NULL DEFAULT 0, note TEXT NOT NULL DEFAULT '')");
        db.execSQL("CREATE TABLE frame_records (_id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER NOT NULL, frame_index INTEGER NOT NULL, timestamp_ms INTEGER NOT NULL, candidate_count INTEGER NOT NULL, confidence REAL NOT NULL, status TEXT NOT NULL, detections_json TEXT NOT NULL, created_at INTEGER NOT NULL, FOREIGN KEY(session_id) REFERENCES sessions(_id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX frame_session_time_idx ON frame_records(session_id,timestamp_ms DESC)");
        db.execSQL("CREATE UNIQUE INDEX frame_session_index_idx ON frame_records(session_id,frame_index)");
        db.execSQL("CREATE TABLE tracking_events (_id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER NOT NULL, timestamp_ms INTEGER NOT NULL, event_type TEXT NOT NULL, track_id TEXT NOT NULL, confidence REAL NOT NULL, status TEXT NOT NULL, details TEXT NOT NULL, created_at INTEGER NOT NULL, FOREIGN KEY(session_id) REFERENCES sessions(_id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX event_session_time_idx ON tracking_events(session_id,timestamp_ms DESC)");
    }

    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) { }

    public synchronized void markIncompleteSessionsInterrupted() {
        ContentValues v=new ContentValues();
        v.put("status","INTERRUPTED");
        v.put("updated_at",System.currentTimeMillis());
        v.put("note","Previous analysis did not finish; already saved frame history is preserved.");
        getWritableDatabase().update("sessions",v,"status IN ('RUNNING','QUEUED')",null);
    }

    public synchronized long createSession(String uri,String name) {
        long now=System.currentTimeMillis(); ContentValues v=new ContentValues();
        v.put("source_uri",uri); v.put("source_name",name); v.put("created_at",now); v.put("updated_at",now); v.put("status","QUEUED"); v.put("note","OpenCV contour proposals; no ground-truth accuracy yet.");
        return getWritableDatabase().insertOrThrow("sessions",null,v);
    }

    public synchronized void updateMetadata(long id,long durationMs,int width,int height,int totalFrames,String status) {
        ContentValues v=new ContentValues(); v.put("video_duration_ms",durationMs); v.put("video_width",width); v.put("video_height",height); v.put("total_frames",totalFrames); v.put("status",status); v.put("updated_at",System.currentTimeMillis());
        getWritableDatabase().update("sessions",v,"_id=?",new String[]{String.valueOf(id)});
    }

    public synchronized void updateProgress(long id,int processed,int total,double averageConfidence,String status,String note) {
        ContentValues v=new ContentValues(); v.put("processed_frames",processed); v.put("total_frames",total); v.put("avg_confidence",averageConfidence); v.put("status",status); v.put("updated_at",System.currentTimeMillis()); if(note!=null) v.put("note",note);
        getWritableDatabase().update("sessions",v,"_id=?",new String[]{String.valueOf(id)});
    }

    public synchronized void saveFrame(long sessionId,int frameIndex,long timestampMs,int candidateCount,double confidence,String status,JSONArray detections) {
        ContentValues v=new ContentValues(); v.put("session_id",sessionId); v.put("frame_index",frameIndex); v.put("timestamp_ms",timestampMs); v.put("candidate_count",candidateCount); v.put("confidence",confidence); v.put("status",status); v.put("detections_json",detections.toString()); v.put("created_at",System.currentTimeMillis());
        getWritableDatabase().insertWithOnConflict("frame_records",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }

    public synchronized void saveEvent(long sessionId,long timestampMs,String type,String trackId,double confidence,String status,String details) {
        ContentValues v=new ContentValues(); v.put("session_id",sessionId); v.put("timestamp_ms",timestampMs); v.put("event_type",type); v.put("track_id",trackId); v.put("confidence",confidence); v.put("status",status); v.put("details",details); v.put("created_at",System.currentTimeMillis());
        getWritableDatabase().insert("tracking_events",null,v);
    }

    public synchronized long findLatestSessionForUri(String uri) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT _id FROM sessions WHERE source_uri=? ORDER BY _id DESC LIMIT 1",new String[]{uri})) { return c.moveToFirst()?c.getLong(0):-1; }
    }

    public synchronized String getSessionUri(long sessionId) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT source_uri FROM sessions WHERE _id=?",new String[]{String.valueOf(sessionId)})) {
            return c.moveToFirst()?c.getString(0):null;
        }
    }

    public synchronized long getLatestSessionId() {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT _id FROM sessions ORDER BY _id DESC LIMIT 1",null)) { return c.moveToFirst()?c.getLong(0):-1; }
    }

    public synchronized Observation getObservationAtOrBefore(long sessionId,long timestampMs) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT timestamp_ms,detections_json,confidence,status FROM frame_records WHERE session_id=? AND timestamp_ms<=? ORDER BY timestamp_ms DESC,_id DESC LIMIT 1",new String[]{String.valueOf(sessionId),String.valueOf(timestampMs)})) {
            if(!c.moveToFirst()) return null;
            return new Observation(c.getLong(0),c.getString(1),c.getDouble(2),c.getString(3));
        }
    }

    public synchronized List<SessionSummary> getRecentSessions(int limit) {
        List<SessionSummary> result=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT _id,source_name,created_at,status,total_frames,processed_frames,avg_confidence,video_duration_ms,note FROM sessions ORDER BY _id DESC LIMIT ?",new String[]{String.valueOf(limit)})) {
            while(c.moveToNext()) result.add(new SessionSummary(c.getLong(0),c.getString(1),c.getLong(2),c.getString(3),c.getInt(4),c.getInt(5),c.getDouble(6),c.getLong(7),c.getString(8)));
        }
        return result;
    }

    public synchronized List<EventSummary> getRecentEvents(int limit) {
        List<EventSummary> result=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT e._id,e.session_id,s.source_name,e.timestamp_ms,e.event_type,e.track_id,e.confidence,e.status,e.details FROM tracking_events e JOIN sessions s ON s._id=e.session_id ORDER BY e._id DESC LIMIT ?",new String[]{String.valueOf(limit)})) {
            while(c.moveToNext()) result.add(new EventSummary(c.getLong(0),c.getLong(1),c.getString(2),c.getLong(3),c.getString(4),c.getString(5),c.getDouble(6),c.getString(7),c.getString(8)));
        }
        return result;
    }

    /** All events for a single session in chronological order, for its exportable session folder. */
    public synchronized List<EventSummary> getSessionEvents(long sessionId) {
        List<EventSummary> result=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery(
                "SELECT e._id,e.session_id,s.source_name,e.timestamp_ms,e.event_type,e.track_id,e.confidence,e.status,e.details " +
                "FROM tracking_events e JOIN sessions s ON s._id=e.session_id " +
                "WHERE e.session_id=? ORDER BY e.timestamp_ms ASC,e._id ASC",
                new String[]{String.valueOf(sessionId)})) {
            while(c.moveToNext()) result.add(new EventSummary(c.getLong(0),c.getLong(1),c.getString(2),c.getLong(3),c.getString(4),c.getString(5),c.getDouble(6),c.getString(7),c.getString(8)));
        }
        return result;
    }

    /** Complete, compact timeline for piles in one video session; avoids truncating long videos. */
    public synchronized List<EventSummary> getPileEvents(long sessionId) {
        List<EventSummary> result=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery(
                "SELECT e._id,e.session_id,s.source_name,e.timestamp_ms,e.event_type,e.track_id,e.confidence,e.status,e.details " +
                "FROM tracking_events e JOIN sessions s ON s._id=e.session_id " +
                "WHERE e.session_id=? AND e.event_type IN ('PILE_CREATED','PILE_COUNT_UPDATED','PILE_STATUS') ORDER BY e._id DESC",
                new String[]{String.valueOf(sessionId)})) {
            while(c.moveToNext()) result.add(new EventSummary(c.getLong(0),c.getLong(1),c.getString(2),c.getLong(3),c.getString(4),c.getString(5),c.getDouble(6),c.getString(7),c.getString(8)));
        }
        return result;
    }

    public synchronized boolean updateEventStatus(long eventId,String status) {
        ContentValues values=new ContentValues();values.put("status",status);
        return getWritableDatabase().update("tracking_events",values,"_id=?",new String[]{String.valueOf(eventId)})>0;
    }

    public synchronized boolean deleteEvent(long eventId) {
        return getWritableDatabase().delete("tracking_events","_id=?",new String[]{String.valueOf(eventId)})>0;
    }

    /** Deletes one analysis session and all frame/event records associated with it. */
    public synchronized boolean deleteSession(long sessionId) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            String[] args = new String[]{String.valueOf(sessionId)};
            db.delete("tracking_events", "session_id=?", args);
            db.delete("frame_records", "session_id=?", args);
            int removed = db.delete("sessions", "_id=?", new String[]{String.valueOf(sessionId)});
            db.setTransactionSuccessful();
            return removed > 0;
        } finally { db.endTransaction(); }
    }

    public static final class Observation {
        public final long timestampMs; public final String json,status; public final double confidence;
        Observation(long t,String j,double c,String s){timestampMs=t;json=j;confidence=c;status=s;}
    }
    public static final class SessionSummary {
        public final long id,createdAt,durationMs; public final String name,status,note; public final int total,processed; public final double confidence;
        SessionSummary(long id,String n,long c,String s,int t,int p,double conf,long dur,String note){this.id=id;name=n;createdAt=c;status=s;total=t;processed=p;confidence=conf;durationMs=dur;this.note=note;}
    }
    public static final class EventSummary {
        public final long id,sessionId,timestampMs; public final String sourceName,type,trackId,status,details; public final double confidence;
        EventSummary(long id,long sid,String source,long ts,String t,String track,double conf,String status,String details){this.id=id;sessionId=sid;sourceName=source;timestampMs=ts;type=t;trackId=track;confidence=conf;this.status=status;this.details=details;}
    }
}
