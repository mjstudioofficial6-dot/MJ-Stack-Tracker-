package com.mj.stacktracker;

/** Physical measurement formulas. These methods require a valid calibration. */
public final class MetricMath {
    private MetricMath() {}

    /** Pixels-per-millimetre from two marked endpoints and known physical distance. */
    public static double pixelsPerMm(double pixelDistance, double knownDistanceMm) {
        if (!Double.isFinite(pixelDistance) || !Double.isFinite(knownDistanceMm)
                || pixelDistance <= 0.0 || knownDistanceMm <= 0.0) return Double.NaN;
        return pixelDistance / knownDistanceMm;
    }

    /** Convert a distance in the same calibrated image plane to millimetres. */
    public static double pixelsToMm(double pixelDistance, double pxPerMm) {
        if (!Double.isFinite(pixelDistance) || !Double.isFinite(pxPerMm)
                || pixelDistance < 0.0 || pxPerMm <= 0.0) return Double.NaN;
        return pixelDistance / pxPerMm;
    }

    /** Height-based count candidate N = measured height / effective piece thickness. */
    public static double countCandidate(double heightMm, double effectiveThicknessMm) {
        if (!Double.isFinite(heightMm) || !Double.isFinite(effectiveThicknessMm)
                || heightMm < 0.0 || effectiveThicknessMm <= 0.0) return Double.NaN;
        return heightMm / effectiveThicknessMm;
    }

    /**
     * Approximate standard uncertainty propagation for N=H/t, assuming independent
     * one-sigma uncertainty on measured height and effective piece thickness.
     */
    public static double countSigma(double heightMm, double thicknessMm,
                                    double sigmaHeightMm, double sigmaThicknessMm) {
        if (heightMm < 0 || thicknessMm <= 0 || sigmaHeightMm < 0 || sigmaThicknessMm < 0
                || !Double.isFinite(heightMm) || !Double.isFinite(thicknessMm)
                || !Double.isFinite(sigmaHeightMm) || !Double.isFinite(sigmaThicknessMm)) return Double.NaN;
        double a = sigmaHeightMm / thicknessMm;
        double b = heightMm * sigmaThicknessMm / (thicknessMm * thicknessMm);
        return Math.sqrt(a*a + b*b);
    }

    public static int lower95Count(double count, double sigma) {
        if (!Double.isFinite(count) || !Double.isFinite(sigma) || sigma < 0) return -1;
        return Math.max(0, (int)Math.floor(count - 1.96 * sigma));
    }
    public static int upper95Count(double count, double sigma) {
        if (!Double.isFinite(count) || !Double.isFinite(sigma) || sigma < 0) return -1;
        return Math.max(0, (int)Math.ceil(count + 1.96 * sigma));
    }
}
