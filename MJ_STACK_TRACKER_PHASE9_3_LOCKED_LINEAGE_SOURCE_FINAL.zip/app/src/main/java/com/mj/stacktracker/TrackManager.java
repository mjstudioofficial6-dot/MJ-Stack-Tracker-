package com.mj.stacktracker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Conservative locked-object tracker.
 *
 * In locked-master mode an arbitrary contour is never enough to create a pile. A child track
 * must first touch/cross the boundary of an already confirmed pile, stay linked to that parent,
 * persist for multiple processed frames, and then visibly separate from the parent. Pending
 * contours are internal only: they do not get a user-facing Pile number or a History event.
 * This is geometric proposal tracking, not semantic proof of a physical pile.
 */
public final class TrackManager {
    public static final class TrackedBox {
        public final String id;
        public final float left, top, right, bottom, confidence;
        public final boolean matchedFromPrevious;
        TrackedBox(String id, float l, float t, float r, float b, float c, boolean matched) {
            this.id=id; left=l; top=t; right=r; bottom=b; confidence=c; matchedFromPrevious=matched;
        }
    }
    public static final class Event {
        public final String type, trackId, details;
        public final float confidence;
        Event(String type, String id, float confidence, String details) {
            this.type=type; trackId=id; this.confidence=confidence; this.details=details;
        }
    }
    public static final class Update {
        public final List<TrackedBox> visible;
        public final List<Event> events;
        public final float frameConfidence;
        Update(List<TrackedBox> visible, List<Event> events, float confidence) {
            this.visible=visible; this.events=events; frameConfidence=confidence;
        }
    }

    private static final int MAX_MISSED_FRAMES = 12;
    private static final int MIN_HITS_TO_CONFIRM = 3;
    private static final int MIN_DETACHED_FRAMES_TO_CONFIRM = 2;
    private static final float MIN_DETECTOR_SCORE = 58f;
    private static final float MIN_ASSOCIATION_SCORE_LOCKED = 0.42f;
    private static final float MAX_PARENT_CONTAINMENT = 0.80f;
    private static final float MIN_CHILD_OUTSIDE_FRACTION = 0.22f;
    private final List<Track> tracks = new ArrayList<>();
    private final boolean lockedMasterLineage;
    private int nextId = 2;
    private int nextPendingId = 1;

    public TrackManager() { this(false); }
    public TrackManager(boolean lockedMasterLineage) { this.lockedMasterLineage=lockedMasterLineage; }

    /** Establish the user-drawn original object as Pile 1 before analysing later frames. */
    public void seedMaster(float[] box) {
        if (box == null || box.length < 4) return;
        tracks.clear();
        nextId=2; nextPendingId=1;
        Track root=new Track();
        root.id="PILE-01";
        root.left=clamp01(box[0]); root.top=clamp01(box[1]);
        root.right=clamp01(box[2]); root.bottom=clamp01(box[3]);
        if (root.right < root.left) { float v=root.left; root.left=root.right; root.right=v; }
        if (root.bottom < root.top) { float v=root.top; root.top=root.bottom; root.bottom=v; }
        root.confidence=100f; root.missed=0; root.hits=MIN_HITS_TO_CONFIRM; root.confirmed=true; root.master=true;
        tracks.add(root);
    }

    public Update update(List<DetectionCandidate> detections) {
        List<Event> events=new ArrayList<>();
        List<Track> before=new ArrayList<>();
        for (Track t:tracks) before.add(t.copy());
        boolean[] usedTrack=new boolean[tracks.size()];
        List<TrackedBox> visible=new ArrayList<>();
        List<DetectionCandidate> ordered=new ArrayList<>(detections==null?Collections.emptyList():detections);
        ordered.removeAll(Collections.singleton(null));
        ordered.sort(Comparator.comparingDouble((DetectionCandidate c)->c.detectorScore).reversed());
        int matchedCount=0;
        Set<String> parentSpawnedThisFrame=new HashSet<>();

        for (DetectionCandidate d:ordered) {
            if (d.detectorScore < (lockedMasterLineage?MIN_DETECTOR_SCORE:50f)) continue;
            int bestIndex=-1; float bestScore=0f;
            for (int i=0;i<tracks.size();i++) {
                if (i>=usedTrack.length || usedTrack[i]) continue;
                Track t=tracks.get(i);
                if (!t.master && t.missed>MAX_MISSED_FRAMES) continue;
                // The root may only be associated with a whole-object-sized contour near its
                // locked centre. A detached child must never steal Pile 1's identity.
                if (lockedMasterLineage && t.master && !looksLikeWholeMaster(d,t)) continue;
                float score=associationScore(d,t);
                if (score>bestScore) { bestScore=score; bestIndex=i; }
            }
            Track chosen;
            float requiredScore=lockedMasterLineage?MIN_ASSOCIATION_SCORE_LOCKED:0.30f;
            boolean matched=bestIndex>=0 && bestScore>=requiredScore;
            if (matched) {
                usedTrack[bestIndex]=true; chosen=tracks.get(bestIndex); matchedCount++;
                chosen.left=0.35f*chosen.left+0.65f*d.left;
                chosen.top=0.35f*chosen.top+0.65f*d.top;
                chosen.right=0.35f*chosen.right+0.65f*d.right;
                chosen.bottom=0.35f*chosen.bottom+0.65f*d.bottom;
                chosen.confidence=clamp(0.75f*d.detectorScore+0.25f*bestScore*100f);
                boolean hadGap=chosen.missed>0;
                chosen.missed=0; chosen.hits=hadGap?1:chosen.hits+1;
                if (lockedMasterLineage && !chosen.master && !chosen.confirmed) {
                    updateSeparationEvidence(chosen,d,before);
                }
            } else {
                Track possibleParent=findSplitParent(d,before);
                // Only one new pending child per confirmed parent per processed frame. This
                // stops several nested contours around one visible object becoming many piles.
                if (possibleParent==null || parentSpawnedThisFrame.contains(possibleParent.id)) continue;
                chosen=new Track();
                chosen.id=lockedMasterLineage?String.format(Locale.US,"PENDING-%04d",nextPendingId++):makeId(nextId++);
                chosen.left=d.left; chosen.top=d.top; chosen.right=d.right; chosen.bottom=d.bottom;
                chosen.confidence=clamp(d.detectorScore*0.68f); chosen.missed=0; chosen.hits=1;
                chosen.parentId=possibleParent.id; chosen.master=false;
                chosen.birthCenterX=d.centerX(); chosen.birthCenterY=d.centerY();
                chosen.birthParentGap=rectGap(d,possibleParent);
                chosen.birthParentScale=Math.max(possibleParent.right-possibleParent.left,possibleParent.bottom-possibleParent.top);
                chosen.confirmed=false;
                tracks.add(chosen);
                usedTrack=java.util.Arrays.copyOf(usedTrack,tracks.size()); usedTrack[tracks.size()-1]=true;
                parentSpawnedThisFrame.add(possibleParent.id);
            }

            boolean mayConfirm = chosen.hits>=MIN_HITS_TO_CONFIRM
                    && (!lockedMasterLineage || chosen.master || chosen.separationFrames>=MIN_DETACHED_FRAMES_TO_CONFIRM);
            if (!chosen.confirmed && mayConfirm) {
                chosen.confirmed=true;
                if (lockedMasterLineage && !chosen.master && chosen.id.startsWith("PENDING-")) {
                    // Allocate public Pile numbers only after a real parent-separation event;
                    // rejected/temporary contours therefore cannot create gaps in pile IDs.
                    chosen.id=makeId(nextId++);
                }
                events.add(new Event("CANDIDATE_CONFIRMED",chosen.id,chosen.confidence,
                        "Child candidate stayed linked to "+(chosen.parentId==null?"the locked object":chosen.parentId)
                                +", persisted across multiple processed frames, and separated from its parent. "
                                +"This is a visual pile hypothesis; count remains an estimate and should be reviewed."));
            }
            if (chosen.confirmed) {
                visible.add(new TrackedBox(chosen.id,chosen.left,chosen.top,chosen.right,chosen.bottom,chosen.confidence,matched));
            }
        }

        for (int i=0;i<tracks.size();i++) {
            Track t=tracks.get(i);
            if (i>=usedTrack.length || !usedTrack[i]) {
                t.missed++;
                if (t.confirmed && !t.master && t.missed==MAX_MISSED_FRAMES+1) {
                    events.add(new Event("TRACK_NOT_VISIBLE",t.id,t.confidence,
                            "This confirmed pile track was not visible for multiple processed frames. It may be hidden or outside the view; it is not automatically marked removed."));
                }
            }
        }
        // Do not draw a stale fixed box when the locked object is not detected in this frame.
        // The user requested the marker to follow the pile or disappear, never remain pinned
        // at the original screen coordinates while unrelated objects move around it.
        for (int i=tracks.size()-1;i>=0;i--) {
            Track t=tracks.get(i);
            if (t.master) continue;
            if ((!t.confirmed && t.missed>3) || (t.confirmed && t.missed>MAX_MISSED_FRAMES+30)) tracks.remove(i);
        }
        float average=0f; int visibleCount=0;
        for (TrackedBox b:visible) { average+=b.confidence; visibleCount++; }
        average=visibleCount==0?0f:average/visibleCount;
        float continuity=ordered.isEmpty()?0f:(float)matchedCount/Math.max(1,ordered.size());
        float frameConfidence=visible.isEmpty()?0f:clamp(average*(0.76f+0.24f*continuity));
        return new Update(Collections.unmodifiableList(visible),events,frameConfidence);
    }

    public void reset() { tracks.clear(); nextId=2; nextPendingId=1; }
    private String makeId(int number) { return lockedMasterLineage?String.format(Locale.US,"PILE-%02d",number):String.format(Locale.US,"S%02d",number); }

    private Track findSplitParent(DetectionCandidate d,List<Track> previous) {
        Track best=null; float bestDistance=Float.MAX_VALUE;
        float candidateArea=Math.max(1e-5f,d.area());
        for (Track t:previous) {
            if (!t.confirmed || (!t.master && t.missed>MAX_MISSED_FRAMES)) continue;
            float parentArea=Math.max(1e-5f,(t.right-t.left)*(t.bottom-t.top));
            float parentScale=Math.max(t.right-t.left,t.bottom-t.top);
            // Child contours need to be meaningfully smaller than the parent pile.
            if (candidateArea>parentArea*0.62f) continue;
            float inter=intersectionArea(d.left,d.top,d.right,d.bottom,t.left,t.top,t.right,t.bottom);
            float contained=inter/candidateArea;
            float outside=1f-contained;
            // A rectangle sitting inside a locked pile is a texture/detail proposal, not a child.
            if (contained>MAX_PARENT_CONTAINMENT || outside<MIN_CHILD_OUTSIDE_FRACTION) continue;
            float gap=rectGap(d,t);
            float contactTolerance=Math.max(0.0035f,parentScale*0.025f);
            // A new child must be seen touching/crossing a known parent's boundary. A distant
            // contour already sitting elsewhere in the work area cannot join the lineage.
            if (gap>contactTolerance) continue;
            float cx=d.centerX(),cy=d.centerY();
            float parentCx=(t.left+t.right)*0.5f,parentCy=(t.top+t.bottom)*0.5f;
            float dist=(float)Math.hypot(cx-parentCx,cy-parentCy);
            float maxLinkDistance=Math.max(0.025f,parentScale*0.78f);
            if (dist>maxLinkDistance) continue;
            if (dist<bestDistance) { best=t; bestDistance=dist; }
        }
        return best;
    }

    private void updateSeparationEvidence(Track child,DetectionCandidate d,List<Track> previous) {
        Track parent=findById(previous,child.parentId);
        if (parent==null) return;
        float candidateArea=Math.max(1e-5f,d.area());
        float inside=intersectionArea(d.left,d.top,d.right,d.bottom,parent.left,parent.top,parent.right,parent.bottom)/candidateArea;
        float outside=1f-inside;
        float gap=rectGap(d,parent);
        float parentScale=Math.max(parent.right-parent.left,parent.bottom-parent.top);
        float minGap=Math.max(0.004f,parentScale*0.025f);
        float movedFromBirth=(float)Math.hypot(d.centerX()-child.birthCenterX,d.centerY()-child.birthCenterY);
        boolean gapProgress=gap-child.birthParentGap>=minGap;
        boolean movedAway=movedFromBirth>=Math.max(0.008f,parentScale*0.06f) || gapProgress;
        boolean clearlyDetached=gap>=minGap && outside>=0.95f && movedAway;
        if (clearlyDetached) child.separationFrames++;
        else child.separationFrames=Math.max(0,child.separationFrames-1);
    }

    private Track findById(List<Track> values,String id) {
        if(id==null)return null;
        for(Track t:values)if(id.equals(t.id))return t;
        return null;
    }

    private boolean looksLikeWholeMaster(DetectionCandidate d,Track t) {
        float masterArea=Math.max(1e-5f,(t.right-t.left)*(t.bottom-t.top));
        float ratio=d.area()/masterArea;
        // Permit a plausible shrink as pieces leave the original pile, but not tiny child contours.
        if (ratio < 0.38f || ratio > 2.4f) return false;
        float distance=(float)Math.hypot(d.centerX()-(t.left+t.right)*0.5f,d.centerY()-(t.top+t.bottom)*0.5f);
        float scale=Math.max(t.right-t.left,t.bottom-t.top);
        float overlap=iou(d.left,d.top,d.right,d.bottom,t.left,t.top,t.right,t.bottom);
        // A shrinking Pile 1 should remain overlapped and near its prior location. A child that
        // detached to the edge must not take the root identity just because it is bright.
        return (overlap>=0.42f && distance<=Math.max(0.02f,scale*0.45f))
                || (overlap>=0.25f && distance<=Math.max(0.012f,scale*0.18f));
    }

    private float associationScore(DetectionCandidate d,Track t) {
        float overlap=iou(d.left,d.top,d.right,d.bottom,t.left,t.top,t.right,t.bottom);
        float dx=d.centerX()-(t.left+t.right)*0.5f,dy=d.centerY()-(t.top+t.bottom)*0.5f;
        float distance=(float)Math.sqrt(dx*dx+dy*dy);
        float dw=Math.max(d.width(),t.right-t.left),dh=Math.max(d.height(),t.bottom-t.top);
        float scale=Math.max(dw,dh);
        if (lockedMasterLineage && !t.master && overlap<0.02f && distance>Math.max(0.012f,scale*0.65f)) return 0f;
        float gate=Math.max(0.025f,0.75f*scale);
        if(distance>gate*2.5f && overlap<0.05f)return 0f;
        float distanceScore=Math.max(0f,1f-distance/(gate*2.5f));
        float a1=Math.max(1e-5f,d.area()),a2=Math.max(1e-5f,(t.right-t.left)*(t.bottom-t.top));
        float ratio=Math.max(a1,a2)/Math.min(a1,a2);
        float sizeScore=ratio>8f?0f:1f-(ratio-1f)/8f;
        return 0.62f*overlap+0.27f*distanceScore+0.11f*sizeScore;
    }

    private float intersectionArea(float al,float at,float ar,float ab,float bl,float bt,float br,float bb) {
        float l=Math.max(al,bl),t=Math.max(at,bt),r=Math.min(ar,br),b=Math.min(ab,bb);
        return Math.max(0f,r-l)*Math.max(0f,b-t);
    }
    private float rectGap(DetectionCandidate d,Track t) {
        float dx=Math.max(0f,Math.max(t.left-d.right,d.left-t.right));
        float dy=Math.max(0f,Math.max(t.top-d.bottom,d.top-t.bottom));
        return (float)Math.hypot(dx,dy);
    }
    private float iou(float al,float at,float ar,float ab,float bl,float bt,float br,float bb) {
        float inter=intersectionArea(al,at,ar,ab,bl,bt,br,bb);
        float aa=Math.max(0f,ar-al)*Math.max(0f,ab-at),ba=Math.max(0f,br-bl)*Math.max(0f,bb-bt);
        float union=aa+ba-inter; return union<=0f?0f:inter/union;
    }
    private float clamp(float v) { return Math.max(0f,Math.min(100f,v)); }
    private float clamp01(float v) { return Math.max(0f,Math.min(1f,v)); }

    private static final class Track {
        String id,parentId; float left,top,right,bottom,confidence; int missed,hits,separationFrames;
        float birthCenterX,birthCenterY,birthParentGap,birthParentScale;
        boolean confirmed,master;
        Track copy() { Track c=new Track();c.id=id;c.parentId=parentId;c.left=left;c.top=top;c.right=right;c.bottom=bottom;c.confidence=confidence;c.missed=missed;c.hits=hits;c.separationFrames=separationFrames;c.birthCenterX=birthCenterX;c.birthCenterY=birthCenterY;c.birthParentGap=birthParentGap;c.birthParentScale=birthParentScale;c.confirmed=confirmed;c.master=master;return c; }
    }
}
