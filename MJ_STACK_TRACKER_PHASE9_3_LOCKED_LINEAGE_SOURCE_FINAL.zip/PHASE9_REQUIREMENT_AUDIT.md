# Phase 9.3 Locked-Lineage Tracking Audit

## Problem corrected from Phase 9.2 testing
The Phase 9.2 run created numerous Pile IDs because any high-scoring neutral contour near an existing track could become a child after persistence. Persisting alone is not evidence that a physical pile split from the locked object. A stationary nested contour or background rectangle could inflate History. The original yellow manual-lock outline also stayed pinned at the lock coordinates during analysis, which could be confused with a live tracking marker.

## Phase 9.3 changes
- The user-selected object remains the lineage root, `PILE-01`.
- In locked-lineage mode, a child candidate must be smaller than its parent, extend meaningfully outside the parent's box, and be observed touching/crossing a confirmed parent's boundary. A distant contour or one contained inside the parent is rejected.
- At most one pending child can start from a given parent in one processed frame, reducing nested-contour burst creation.
- Pending contours are private/internal: they do not create History events or consume public Pile numbers.
- The child must persist across at least three processed frames and then be spatially separated from its parent across multiple frames before it is confirmed and assigned `PILE-02`, `PILE-03`, etc.
- Confirmed children can become parents for later child piles only through the same boundary-link and separation gate.
- The original root's association allows plausible shrinkage while retaining overlap/centre proximity; a detached small child cannot take over the root identity.
- The fixed manual-lock rectangle is hidden during analysis. A tracked box is drawn only when a current frame contour associates with that track; a missing target's stale rectangle is hidden instead of appearing pinned to the original coordinates. Pending false candidates do not draw green tracking boxes.
- Unit tests cover distant contours, contained contours, stationary edge contours, a child separating from its parent, root identity, and suppressing extra pile IDs.

## Count and accuracy boundary
Pile-count values remain geometric estimates based on calibrated projected height or relative image height. They are not ground-truth counts, and 0.33 mm nominal piece thickness does not solve perspective by itself. The confirmed inventory ledger remains separate from automatic estimates. This is still OpenCV contour proposal tracking, not a trained semantic classifier, so real-video validation remains necessary. A candidate that never separates is intentionally not promoted to a public pile even if it remains visually stable.

## Build status
The source ZIP and workflow have static/file-integrity validation; source-level tracker smoke tests are run separately. A successful Android/JDK/Gradle build is not claimed until GitHub Actions passes `testDebugUnitTest` and `assembleDebug`.
