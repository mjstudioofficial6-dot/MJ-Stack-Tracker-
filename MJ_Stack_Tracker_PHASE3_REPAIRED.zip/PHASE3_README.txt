MJ Stack Tracker — Phase 3: Sequential Frame Analysis + Persistent History

Preserved from the proven Phase 1 baseline:
- local video picker and Media3 player
- landscape 16:9 video viewport and white controls area
- no camera permission, no broad storage permission, no internet permission

Added in Phase 3:
- bundled OpenCV 4.14.0 AAR for offline image processing
- sequential frame-index analysis on Android API 28+ where frame indexing is supported
- timestamp-based sampling fallback on API 26–27
- one frame at a time; no full-video bitmap cache
- experimental low-saturation/bright-contour proposal detector in the lower part of the frame
- greedy frame-to-frame box association and short-gap track retention
- stable candidate IDs S01, S02, ... during a run, with pending-review events for new/lost candidates
- local SQLite history: session, each processed frame, candidate boxes, confidence, and candidate events
- history updates every five processed frames and every frame observation is committed as it is processed
- slow review speeds 0.25x, 0.5x, 0.75x, and 1.0x
- overlay queries the stored record at or before the current video position to keep review timestamp-linked
- heuristic tracking-confidence percent under each saved history entry

Very important limitations of this phase:
- The detector is a classical contour proposal heuristic, NOT a trained stack/object detector.
- It may detect text, highlights, white equipment or only part of a pile; all candidate events are unconfirmed.
- Displayed percentage is a heuristic confidence score, NOT verified accuracy. True accuracy requires labelled ground truth.
- No verified millimetre scale, table-plane homography, 3D pose, 416-layer projection, exact count, or automatic split/merge ledger yet.
- Indexed-frame timestamps are estimated from frame index and duration; variable-frame-rate sources need a later PTS-accurate decoder pipeline for tighter synchronization.
- Analysis may take much longer than video playback. The screen stays offline and processing can be stopped; frames already stored stay in local history.

Acceptance tests:
1. GitHub Actions build succeeds and produces debug APK.
2. App installs and opens without camera/storage/internet permissions.
3. Select a recorded local video; playback, pause, seek and Clear work.
4. Each speed button changes review playback speed.
5. Start Analyze Frames; progress increases and does not freeze the UI.
6. Stop analysis; the session status changes to STOPPED and saved observations remain.
7. Let a short video finish; session status becomes COMPLETED.
8. Close/reopen app; saved sessions and confidence percentages remain in history.
9. Play and seek the analyzed video; stored candidate boxes follow saved timestamps.
10. OpenCV contour candidates are treated as proposals only. Do not claim exact stack count or true accuracy from this phase.


Build repair note (Phase 3 repaired package):
- Fixed OpenCV Java color conversion. RGBA is converted to RGB, then RGB to HSV.
- The RGB Mat is declared outside the try block so cleanup in finally compiles and runs.
- The contour detector remains an experimental candidate detector, not a trained stack detector.
- Build result must still be verified using the supplied GitHub Actions workflow.
