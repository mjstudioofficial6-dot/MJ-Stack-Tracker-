package com.mj.stacktracker;

import android.graphics.Bitmap;
import android.util.Log;

import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Phase 3 experimental proposal detector.
 * It proposes light, compact contours in the lower/table part of a frame.
 * This is NOT a trained object detector and must not be treated as proven
 * stack recognition or exact piece counting. Calibration and a task-trained
 * segmenter are separate later phases.
 */
public final class FrameDetector {
    private static final int MAX_WIDTH = 640;
    private static final float TABLE_ROI_TOP = 0.40f;

    public List<DetectionCandidate> detect(Bitmap source) {
        List<DetectionCandidate> result = new ArrayList<>();
        if (source == null || source.isRecycled() || source.getWidth() < 32 || source.getHeight() < 32) {
            return result;
        }

        Bitmap scaled = null;
        Mat rgba = new Mat();
        Mat rgb = new Mat();
        Mat hsv = new Mat();
        Mat mask = new Mat();
        Mat kernel = null;
        Mat contourInput = null;
        Mat hierarchy = new Mat();
        List<MatOfPoint> contours = new ArrayList<>();
        try {
            float scale = Math.min(1f, MAX_WIDTH / (float) source.getWidth());
            int w = Math.max(64, Math.round(source.getWidth() * scale));
            int h = Math.max(64, Math.round(source.getHeight() * scale));
            scaled = Bitmap.createScaledBitmap(source, w, h, true);
            Utils.bitmapToMat(scaled, rgba);
            Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB);
            Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV);

            // Cards/stacks tend to be bright and low-saturation; this is only
            // a proposal mask. Logos, reflections and other white objects may
            // also pass, which is why temporal and confidence gates are needed.
            Core.inRange(hsv, new Scalar(0, 0, 85), new Scalar(180, 68, 255), mask);
            int roiY = Math.max(0, Math.min(h - 1, Math.round(h * TABLE_ROI_TOP)));
            if (roiY > 0) {
                Mat excluded = mask.submat(0, roiY, 0, w);
                excluded.setTo(new Scalar(0));
                excluded.release();
            }

            kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(5, 9));
            Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_CLOSE, kernel);
            contourInput = mask.clone();
            Imgproc.findContours(contourInput, contours, hierarchy,
                    Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE);

            double imageArea = (double) w * h;
            double minArea = Math.max(55.0, imageArea * 0.00012);
            double maxArea = imageArea * 0.045;

            for (MatOfPoint contour : contours) {
                double contourArea = Imgproc.contourArea(contour);
                if (contourArea < minArea || contourArea > maxArea) continue;
                Rect r = Imgproc.boundingRect(contour);
                if (r.width < 8 || r.height < 5) continue;
                if (r.width > w * 0.34 || r.height > h * 0.32) continue;
                if (r.y < roiY) continue;

                float aspect = r.width / (float) r.height;
                if (aspect < 0.22f || aspect > 5.2f) continue;
                double boxArea = Math.max(1.0, (double) r.width * r.height);
                float fill = (float) Math.max(0.0, Math.min(1.0, contourArea / boxArea));

                Rect safe = new Rect(Math.max(0, r.x), Math.max(0, r.y),
                        Math.min(r.width, w - Math.max(0, r.x)),
                        Math.min(r.height, h - Math.max(0, r.y)));
                if (safe.width <= 0 || safe.height <= 0) continue;
                Mat patch = mask.submat(safe);
                float whiteCoverage = (float) Core.countNonZero(patch) / (float) (safe.width * safe.height);
                patch.release();

                // Broad shape prior: do not hard-code one orientation because
                // piles may lie flat or stand upright.
                float aspectScore = (aspect >= 0.35f && aspect <= 3.5f) ? 1f : 0.55f;
                float fillScore = Math.min(1f, fill / 0.62f);
                float coverageScore = Math.min(1f, whiteCoverage / 0.60f);
                float relativeArea = (float) (boxArea / imageArea);
                float areaScore = (float) Math.max(0.25, Math.min(1.0, relativeArea / 0.006));
                float score = 100f * (0.28f * fillScore + 0.42f * coverageScore
                        + 0.15f * aspectScore + 0.15f * areaScore);

                // Remove very weak proposals but keep moderate confidence so
                // history can document that the frame was uncertain.
                if (score < 29f) continue;
                result.add(new DetectionCandidate(r.x / (float) w, r.y / (float) h,
                        (r.x + r.width) / (float) w, (r.y + r.height) / (float) h, score));
            }

            result.sort(Comparator.comparingDouble((DetectionCandidate c) -> c.detectorScore).reversed());
            return suppressOverlaps(result, 24);
        } catch (Exception error) {
            Log.w("MJStackFrameDetector", "Frame contour analysis failed", error);
            return result;
        } finally {
            for (MatOfPoint c : contours) c.release();
            rgba.release();
            rgb.release();
            hsv.release();
            mask.release();
            hierarchy.release();
            if (kernel != null) kernel.release();
            if (contourInput != null) contourInput.release();
            if (scaled != null && scaled != source && !scaled.isRecycled()) scaled.recycle();
        }
    }

    private List<DetectionCandidate> suppressOverlaps(List<DetectionCandidate> input, int max) {
        List<DetectionCandidate> kept = new ArrayList<>();
        for (DetectionCandidate candidate : input) {
            boolean duplicate = false;
            for (DetectionCandidate prior : kept) {
                if (iou(candidate, prior) > 0.42f) {
                    duplicate = true;
                    break;
                }
            }
            if (!duplicate) kept.add(candidate);
            if (kept.size() >= max) break;
        }
        return kept;
    }

    private float iou(DetectionCandidate a, DetectionCandidate b) {
        float l = Math.max(a.left, b.left), t = Math.max(a.top, b.top);
        float r = Math.min(a.right, b.right), bt = Math.min(a.bottom, b.bottom);
        float inter = Math.max(0f, r - l) * Math.max(0f, bt - t);
        float union = a.area() + b.area() - inter;
        return union <= 0f ? 0f : inter / union;
    }
}
