# Phase 9.4.1 — Manifest Hotfix and Phase 9.4 Requirement Audit

## Build failure confirmed from the user's GitHub screenshots

The failing task was `:app:processDebugMainManifest`. The exception named `app/src/main/AndroidManifest.xml`; the previous manifest had a literal ampersand in the label: `Geometry & Lineage 9.4`. In XML attributes, a raw `&` begins an entity reference, so the XML parser rejects that line. The label now uses `Geometry &amp; Lineage 9.4.1`.

The Phase 9.4.1 workflow adds a pre-build XML parse pass for every `.xml` file in the source archive. It reports the exact archive entry and parser location if malformed XML is introduced again.

## Phase 9.4 tracking/measurement controls retained

- The locked original object is the lineage root **Pile 1**. Its tracking rectangle is updated from predicted motion and matched detections; it is not deliberately left at the initial lock coordinates.
- A single parent may have multiple confirmed children, and a confirmed child can itself split, retaining parent IDs in lineage history.
- New pile IDs require parent-linked evidence, persistence and visible separation. Unrelated or fully nested contours are gated.
- A pile that is hidden or leaves the visible work area stops drawing a live tracking box, while its history identity and last known count remain. Invisibility is not treated as removal.
- Possible merge/occlusion is recorded for review rather than silently deleting the pile.
- Rotated bounding dimensions are projected onto a calibrated stack-height axis; counts derive from measured geometry and calibration rather than hard-coded example quantities.
- The app does not force visual estimates to add up to the known inventory. Inconsistent counts/calibration are flagged for review.

## Limits that remain

The front end uses classical OpenCV contours, not semantic whole-pile segmentation. A visible contour can describe only a face or a partial stack; hands, overlap, blur, perspective, and similar-looking touching piles can still cause tracking or counting errors. Calibration is a local 2D scale, not complete perspective-correct 3D reconstruction. A passing build is not proof of exact measurement accuracy; a short labelled-video test remains essential.
