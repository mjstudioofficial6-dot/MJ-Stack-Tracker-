# Phase 9.5 Precision Engine Integration Audit

- Preserved Phase 9.4.1 app source and existing pile-lineage/count-estimate algorithms.
- Added a local Android library module `:cardchange-engine`.
- Added a dependency from `:app` to `:cardchange-engine`.
- Integrated precision evidence into the video-analysis frame loop.
- Added manual signature labelling for exactly 1, 2, or 3 removed cards.
- Learned signatures are stored on-device in SharedPreferences.
- A signature match requires manual confirmation.
- The precision engine does not automatically modify existing pile counts or conservation ledger values.
- Kept package ID `com.mj.stacktracker.phase9` for upgrade compatibility.
- Increased versionCode 14 -> 15 and versionName 0.9.4.1 -> 0.9.5.
- Retained compileSdk 36, Java 17, Media3, OpenCV, file-provider, history, and export dependencies.
- No camera or Internet permission introduced.

## Validation boundary

The archive structure, source-level invariants, XML, and engine unit tests are checked by the paired GitHub Actions workflow. A successful CI build proves compilation and packaged tests, not empirical accuracy on the user's 720p recording. Real-video validation is still required before treating learned signatures or automatic matches as reliable.
