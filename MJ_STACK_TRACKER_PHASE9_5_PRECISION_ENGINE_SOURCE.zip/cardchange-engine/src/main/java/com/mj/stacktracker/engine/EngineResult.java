package com.mj.stacktracker.engine;

public final class EngineResult {
    public enum Status {
        WAITING, NO_CHANGE, CHANGE_CANDIDATE, CONFIRMED,
        UNCLASSIFIED_CHANGE, UNCERTAIN
    }

    public final Status status;
    public final int removedCards;
    public final double confidence;
    public final double profileDistance;
    public final double reprojectionError;
    public final int trackedAnchors;
    public final String message;
    public final float[] signature;

    public EngineResult(Status status,int removedCards,double confidence,double profileDistance,
                        double reprojectionError,int trackedAnchors,String message,float[] signature){
        this.status=status;this.removedCards=removedCards;this.confidence=confidence;
        this.profileDistance=profileDistance;this.reprojectionError=reprojectionError;
        this.trackedAnchors=trackedAnchors;this.message=message;this.signature=signature;
    }
}
