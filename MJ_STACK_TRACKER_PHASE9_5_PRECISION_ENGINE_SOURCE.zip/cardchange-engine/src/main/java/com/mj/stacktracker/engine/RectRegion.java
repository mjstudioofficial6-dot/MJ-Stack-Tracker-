package com.mj.stacktracker.engine;

import android.graphics.RectF;

public final class RectRegion {
    public final int left, top, right, bottom;

    public RectRegion(int left, int top, int right, int bottom) {
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
    }

    public int width() { return Math.max(0, right - left); }
    public int height() { return Math.max(0, bottom - top); }
    public boolean isValid() { return width() >= 24 && height() >= 16; }

    public static RectRegion fromNormalized(RectF n, int width, int height) {
        if (n == null || width < 2 || height < 2 ||
                !Float.isFinite(n.left) || !Float.isFinite(n.top) ||
                !Float.isFinite(n.right) || !Float.isFinite(n.bottom)) {
            throw new IllegalArgumentException("Invalid normalized ROI");
        }
        float left = Math.max(0f, Math.min(1f, Math.min(n.left, n.right)));
        float top = Math.max(0f, Math.min(1f, Math.min(n.top, n.bottom)));
        float right = Math.max(0f, Math.min(1f, Math.max(n.left, n.right)));
        float bottom = Math.max(0f, Math.min(1f, Math.max(n.top, n.bottom)));
        int l = clamp((int)Math.floor(left * width), 0, width - 1);
        int t = clamp((int)Math.floor(top * height), 0, height - 1);
        int r = clamp((int)Math.ceil(right * width), l + 1, width);
        int b = clamp((int)Math.ceil(bottom * height), t + 1, height);
        return new RectRegion(l, t, r, b);
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}
