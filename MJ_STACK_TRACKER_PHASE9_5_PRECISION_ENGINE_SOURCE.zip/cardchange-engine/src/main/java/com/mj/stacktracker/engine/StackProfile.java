package com.mj.stacktracker.engine;

import java.util.Arrays;

public final class StackProfile {
    public final float[] vector;
    public final double edgeEnergy;
    public final double brightness;

    private StackProfile(float[] vector,double edgeEnergy,double brightness) {
        this.vector=vector; this.edgeEnergy=edgeEnergy; this.brightness=brightness;
    }

    public static StackProfile measure(WarpedPatch patch) {
        if(patch.width<8||patch.height<8) throw new IllegalArgumentException("ROI too small");
        int yBins=48, xBins=32;
        double[] rows=new double[yBins], cols=new double[xBins];
        double[] rowEdges=new double[yBins], colEdges=new double[xBins];
        double mean=0; int n=0;
        for(float v:patch.pixels){mean+=v;n++;}
        mean/=Math.max(1,n);
        double variance=0;
        for(float v:patch.pixels){double d=v-mean;variance+=d*d;}
        double std=Math.sqrt(variance/Math.max(1,n))+1e-5;

        for(int b=0;b<yBins;b++){
            int y0=b*patch.height/yBins;
            int y1=Math.max(y0+1,(b+1)*patch.height/yBins);
            double s=0,e=0;int c=0;
            for(int y=y0;y<Math.min(patch.height,y1);y++)
                for(int x=1;x<patch.width-1;x++){
                    s+=patch.get(x,y);
                    e+=Math.abs(patch.get(x,y)-patch.get(x,y-1));
                    c++;
                }
            rows[b]=s/Math.max(1,c);
            rowEdges[b]=e/Math.max(1,c);
        }
        for(int b=0;b<xBins;b++){
            int x0=b*patch.width/xBins;
            int x1=Math.max(x0+1,(b+1)*patch.width/xBins);
            double s=0,e=0;int c=0;
            for(int x=x0;x<Math.min(patch.width,x1);x++)
                for(int y=1;y<patch.height-1;y++){
                    s+=patch.get(x,y);
                    e+=Math.abs(patch.get(x,y)-patch.get(x-1,y));
                    c++;
                }
            cols[b]=s/Math.max(1,c);
            colEdges[b]=e/Math.max(1,c);
        }

        float[] vector=new float[yBins*2+xBins*2];
        int k=0;
        k=appendZ(vector,k,rows);
        k=appendZ(vector,k,rowEdges);
        k=appendZ(vector,k,cols);
        appendZ(vector,k,colEdges);
        double edge=0;
        for(double v:rowEdges)edge+=v;
        for(double v:colEdges)edge+=v;
        return new StackProfile(vector,edge/(yBins+xBins),mean);
    }

    private static int appendZ(float[] out,int offset,double[] values) {
        double m=0;for(double v:values)m+=v;m/=values.length;
        double s=0;for(double v:values){double d=v-m;s+=d*d;}
        s=Math.sqrt(s/values.length)+1e-6;
        for(double v:values)out[offset++]=(float)((v-m)/s);
        return offset;
    }

    public static double distance(StackProfile a,StackProfile b) {
        int n=Math.min(a.vector.length,b.vector.length);
        if(n==0)return 1;
        double dot=0,aa=0,bb=0;
        for(int i=0;i<n;i++){
            double x=a.vector[i],y=b.vector[i];
            dot+=x*y;aa+=x*x;bb+=y*y;
        }
        double corr=dot/(Math.sqrt(aa*bb)+1e-9);
        double mse=0;
        for(int i=0;i<n;i++){double d=a.vector[i]-b.vector[i];mse+=d*d;}
        mse/=n;
        return Math.max(0,Math.min(1,0.65*(1-corr)/2.0+0.35*Math.sqrt(mse)/4.0));
    }

    public float[] differenceVector(StackProfile reference) {
        int n=Math.min(vector.length,reference.vector.length);
        float[] out=new float[n];
        for(int i=0;i<n;i++)out[i]=Math.abs(vector[i]-reference.vector[i]);
        return out;
    }
}
