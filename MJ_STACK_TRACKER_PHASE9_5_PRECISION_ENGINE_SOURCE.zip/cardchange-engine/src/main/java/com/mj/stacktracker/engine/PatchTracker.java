package com.mj.stacktracker.engine;

public final class PatchTracker {
    public static final class Match {
        public final Point2 point;
        public final double score;
        Match(Point2 point, double score) { this.point = point; this.score = score; }
    }

    private final int patchRadius;
    private final int searchRadius;

    public PatchTracker(int patchRadius, int searchRadius) {
        this.patchRadius = Math.max(2, patchRadius);
        this.searchRadius = Math.max(2, searchRadius);
    }

    public Match track(GrayFrame previous, GrayFrame current, Point2 from) {
        int px=(int)Math.round(from.x), py=(int)Math.round(from.y);
        double best=-2, second=-2;
        Point2 bestPoint=null;
        for(int dy=-searchRadius;dy<=searchRadius;dy++){
            for(int dx=-searchRadius;dx<=searchRadius;dx++){
                int cx=px+dx, cy=py+dy;
                if(cx-patchRadius<1||cy-patchRadius<1||
                        cx+patchRadius>=current.width-1||cy+patchRadius>=current.height-1||
                        px-patchRadius<1||py-patchRadius<1||
                        px+patchRadius>=previous.width-1||py+patchRadius>=previous.height-1) continue;
                double score=zncc(previous,current,px,py,cx,cy);
                if(score>best){
                    second=best;best=score;bestPoint=new Point2(cx,cy);
                } else if(score>second) second=score;
            }
        }
        if(bestPoint==null || best<0.48) return null;
        // Repetitive card edges can have multiple equally good matches; reject ambiguous matches.
        if(second > 0.0 && best-second < 0.002) return null;
        return new Match(bestPoint,best);
    }

    private double zncc(GrayFrame a, GrayFrame b, int ax, int ay, int bx, int by) {
        int size=(patchRadius*2+1)*(patchRadius*2+1);
        double ma=0, mb=0;
        for(int y=-patchRadius;y<=patchRadius;y++)
            for(int x=-patchRadius;x<=patchRadius;x++){
                ma+=a.get(ax+x,ay+y); mb+=b.get(bx+x,by+y);
            }
        ma/=size; mb/=size;
        double num=0, va=0, vb=0;
        for(int y=-patchRadius;y<=patchRadius;y++)
            for(int x=-patchRadius;x<=patchRadius;x++){
                double da=a.get(ax+x,ay+y)-ma;
                double db=b.get(bx+x,by+y)-mb;
                num+=da*db; va+=da*da; vb+=db*db;
            }
        return num/(Math.sqrt(va*vb)+1e-9);
    }
}
