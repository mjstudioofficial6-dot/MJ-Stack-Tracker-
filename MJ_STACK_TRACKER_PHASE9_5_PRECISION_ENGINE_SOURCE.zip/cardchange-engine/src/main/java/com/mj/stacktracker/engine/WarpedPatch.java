package com.mj.stacktracker.engine;

public final class WarpedPatch {
    public final int width, height;
    public final float[] pixels;

    public WarpedPatch(int width, int height, float[] pixels) {
        this.width=width; this.height=height; this.pixels=pixels;
    }

    public float get(int x,int y) {
        if(x<0||y<0||x>=width||y>=height) return 0;
        return pixels[y*width+x];
    }

    public static WarpedPatch fromFrame(GrayFrame frame, RectRegion referenceRoi,
                                        Homography referenceToCurrent) {
        int w=referenceRoi.width(), h=referenceRoi.height();
        float[] out=new float[w*h];
        for(int y=0;y<h;y++){
            for(int x=0;x<w;x++){
                Point2 mapped=referenceToCurrent.map(
                        new Point2(referenceRoi.left+x,referenceRoi.top+y));
                float v=frame.bilinear(mapped.x,mapped.y);
                out[y*w+x]=Float.isNaN(v)?0:v;
            }
        }
        return new WarpedPatch(w,h,out);
    }
}
