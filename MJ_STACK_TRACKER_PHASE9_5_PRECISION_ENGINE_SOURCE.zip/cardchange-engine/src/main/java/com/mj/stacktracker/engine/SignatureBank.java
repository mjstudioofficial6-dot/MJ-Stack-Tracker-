package com.mj.stacktracker.engine;

import java.util.LinkedHashMap;
import java.util.Map;

public final class SignatureBank {
    public static final class Match {
        public final int removedCards;
        public final double distance;
        Match(int removedCards,double distance){this.removedCards=removedCards;this.distance=distance;}
    }

    private final Map<Integer,float[]> templates=new LinkedHashMap<>();

    public synchronized void put(int count,float[] signature) {
        if(count<1||count>20||signature==null||signature.length==0)
            throw new IllegalArgumentException("Invalid card-change signature");
        templates.put(count,signature.clone());
    }

    public synchronized Match match(float[] observed,double maximumDistance) {
        int bestCount=0;double best=Double.POSITIVE_INFINITY;
        for(Map.Entry<Integer,float[]> e:templates.entrySet()){
            float[] t=e.getValue();int n=Math.min(t.length,observed.length);
            if(n==0)continue;
            double d=0;
            for(int i=0;i<n;i++){double x=observed[i]-t[i];d+=x*x;}
            d=Math.sqrt(d/n);
            if(d<best){best=d;bestCount=e.getKey();}
        }
        return bestCount>0&&best<=maximumDistance?new Match(bestCount,best):new Match(0,best);
    }

    public synchronized String serialize() {
        StringBuilder b=new StringBuilder();
        for(Map.Entry<Integer,float[]> e:templates.entrySet()){
            if(b.length()>0)b.append('\n');
            b.append(e.getKey()).append(':');
            float[] a=e.getValue();
            for(int i=0;i<a.length;i++){
                if(i>0)b.append(',');
                b.append(a[i]);
            }
        }
        return b.toString();
    }

    public synchronized void deserialize(String encoded) {
        templates.clear();
        if(encoded==null||encoded.trim().isEmpty())return;
        for(String line:encoded.split("\\n")){
            int colon=line.indexOf(':');
            if(colon<=0)continue;
            try{
                int count=Integer.parseInt(line.substring(0,colon));
                String[] parts=line.substring(colon+1).split(",");
                float[] a=new float[parts.length];
                for(int i=0;i<parts.length;i++)a[i]=Float.parseFloat(parts[i]);
                put(count,a);
            }catch(Exception ignored){}
        }
    }
}
