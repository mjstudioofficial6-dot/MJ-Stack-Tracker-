package com.mj.stacktracker.engine;

import java.util.ArrayList;
import java.util.List;

public final class Homography {
    private final double[] h;

    private Homography(double[] values) {
        if (values == null || values.length != 9) throw new IllegalArgumentException("Homography needs 9 values");
        h = values.clone();
    }

    public static Homography identity() {
        return new Homography(new double[]{1,0,0, 0,1,0, 0,0,1});
    }

    public Point2 map(Point2 p) {
        double d = h[6] * p.x + h[7] * p.y + h[8];
        if (Math.abs(d) < 1e-9) return new Point2(Double.NaN, Double.NaN);
        return new Point2((h[0]*p.x + h[1]*p.y + h[2]) / d,
                (h[3]*p.x + h[4]*p.y + h[5]) / d);
    }

    public Homography multiply(Homography right) {
        double[] a = h, b = right.h, c = new double[9];
        for (int r = 0; r < 3; r++)
            for (int col = 0; col < 3; col++)
                for (int k = 0; k < 3; k++)
                    c[r*3+col] += a[r*3+k] * b[k*3+col];
        return new Homography(c);
    }

    public static final class Fit {
        public final Homography transform;
        public final List<Integer> inliers;
        public final double meanError;
        Fit(Homography transform, List<Integer> inliers, double meanError) {
            this.transform = transform;
            this.inliers = inliers;
            this.meanError = meanError;
        }
    }

    public static Fit fitRansac(List<Point2> from, List<Point2> to, double threshold) {
        if (from.size() != to.size() || from.size() < 4) return null;
        int n = from.size();
        List<Integer> best = new ArrayList<>();
        Homography bestH = null;
        double bestErr = Double.POSITIVE_INFINITY;

        for (int a = 0; a < n - 3; a++) {
            for (int b = a + 1; b < n - 2; b++) {
                for (int c = b + 1; c < n - 1; c++) {
                    for (int d = c + 1; d < n; d++) {
                        int[] ids = {a,b,c,d};
                        List<Point2> f = new ArrayList<>(), t = new ArrayList<>();
                        for (int id : ids) { f.add(from.get(id)); t.add(to.get(id)); }
                        Homography candidate = fitLeastSquares(f, t);
                        if (candidate == null) continue;
                        List<Integer> inliers = new ArrayList<>();
                        double err = 0;
                        for (int i = 0; i < n; i++) {
                            Point2 q = candidate.map(from.get(i));
                            double e = q.distance(to.get(i));
                            if (Double.isFinite(e) && e <= threshold) {
                                inliers.add(i); err += e;
                            }
                        }
                        double mean = inliers.isEmpty() ? Double.POSITIVE_INFINITY : err / inliers.size();
                        if (inliers.size() > best.size() ||
                                (inliers.size() == best.size() && mean < bestErr)) {
                            best = inliers; bestH = candidate; bestErr = mean;
                        }
                    }
                }
            }
        }
        if (best.size() < Math.max(5, (int)Math.ceil(n * 0.55))) return null;

        List<Point2> f = new ArrayList<>(), t = new ArrayList<>();
        for (int i : best) { f.add(from.get(i)); t.add(to.get(i)); }
        Homography refined = fitLeastSquares(f, t);
        if (refined == null) refined = bestH;

        double sum = 0;
        for (int i : best) sum += refined.map(from.get(i)).distance(to.get(i));
        return new Fit(refined, best, sum / best.size());
    }

    private static Homography fitLeastSquares(List<Point2> from, List<Point2> to) {
        if (from.size() < 4) return null;
        double[][] normal = new double[8][8];
        double[] rhs = new double[8];
        for (int i = 0; i < from.size(); i++) {
            Point2 p = from.get(i), q = to.get(i);
            double x=p.x, y=p.y, u=q.x, v=q.y;
            double[] r1 = {x,y,1, 0,0,0, -u*x,-u*y};
            double[] r2 = {0,0,0, x,y,1, -v*x,-v*y};
            addEquation(normal, rhs, r1, u);
            addEquation(normal, rhs, r2, v);
        }
        double[] solution = solve(normal, rhs);
        if (solution == null) return null;
        return new Homography(new double[]{solution[0],solution[1],solution[2],
                solution[3],solution[4],solution[5],solution[6],solution[7],1});
    }

    private static void addEquation(double[][] n, double[] rhs, double[] row, double value) {
        for (int i=0;i<8;i++) {
            rhs[i] += row[i] * value;
            for (int j=0;j<8;j++) n[i][j] += row[i] * row[j];
        }
    }

    private static double[] solve(double[][] a, double[] b) {
        int n=b.length;
        double[][] m=new double[n][n+1];
        for(int i=0;i<n;i++){System.arraycopy(a[i],0,m[i],0,n);m[i][n]=b[i];}
        for(int col=0;col<n;col++){
            int pivot=col;
            for(int r=col+1;r<n;r++) if(Math.abs(m[r][col])>Math.abs(m[pivot][col])) pivot=r;
            if(Math.abs(m[pivot][col])<1e-10)return null;
            double[] tmp=m[col];m[col]=m[pivot];m[pivot]=tmp;
            double div=m[col][col];
            for(int j=col;j<=n;j++)m[col][j]/=div;
            for(int r=0;r<n;r++) if(r!=col){
                double f=m[r][col];
                for(int j=col;j<=n;j++)m[r][j]-=f*m[col][j];
            }
        }
        double[] out=new double[n];
        for(int i=0;i<n;i++)out[i]=m[i][n];
        return out;
    }
}
