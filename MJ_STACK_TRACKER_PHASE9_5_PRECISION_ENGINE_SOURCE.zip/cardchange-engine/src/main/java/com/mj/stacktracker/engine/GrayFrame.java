package com.mj.stacktracker.engine;

import android.graphics.Bitmap;
import android.graphics.Color;

public final class GrayFrame {
    public final int width;
    public final int height;
    public final float[] pixels;

    public GrayFrame(int width, int height, float[] pixels) {
        if (width <= 0 || height <= 0 || pixels == null || pixels.length != width * height) {
            throw new IllegalArgumentException("Invalid grayscale frame");
        }
        this.width = width;
        this.height = height;
        this.pixels = pixels;
    }

    public static GrayFrame fromBitmap(Bitmap source, int maximumWidth) {
        if (source == null) throw new IllegalArgumentException("Bitmap is null");
        if (source.isRecycled()) throw new IllegalArgumentException("Bitmap is recycled");
        if (maximumWidth < 32) throw new IllegalArgumentException("maximumWidth must be at least 32");
        Bitmap b = source;
        boolean recycleScaled = false;
        if (source.getWidth() > maximumWidth) {
            int nw = maximumWidth;
            int nh = Math.max(1, (int)Math.round(source.getHeight() * (nw / (double)source.getWidth())));
            b = Bitmap.createScaledBitmap(source, nw, nh, true);
            recycleScaled = b != source;
        }
        try {
            int w = b.getWidth(), h = b.getHeight();
            int[] argb = new int[w * h];
            b.getPixels(argb, 0, w, 0, 0, w, h);
            float[] gray = new float[w * h];
            for (int i = 0; i < argb.length; i++) {
                int c = argb[i];
                gray[i] = (0.299f * Color.red(c) + 0.587f * Color.green(c) +
                        0.114f * Color.blue(c)) / 255f;
            }
            return new GrayFrame(w, h, gray);
        } finally {
            if (recycleScaled && !b.isRecycled()) b.recycle();
        }
    }

    public float get(int x, int y) {
        if (x < 0 || y < 0 || x >= width || y >= height) return 0f;
        return pixels[y * width + x];
    }

    public float bilinear(double x, double y) {
        if (!Double.isFinite(x) || !Double.isFinite(y) ||
                x < 0 || y < 0 || x >= width - 1 || y >= height - 1) return Float.NaN;
        int x0 = (int)Math.floor(x), y0 = (int)Math.floor(y);
        double fx = x - x0, fy = y - y0;
        double a = get(x0, y0), b = get(x0 + 1, y0);
        double c = get(x0, y0 + 1), d = get(x0 + 1, y0 + 1);
        return (float)((1 - fy) * ((1 - fx) * a + fx * b) +
                fy * ((1 - fx) * c + fx * d));
    }

    public double laplacianVariance(RectRegion roi) {
        int l = Math.max(1, roi.left), t = Math.max(1, roi.top);
        int r = Math.min(width - 1, roi.right), b = Math.min(height - 1, roi.bottom);
        if (r - l < 3 || b - t < 3) return 0;
        double sum = 0, sumSq = 0;
        int n = 0;
        for (int y = t; y < b; y += 2) {
            for (int x = l; x < r; x += 2) {
                double v = 4 * get(x, y) - get(x - 1, y) - get(x + 1, y)
                        - get(x, y - 1) - get(x, y + 1);
                sum += v;
                sumSq += v * v;
                n++;
            }
        }
        if (n == 0) return 0;
        double mean = sum / n;
        return Math.max(0, sumSq / n - mean * mean);
    }

    public double mean(RectRegion roi) {
        int l = Math.max(0, roi.left), t = Math.max(0, roi.top);
        int r = Math.min(width, roi.right), b = Math.min(height, roi.bottom);
        double sum = 0; long n = 0;
        for (int y = t; y < b; y += 2) {
            for (int x = l; x < r; x += 2) {
                sum += get(x, y);
                n++;
            }
        }
        return n == 0 ? 0 : sum / n;
    }
}
