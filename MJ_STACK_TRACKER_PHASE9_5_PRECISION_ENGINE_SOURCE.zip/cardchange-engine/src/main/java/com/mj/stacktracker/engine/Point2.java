package com.mj.stacktracker.engine;

public final class Point2 {
    public final double x;
    public final double y;

    public Point2(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double distance(Point2 p) {
        return Math.hypot(x - p.x, y - p.y);
    }
}
