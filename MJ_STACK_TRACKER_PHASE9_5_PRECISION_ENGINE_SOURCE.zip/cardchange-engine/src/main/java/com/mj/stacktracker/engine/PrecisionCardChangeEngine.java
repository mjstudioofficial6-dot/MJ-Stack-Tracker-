package com.mj.stacktracker.engine;

import android.graphics.Bitmap;
import android.graphics.RectF;
import java.util.ArrayList;
import java.util.List;

public final class PrecisionCardChangeEngine {
    public static final class Config {
        public int maximumAnalysisWidth=480;
        public int patchRadius=4;
        public int featureSearchRadius=22;
        public int minimumAnchors=5;
        public double ransacThresholdPixels=4.0;
        public double minimumSharpness=0.00035;
        public double changeThreshold=0.105;
        public double signatureMatchThreshold=0.42;
        public int persistentSamples=3;
    }

    private final Config config;
    private final PatchTracker patchTracker;
    private final SignatureBank signatureBank=new SignatureBank();

    private GrayFrame referenceFrame;
    private GrayFrame previousFrame;
    private RectRegion referenceRoi;
    private List<Point2> referenceAnchors=new ArrayList<>();
    private List<Point2> previousAnchors=new ArrayList<>();
    private Homography referenceToCurrent=Homography.identity();
    private StackProfile referenceProfile;
    private StackProfile previousCandidateProfile;
    private float[] pendingSignature;
    private GrayFrame pendingFrame;
    private Homography pendingTransform;
    private RectRegion pendingRoi;
    private int candidatePersistence=0;
    private boolean awaitingManualResolution=false;

    public PrecisionCardChangeEngine() { this(new Config()); }

    public PrecisionCardChangeEngine(Config config) {
        this.config = config == null ? new Config() : config;
        if (this.config.maximumAnalysisWidth < 64 || this.config.minimumAnchors < 4 ||
                this.config.minimumAnchors > 9 || this.config.persistentSamples < 2 ||
                this.config.ransacThresholdPixels <= 0 || this.config.changeThreshold <= 0 ||
                this.config.signatureMatchThreshold <= 0) {
            throw new IllegalArgumentException("Invalid precision-engine configuration");
        }
        this.patchTracker=new PatchTracker(this.config.patchRadius,this.config.featureSearchRadius);
    }

    public synchronized void loadSignatures(String data) {
        signatureBank.deserialize(data);
    }

    public synchronized String saveSignatures() {
        return signatureBank.serialize();
    }

    public synchronized boolean isLocked() { return referenceFrame!=null; }

    public synchronized void lockReference(Bitmap bitmap,RectF normalizedRoi) {
        if (bitmap == null || bitmap.isRecycled()) throw new IllegalArgumentException("A valid frame is required.");
        if (normalizedRoi == null) throw new IllegalArgumentException("A locked stack ROI is required.");
        GrayFrame frame=GrayFrame.fromBitmap(bitmap,config.maximumAnalysisWidth);
        RectF n=new RectF(normalizedRoi);
        RectRegion roi=RectRegion.fromNormalized(n,frame.width,frame.height);
        if(!roi.isValid())throw new IllegalArgumentException("Lock Object area is too small.");
        // Keep the user-selected frame as the reference even if its detail is weak.
        // Subsequent frames are quality-gated; a single blurred starting frame must not
        // disable the entire video analysis session.
        setReference(frame,roi);
    }

    public synchronized EngineResult analyze(Bitmap bitmap) {
        if (bitmap == null || bitmap.isRecycled())
            return result(EngineResult.Status.UNCERTAIN,0,0,1,999,0,"Invalid frame rejected.",null);
        if(referenceFrame==null)
            return result(EngineResult.Status.UNCERTAIN,0,0,1,999,0,"Lock Object first.",null);
        if(awaitingManualResolution)
            return result(EngineResult.Status.UNCERTAIN,0,0,1,999,0,
                    "A detected change needs a known 1/2/3+ label before continuing.",pendingSignature);

        GrayFrame current=GrayFrame.fromBitmap(bitmap,config.maximumAnalysisWidth);
        if(current.width!=referenceFrame.width || current.height!=referenceFrame.height){
            return result(EngineResult.Status.UNCERTAIN,0,0,1,999,0,
                    "Frame size changed; analysis paused.",null);
        }

        double sharpness=current.laplacianVariance(mapRoi(referenceToCurrent,referenceRoi));
        if(sharpness<config.minimumSharpness){
            // Keep the last geometrically consistent frame; a rejected blurred frame
            // must not become the tracking origin for the next sample.
            return result(EngineResult.Status.UNCERTAIN,0,0,1,999,0,
                    "Blur/low-detail frame rejected.",null);
        }

        List<Point2> from=new ArrayList<>(),to=new ArrayList<>();
        int good=0;
        for(Point2 prev:previousAnchors){
            PatchTracker.Match m=patchTracker.track(previousFrame,current,prev);
            if(m!=null){
                from.add(prev);to.add(m.point);good++;
            }
        }
        if(good<config.minimumAnchors){
            return result(EngineResult.Status.UNCERTAIN,0,0,1,999,good,
                    "Object tracking is not reliable; wait for a clear stable view.",null);
        }

        Homography.Fit step=Homography.fitRansac(from,to,config.ransacThresholdPixels);
        if(step==null || step.inliers.size()<config.minimumAnchors){
            return result(EngineResult.Status.UNCERTAIN,0,0,1,999,good,
                    "Perspective tracking failed quality check.",null);
        }

        referenceToCurrent=step.transform.multiply(referenceToCurrent);
        // Re-seed the original anchor grid through the accumulated transform instead
        // of permanently shrinking the tracker to only the current frame's inliers.
        // This lets a temporarily weak patch recover on a later clear frame.
        List<Point2> refreshedAnchors=new ArrayList<>();
        for(Point2 referenceAnchor:referenceAnchors){
            Point2 mapped=referenceToCurrent.map(referenceAnchor);
            if(Double.isFinite(mapped.x)&&Double.isFinite(mapped.y)&&
                    mapped.x>config.patchRadius+1&&mapped.y>config.patchRadius+1&&
                    mapped.x<current.width-config.patchRadius-1&&
                    mapped.y<current.height-config.patchRadius-1){
                refreshedAnchors.add(mapped);
            }
        }
        previousAnchors=refreshedAnchors;
        previousFrame=current;

        RectRegion currentRoi=mapRoi(referenceToCurrent,referenceRoi);
        double currentSharpness=current.laplacianVariance(currentRoi);
        if(currentSharpness<config.minimumSharpness){
            // The homography is valid, so this frame can still advance tracking;
            // but its profile is not used as evidence.
            return result(EngineResult.Status.UNCERTAIN,0,0,1,step.meanError,step.inliers.size(),
                    "Tracked stack area is blurred or obstructed.",null);
        }

        WarpedPatch normalized=WarpedPatch.fromFrame(current,referenceRoi,referenceToCurrent);
        StackProfile profile=StackProfile.measure(normalized);
        double distance=StackProfile.distance(referenceProfile,profile);
        double geometryConfidence=Math.max(0,Math.min(1,1.0-step.meanError/Math.max(1,config.ransacThresholdPixels)));
        float[] signature=profile.differenceVector(referenceProfile);

        if(distance<config.changeThreshold){
            candidatePersistence=0;
            previousCandidateProfile=null;
            return result(EngineResult.Status.NO_CHANGE,0,1.0-distance, distance,
                    step.meanError,step.inliers.size(),
                    "No persistent structural change after movement compensation.",null);
        }

        if(previousCandidateProfile!=null &&
                StackProfile.distance(previousCandidateProfile,profile)<0.075) {
            candidatePersistence++;
        } else {
            candidatePersistence=1;
        }
        previousCandidateProfile=profile;

        double confidence=Math.min(1,0.35*normalize(distance)+0.35*geometryConfidence+
                0.30*Math.min(1,candidatePersistence/(double)config.persistentSamples));

        if(candidatePersistence<config.persistentSamples){
            return result(EngineResult.Status.CHANGE_CANDIDATE,0,confidence,distance,
                    step.meanError,step.inliers.size(),
                    "Possible physical change; waiting for more stable frames.",signature);
        }

        SignatureBank.Match match=signatureBank.match(signature,config.signatureMatchThreshold);
        pendingSignature=signature.clone();
        pendingFrame=current;
        pendingTransform=referenceToCurrent;
        pendingRoi=currentRoi;

        if(match.removedCards>0){
            awaitingManualResolution=true;
            return result(EngineResult.Status.CONFIRMED,match.removedCards,confidence,distance,
                    step.meanError,step.inliers.size(),
                    "Known change signature matched. Review/accept before continuing.",signature);
        }

        awaitingManualResolution=true;
        return result(EngineResult.Status.UNCLASSIFIED_CHANGE,0,confidence,distance,
                step.meanError,step.inliers.size(),
                "Persistent structural change found; exact card count needs a labelled signature.",signature);
    }

    /**
     * Call only after the operator has independently verified the exact number removed.
     * The observed difference becomes a labelled signature and the current view becomes
     * the next reference state.
     */
    public synchronized boolean teachPendingAs(int exactRemovedCards) {
        if(!awaitingManualResolution || pendingSignature==null || pendingFrame==null) return false;
        if(exactRemovedCards<1 || exactRemovedCards>20) return false;
        signatureBank.put(exactRemovedCards,pendingSignature);
        rebaseToPendingFrame();
        return true;
    }

    /** Accept a known event and rebase without teaching a new class. */
    public synchronized boolean acceptPendingAndRebase() {
        if(!awaitingManualResolution || pendingFrame==null) return false;
        rebaseToPendingFrame();
        return true;
    }

    private void rebaseToPendingFrame() {
        GrayFrame newReference=pendingFrame;
        RectRegion newRoi=pendingRoi;
        setReference(newReference,newRoi);
        awaitingManualResolution=false;
        pendingSignature=null;pendingFrame=null;pendingTransform=null;pendingRoi=null;
        previousCandidateProfile=null;candidatePersistence=0;
    }

    private void setReference(GrayFrame frame,RectRegion roi) {
        referenceFrame=frame;previousFrame=frame;referenceRoi=roi;
        referenceToCurrent=Homography.identity();
        referenceProfile=StackProfile.measure(WarpedPatch.fromFrame(frame,roi,referenceToCurrent));
        referenceAnchors=createGrid(roi);
        previousAnchors=new ArrayList<>(referenceAnchors);
        previousCandidateProfile=null;candidatePersistence=0;
        pendingSignature=null;pendingFrame=null;pendingTransform=null;pendingRoi=null;
        awaitingManualResolution=false;
    }

    private List<Point2> createGrid(RectRegion r) {
        List<Point2> points=new ArrayList<>();
        double[] fractions={0.18,0.50,0.82};
        for(double fy:fractions) for(double fx:fractions)
            points.add(new Point2(r.left+r.width()*fx,r.top+r.height()*fy));
        return points;
    }

    private RectRegion mapRoi(Homography h,RectRegion r) {
        Point2 a=h.map(new Point2(r.left,r.top));
        Point2 b=h.map(new Point2(r.right,r.top));
        Point2 c=h.map(new Point2(r.right,r.bottom));
        Point2 d=h.map(new Point2(r.left,r.bottom));
        double minX=Math.min(Math.min(a.x,b.x),Math.min(c.x,d.x));
        double maxX=Math.max(Math.max(a.x,b.x),Math.max(c.x,d.x));
        double minY=Math.min(Math.min(a.y,b.y),Math.min(c.y,d.y));
        double maxY=Math.max(Math.max(a.y,b.y),Math.max(c.y,d.y));
        return new RectRegion((int)Math.floor(minX),(int)Math.floor(minY),
                (int)Math.ceil(maxX),(int)Math.ceil(maxY));
    }

    private double normalize(double d) {
        return Math.max(0,Math.min(1,d/0.35));
    }

    private EngineResult result(EngineResult.Status status,int cards,double confidence,
                                double pd,double error,int anchors,String message,float[] signature) {
        return new EngineResult(status,cards,confidence,pd,error,anchors,message,signature);
    }
}
