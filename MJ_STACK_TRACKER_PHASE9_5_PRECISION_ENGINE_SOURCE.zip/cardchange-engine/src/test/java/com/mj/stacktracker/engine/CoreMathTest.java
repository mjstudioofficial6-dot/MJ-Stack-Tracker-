package com.mj.stacktracker.engine;

import org.junit.Test;
import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

public class CoreMathTest {
    @Test public void identityHomographyKeepsPoint() {
        Point2 p=new Point2(23.5,71.25);
        Point2 q=Homography.identity().map(p);
        assertEquals(p.x,q.x,1e-8);
        assertEquals(p.y,q.y,1e-8);
    }

    @Test public void identityHomographyFitFindsAllPoints() {
        List<Point2> pts=Arrays.asList(
                new Point2(10,10),new Point2(90,10),new Point2(90,90),
                new Point2(10,90),new Point2(50,50),new Point2(25,60));
        Homography.Fit fit=Homography.fitRansac(pts,pts,0.5);
        assertNotNull(fit);
        assertEquals(pts.size(),fit.inliers.size());
        assertTrue(fit.meanError<0.01);
    }

    @Test public void profilesIdenticalPatchDistanceIsZero() {
        int w=80,h=48;
        float[] a=new float[w*h];
        for(int y=0;y<h;y++) for(int x=0;x<w;x++)
            a[y*w+x]=(float)(0.4+0.2*Math.sin(y*0.7)+(x%11==0?0.1:0));
        WarpedPatch patch=new WarpedPatch(w,h,a);
        StackProfile p=StackProfile.measure(patch);
        assertEquals(0,StackProfile.distance(p,p),1e-8);
    }

    @Test public void signatureBankOnlyMatchesLabelledPatterns() {
        SignatureBank b=new SignatureBank();
        float[] signature={0.2f,0.4f,0.6f};
        assertEquals(0,b.match(signature,0.4).removedCards);
        b.put(1,signature);
        assertEquals(1,b.match(new float[]{0.21f,0.39f,0.61f},0.1).removedCards);
    }
    @Test public void translatedObjectIsCompensatedByHomography() {
        List<Point2> from=Arrays.asList(
                new Point2(20,20),new Point2(100,20),new Point2(100,100),
                new Point2(20,100),new Point2(60,60),new Point2(40,75));
        List<Point2> to=new java.util.ArrayList<>();
        for(Point2 p:from) to.add(new Point2(p.x+12.0,p.y-7.0));
        Homography.Fit fit=Homography.fitRansac(from,to,0.5);
        assertNotNull(fit);
        assertEquals(from.size(),fit.inliers.size());
        Point2 mapped=fit.transform.map(new Point2(55,45));
        assertEquals(67.0,mapped.x,0.01);
        assertEquals(38.0,mapped.y,0.01);
    }

    @Test public void signatureBankRoundTripsLearnedLabels() {
        SignatureBank bank=new SignatureBank();
        bank.put(2,new float[]{0.15f,0.45f,0.85f});
        SignatureBank restored=new SignatureBank();
        restored.deserialize(bank.serialize());
        assertEquals(2,restored.match(new float[]{0.15f,0.45f,0.85f},0.01).removedCards);
    }

}

