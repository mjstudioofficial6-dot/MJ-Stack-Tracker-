# MJ Stack Tracker — Phase 9.5 Precision Engine Integration

**Package:** `MJ_STACK_TRACKER_PHASE9_5_PRECISION_ENGINE_SOURCE.zip`  
**App version:** `0.9.5` (`versionCode 15`)  
**Android:** Native Java, Android SDK 36, Java 17  
**Runtime:** Offline; user selects a locally stored recorded video  
**Build:** GitHub Actions only

## What changed

Phase 9.5 retains the Phase 9.4.1 multi-pile tracker, object lineage, geometry estimates, local history, and exports. It adds a separate `cardchange-engine` Android library and connects it to the recorded-video analysis loop as an independent evidence channel.

The precision engine:
- locks the user-selected original stack ROI;
- tracks image patches and estimates frame-to-frame homography;
- warps the current ROI into the reference geometry;
- rejects blurred/low-detail frames;
- compares normalized multi-row/multi-column stack profiles;
- requires a persistent structural change;
- matches only locally learned signatures for 1, 2, or 3 card changes;
- requests manual review when a structural change has no labelled signature;
- stores learned signatures locally in app preferences.

## Safety of integration

The new engine does **not** silently replace the existing Phase 9.4.1 detector, multi-pile lineage tracker, or count-estimation ledger. Precision results are saved as separate History events. A matched signature requires human confirmation. A newly detected signature must be independently labelled by the user before it is learned. The existing pile count is not automatically changed by this engine.

The first build is an integration candidate, not a claim of 100% accuracy. Thresholds and signature matches must be validated on real 720p footage. The engine uses no fixed card thickness and does not convert pixels to millimetres to decide a card-removal event.

## Project layout

- `app/` — existing MJ Stack Tracker Android app.
- `cardchange-engine/` — standalone local Java/Android library with tracking, homography, normalized profile, signature bank, and unit tests.
- `settings.gradle` — includes `:app` and `:cardchange-engine`.
- `app/build.gradle` — retains existing dependencies and adds the local engine module.

## Build

Upload this source ZIP to the repository root and upload `build-phase9-5-precision-engine.yml` to `.github/workflows/`. Run the workflow `Build MJ Stack Tracker Phase 9.5 Precision Engine` (or let a push to either watched path trigger it). The workflow checks the archive, runs unit tests, builds the APK, verifies package/version/signature, and publishes the APK plus diagnostics as workflow artifacts.

## Runtime constraints retained

No camera permission, no Internet permission, no Firebase, no cloud AI, no runtime server, and no login requirement. GitHub Actions is used only to compile and publish the APK artifact.
