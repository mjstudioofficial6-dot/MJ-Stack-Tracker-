# MJ Stack Tracker — Phase 10.1 Tabletop ROI

This source package is a targeted Phase 10.1 repair build. It adds tabletop-only candidate filtering and on-screen analysis diagnostics while retaining offline video processing.

## Phase 10.1 build and upload

Repository root upload:

- `MJ_STACK_TRACKER_PHASE10_1_TABLETOP_ROI_SOURCE.zip`

Workflow upload path:

- `.github/workflows/build-phase10-1-tabletop-roi.yml`

Then open **Actions → Build MJ Stack Tracker Phase 10.1 Tabletop ROI → Run workflow**. The APK artifact name is `MJ-Stack-Tracker-Phase10-1-Tabletop-ROI-APK`.

The app keeps the package ID `com.mj.stacktracker.phase9` for upgrade compatibility and increments to version code 17 / version 1.0.1.

## Important accuracy status

This build targets the Phase 10 false-candidate failure: full-frame scene contours were being considered as card piles. It focuses candidate extraction on the central tabletop and reports frame/candidate/quantity-valid diagnostics. It does **not** certify exact per-pile card counts or one-card sensitivity. In the source-video OpenCV reproduction, the table-zone policy proposed candidates in 84 of 121 sample timestamps and up to four candidates in the final frames; this is not an Android APK result or a count-accuracy result. The supplied video has no independent timestamped ground-truth quantity ledger. The known 416-card opening pile can be tracked from presence alone while its visual footprint stays consistent; smaller child piles cannot inherit its 416 count. Unmeasured child piles and uncertain quantities remain unassigned.

See `PHASE10_1_VIDEO_CROSSCHECK.md` for the source/video findings and remaining accuracy limits.

---


- App version: **1.0.1** (`versionCode 17`)
- Package: `com.mj.stacktracker.phase9` (preserved for package identity)
- Platform: native Android / Java 17 / Android SDK 36
- Runtime: offline analysis of a video selected from the phone
- Permissions: no camera or Internet permission; video access is via Android document picker.

## User workflow
1. Tap **SELECT VIDEO** and choose the recorded clip.
2. Tap **PLAY & ANALYZE** (or use the player's Play control).
3. The app samples the full video locally and shows pile-wise quantities, matched transfers and unassigned cards.

No manual object rectangle, millimetre calibration, 0.33 mm/card entry, or Teach 1/2/3 popup is included in the new launcher screen.

## Internal engine structure
- `AutomaticAnalyzer`: sequential local video-frame extraction.
- `CardStackVision`: tabletop-focused bright-card candidate proposals, directional edge projections, and sub-pixel edge-peak analysis.
- `RelativeCountEstimator`: relative scaling against the known 416-card opening stack; no physical units.
- `AutomaticTransferEngine`: temporal object association, stable count updates, source/destination quantity pairing, and conservation accounting.
- `AutomaticMainActivity`: video selection, playback, progress, pile-wise output and transfer history.

## Accuracy boundary
This is an implementation candidate, not a certified card-counting product. The vision detector and relative layer measurement are classical computer vision and remain dependent on the video making the card stack's layer edges visible. If the opening deck cannot be isolated from stable tabletop candidates, or the edge evidence is too weak, the app does not invent an exact count. A one-card change smaller than the available image information cannot be guaranteed by mathematics alone. The Phase 10.1 workflow runs unit tests and builds the APK; real-video accuracy requires validation against labelled samples from the actual recording.

## GitHub build
Upload this ZIP to the repository root and upload the separate workflow file to `.github/workflows/build-phase10-1-tabletop-roi.yml`. Then run the **Build MJ Stack Tracker Phase 10.1 Tabletop ROI** workflow.
