package com.mj.stacktracker.automatic;

/**
 * Conservative, camera-frame-relative gate for the central tabletop region.
 *
 * The Phase 10 full-frame detector was accepting scenery, text and the dealer's
 * hands as piles. This policy limits candidates to the lower central playing
 * surface and to compact card-stack-like connected components.
 *
 * Coordinates and area are normalized, so the same gate works at the analyzer's
 * 1280-pixel maximum width for both 16:9 HD and 16:9 Full-HD recordings.
 */
public final class TabletopCandidatePolicy {
    private TabletopCandidatePolicy() { }

    public static boolean accepts(int x, int y, int width, int height,
                                  double contourArea, int imageWidth, int imageHeight,
                                  double rectangularity) {
        if (imageWidth <= 0 || imageHeight <= 0 || width <= 0 || height <= 0) return false;
        if (!Double.isFinite(contourArea) || contourArea <= 0) return false;
        if (!Double.isFinite(rectangularity) || rectangularity < 0.12) return false;

        double imageArea = (double) imageWidth * imageHeight;
        double areaFraction = contourArea / imageArea;
        if (areaFraction < 0.00085 || areaFraction > 0.035) return false;

        // Exclude thin table lettering, rails and large scenery/background regions.
        if (width < 22 || height < 18 || width > 180 || height > 130) return false;
        double aspect = width / (double) height;
        if (aspect < 0.55 || aspect > 2.80) return false;

        double cx = (x + width * 0.5) / imageWidth;
        double cy = (y + height * 0.5) / imageHeight;
        // Observed playable tabletop window in the supplied fixed-camera test clip.
        return cx >= 0.28 && cx <= 0.68 && cy >= 0.50 && cy <= 0.80;
    }
}
