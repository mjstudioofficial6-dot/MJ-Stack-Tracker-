package com.mj.stacktracker.automatic;

import org.junit.Test;
import static org.junit.Assert.*;

public class TabletopCandidatePolicyTest {
    @Test public void acceptsOpeningDeckInsideTabletopWindow() {
        assertTrue(TabletopCandidatePolicy.accepts(
                597, 377, 72, 84, 3416, 1280, 720, 0.56));
    }

    @Test public void acceptsFourFinalPileShapesFromSuppliedClip() {
        assertTrue(TabletopCandidatePolicy.accepts(441, 444, 77, 34, 1411, 1280, 720, 0.54));
        assertTrue(TabletopCandidatePolicy.accepts(565, 463, 64, 28, 1016, 1280, 720, 0.57));
        assertTrue(TabletopCandidatePolicy.accepts(667, 459, 68, 37, 1768, 1280, 720, 0.70));
        assertTrue(TabletopCandidatePolicy.accepts(745, 443, 71, 42, 1960, 1280, 720, 0.66));
    }

    @Test public void rejectsLargeBackgroundSceneryContour() {
        assertFalse(TabletopCandidatePolicy.accepts(
                71, 25, 819, 462, 143222, 1280, 720, 0.42));
    }

    @Test public void rejectsThinPrintedTableText() {
        assertFalse(TabletopCandidatePolicy.accepts(
                707, 438, 93, 18, 1234, 1280, 720, 0.64));
    }

    @Test public void rejectsSmallBrightHandOrPropCandidate() {
        assertFalse(TabletopCandidatePolicy.accepts(
                673, 359, 72, 50, 652, 1280, 720, 0.18));
    }

    @Test public void rejectsRightSideDealerEquipmentOutsidePileZone() {
        assertFalse(TabletopCandidatePolicy.accepts(
                868, 409, 61, 64, 1974, 1280, 720, 0.60));
    }
}
