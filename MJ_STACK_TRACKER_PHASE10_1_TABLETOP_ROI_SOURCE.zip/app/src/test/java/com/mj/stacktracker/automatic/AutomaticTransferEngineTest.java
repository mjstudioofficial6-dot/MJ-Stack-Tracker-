package com.mj.stacktracker.automatic;
import org.junit.Test;
import java.util.Arrays;
import static org.junit.Assert.*;
public class AutomaticTransferEngineTest {
 private PileObservation p(float l,float t,float r,float b,int c){return new PileObservation(l,t,r,b,c,.95,true);}
 @Test public void knownStartingDeckCanBeTrackedFromPresenceOnlyEvidence(){
  AutomaticTransferEngine e=new AutomaticTransferEngine(416);
  PileObservation presenceOnly=new PileObservation(.40f,.35f,.60f,.65f,0,.72,false);
  AnalysisSnapshot s=e.update(0,Arrays.asList(presenceOnly));
  assertEquals(416,s.accountedCount);assertEquals(0,s.unassignedCount);
  assertEquals(1,s.piles.size());assertEquals("PILE-01",s.piles.get(0).id);
  assertEquals(416,s.piles.get(0).count);assertTrue(s.piles.get(0).visible);
 }
 @Test public void presenceOnlyChildDoesNotCreateInventedQuantity(){
  AutomaticTransferEngine e=new AutomaticTransferEngine(416);
  AnalysisSnapshot s=e.update(0,Arrays.asList(p(.35f,.35f,.65f,.65f,416)));
  PileObservation unknownChild=new PileObservation(.70f,.35f,.82f,.65f,0,.80,false);
  s=e.update(180,Arrays.asList(p(.35f,.35f,.65f,.65f,416),unknownChild));
  assertEquals(416,s.accountedCount);assertEquals(1,s.piles.size());
  assertEquals("PILE-01",s.piles.get(0).id);
 }
 @Test public void smallerNearbyPresenceOnlyChildCannotInheritThe416CardRoot(){
  AutomaticTransferEngine e=new AutomaticTransferEngine(416);
  PileObservation opening=new PileObservation(.40f,.40f,.60f,.60f,0,.72,false);
  AnalysisSnapshot s=e.update(0,Arrays.asList(opening));
  PileObservation smallerChild=new PileObservation(.43f,.44f,.57f,.56f,0,.80,false);
  s=e.update(180,Arrays.asList(smallerChild));
  s=e.update(360,Arrays.asList(smallerChild));
  s=e.update(540,Arrays.asList(smallerChild));
  assertEquals(0,s.accountedCount);assertEquals(416,s.unassignedCount);
  assertEquals(1,s.piles.size());assertFalse(s.piles.get(0).visible);
 }
 @Test public void splitCountsRemainConserved(){
  AutomaticTransferEngine e=new AutomaticTransferEngine(416);AnalysisSnapshot s=null;
  for(int i=0;i<4;i++)s=e.update(i*180,Arrays.asList(p(.35f,.35f,.65f,.65f,416)));
  assertEquals(416,s.accountedCount);
  for(int i=4;i<12;i++)s=e.update(i*180,Arrays.asList(p(.15f,.35f,.37f,.65f,336),p(.55f,.35f,.75f,.65f,80)));
  assertEquals(416,s.accountedCount);assertTrue(s.piles.size()>=2);
 }
 @Test public void transferPairIsRecognizedAndParentIdentityKept(){
  AutomaticTransferEngine e=new AutomaticTransferEngine(416);AnalysisSnapshot s=null;
  for(int i=0;i<4;i++)s=e.update(i*180,Arrays.asList(p(.35f,.35f,.65f,.65f,416)));
  for(int i=4;i<12;i++)s=e.update(i*180,Arrays.asList(p(.15f,.35f,.37f,.65f,360),p(.55f,.35f,.75f,.65f,56)));
  assertEquals(416,s.accountedCount);assertFalse(s.transfers.isEmpty());
  TransferEvent event=s.transfers.get(0);assertEquals(56,event.quantity);
  assertEquals("PILE-01",event.sourcePileId);assertEquals("PILE-02",event.destinationPileId);
 }
}
