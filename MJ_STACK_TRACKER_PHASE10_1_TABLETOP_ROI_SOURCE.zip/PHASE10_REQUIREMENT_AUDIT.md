# Phase 10.1 Requirement Audit

## Preserved requirements

- Native Android application.
- Local video selected through Android document picker.
- Video playback using AndroidX Media3.
- OpenCV analysis executes on-device.
- No camera permission.
- No Internet permission or cloud runtime dependency.
- Initial inventory remains 416.
- No manual mm calibration or 1/2/3-card teach popup.
- GitHub Actions is used only to compile and package the APK.

## Phase 10.1 changes

- Replace unrestricted full-frame scene contour selection with low-saturation bright candidate extraction inside a tabletop search window.
- Apply normalized candidate shape, area, location and aspect gates.
- Lock reference measurements only from geometrically stable opening tabletop candidates.
- Report decoded frames, tabletop candidates, maximum simultaneous candidates, quantity-valid observations and transfer count.
- Add pure-Java tests for the tabletop candidate gate.

## Acceptance still outstanding

- Run the Phase 10.1 workflow and install the resulting APK.
- Confirm the supplied video reports the expected tabletop candidate progression from one deck to multiple piles.
- Record independent ground-truth card counts for each pile at labelled timestamps.
- Validate 20–25 card moves and 1-card sensitivity against the ground truth.
- Confirm source/destination transfers and inventory conservation on controlled test footage.

A successful build or candidate detection is not proof of exact automatic counting.
