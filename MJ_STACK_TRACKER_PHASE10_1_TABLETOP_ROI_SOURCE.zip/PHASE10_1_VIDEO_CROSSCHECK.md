# MJ Stack Tracker — Phase 10.1 Video Cross-check

## Inputs inspected

- User-provided clip: `VID_20261028_173908.mp4` (kept outside the source package and repository)
- Resolution: 1920 × 1080
- Frame rate: 30 FPS
- Duration: approximately 21.7 seconds
- Frames: approximately 650
- Final visible state: four separated card piles on the central tabletop
- Frame sampling policy: 180 ms (about 121 requested sample timestamps for this clip; the old “16 usable samples” status counted quantity-valid visual samples, not total decoded frames)

## Confirmed Phase 10 failure points

1. The analyzer did not inspect only the playing surface. It combined full-frame Canny edges and a broad white mask, then ranked contours partly by distance from the full-frame centre. Large scenery, clothing, table lettering and dealer equipment could therefore outrank the actual card stack.
2. The opening reference selector had no tabletop region or card-stack shape gate. A stable but unrelated background contour could be selected as the 416-card reference.
3. The relative estimator required `edgePeriodicity >= 0.08` and at least two edge peaks. With exactly two peaks, regularity remained zero and periodicity was only about 0.0583, so those candidates were rejected despite satisfying the peak-count check.
4. A pile track could be created only from a quantity-valid observation. When the vision stage rejected a candidate, no child pile or transfer could be committed.
5. The app displayed only the final usable count and ledger. It did not report how many frames were decoded, how many tabletop candidates were found, or how many passed quantity confidence.
6. The `RelativeCountEstimator` also rejected low-edge observations before transfer tracking. On the supplied final pile crops, several candidates show only two directional peaks; the old 0.08 periodicity cutoff rejects the 0.0583 value produced by two peaks. Lowering this threshold alone would still not establish the right orientation or a reliable layer-to-card scale, so Phase 10.1 does not force these candidates into quantity-valid observations.

## Phase 10.1 changes

- Candidate extraction now uses a low-saturation bright-card mask inside a central tabletop search window.
- `TabletopCandidatePolicy` rejects large background contours, thin printed text, small bright hand/prop regions and equipment outside the pile zone.
- Opening reference samples must remain geometrically stable in the tabletop zone. The reference is locked from the first stable opening views rather than being selected from arbitrary full-frame contours later in the clip.
- The UI status now reports decoded frame count, sampling interval, frames with tabletop candidates, maximum simultaneous candidates, quantity-valid observations and transfer count.
- Candidate presence is kept separately from quantity validity. This allows the known 416-card opening inventory to initialise PILE-01 when the opening stack is visually present, without assigning guessed quantities to new child piles.
- Presence-only matching keeps PILE-01 only while the candidate footprint and centre remain close to the opening-deck track. A smaller nearby child pile cannot inherit the parent’s 416 count.
- The transfer engine ignores presence-only observations when creating child piles or changing a known count.
- A further matching guard stops a smaller, nearby presence-only child from inheriting PILE-01's 416-card identity after a split.
- A dedicated unit-test class covers the opening stack, the four final pile boxes, and representative false-positive candidates taken from the inspected video frames.
- A separate Python/OpenCV 4.13 reproduction of the Phase 10.1 colour-mask and geometry policy on the uploaded recording found candidates in 84 of 121 requested sample frames, with a maximum of four candidates in one frame near the clip end. This is a detector-policy reproduction on extracted frames, not a result from the Android APK and not a card-count accuracy score.

## Important accuracy boundary

This is a targeted detector repair and diagnostic build, not a certified exact-count release. The supplied clip does not include a ground-truth event ledger listing the true number of cards in each pile at every timestamp. A pile bounding box is not proof of its exact quantity, and one-card changes cannot be claimed as resolved from these images. The app must leave low-confidence quantities unassigned rather than inventing counts.

The uploaded video is intentionally not included in the source ZIP and should not be committed to GitHub. It remains local to the user's phone/test workflow. No per-pile ground-truth quantity timeline was supplied, so 1-card / 20–25-card accuracy and transfer matching remain unverified.
