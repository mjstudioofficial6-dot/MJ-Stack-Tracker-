MJ Stack Tracker — Phase 2 (Auto + Manual Geometry)

Scope:
- Keep Phase 1 local video playback and 16:9 YouTube-like viewport.
- Auto Detect analyzes a representative frame from the selected local video.
- It generates a conservative geometry candidate for the working region.
- Blue four-corner top-surface reference is shown from the candidate.
- Red vertical side/edge reference is shown from the candidate.
- Manual mode lets the user correct every handle.
- Known physical reference in millimetres can be entered and saved for the session.
- Low-confidence automatic results are NOT forced; the app asks for manual correction.
- No automatic quantity counting, stack tracking, database or cloud runtime.

Important:
Auto Detect is a candidate generator, not proof of perfect geometry. The confidence
gate deliberately falls back to manual calibration when evidence is weak. This prevents
a bad automatic guess from silently becoming tracking ground truth.

Acceptance test:
1. Build through GitHub Actions.
2. Install APK.
3. Select a recorded video.
4. Confirm the video remains 16:9 and the rest of the UI is white.
5. Tap Auto Detect.
6. If confidence is sufficient, a blue rectangle and red side line appear.
7. Tap Manual and adjust handles if necessary.
8. If confidence is low, the app explicitly asks for Manual calibration.
9. Enter a positive mm reference and Save.
10. Reset restores the default geometry.
11. Clear removes the video and overlay.
12. No camera permission or broad storage permission is requested.
