package com.mj.stacktracker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.Locale;

/**
 * Phase 2 manual geometry overlay.
 * This is a UI/calibration layer only; it does not perform automatic CV.
 */
public final class CalibrationOverlayView extends View {
    public interface Listener {
        void onCalibrationChanged();
    }

    private final Paint blue = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint red = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint white = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final PointF[] corners = {
            new PointF(0.20f, 0.28f),
            new PointF(0.80f, 0.28f),
            new PointF(0.80f, 0.72f),
            new PointF(0.20f, 0.72f)
    };
    private float sideX = 0.20f;
    private float sideTopY = 0.28f;
    private float sideBottomY = 0.72f;

    private boolean calibrationMode;
    private int activeHandle = -1;
    private Listener listener;

    public CalibrationOverlayView(Context context) {
        super(context);
        setWillNotDraw(false);

        blue.setColor(0xFF1565C0);
        blue.setStyle(Paint.Style.STROKE);
        blue.setStrokeWidth(dp(3));

        red.setColor(0xFFD32F2F);
        red.setStyle(Paint.Style.STROKE);
        red.setStrokeWidth(dp(3));

        white.setColor(0xFFFFFFFF);
        white.setStyle(Paint.Style.FILL);

        text.setColor(0xFFFFFFFF);
        text.setTextSize(dp(12));
        text.setShadowLayer(dp(3), 0, 0, 0xFF000000);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void setCalibrationMode(boolean enabled) {
        calibrationMode = enabled;
        activeHandle = -1;
        invalidate();
    }

    public boolean isCalibrationMode() {
        return calibrationMode;
    }

    public void applyDetectedGeometry(float left, float top,
                                      float right, float bottom) {
        left = clamp(left, 0.02f, 0.90f);
        right = clamp(right, left + 0.05f, 0.98f);
        top = clamp(top, 0.02f, 0.90f);
        bottom = clamp(bottom, top + 0.05f, 0.98f);

        corners[0].set(left, top);
        corners[1].set(right, top);
        corners[2].set(right, bottom);
        corners[3].set(left, bottom);

        sideX = left;
        sideTopY = top;
        sideBottomY = bottom;
        invalidate();
        notifyChanged();
    }

    public void resetCalibration() {
        corners[0].set(0.20f, 0.28f);
        corners[1].set(0.80f, 0.28f);
        corners[2].set(0.80f, 0.72f);
        corners[3].set(0.20f, 0.72f);
        sideX = 0.20f;
        sideTopY = 0.28f;
        sideBottomY = 0.72f;
        invalidate();
        notifyChanged();
    }

    public String getCalibrationSummary() {
        return String.format(Locale.US,
                "Top corners: (%.0f%%,%.0f%%) → (%.0f%%,%.0f%%)   Side: %.0f%%",
                corners[0].x * 100f, corners[0].y * 100f,
                corners[1].x * 100f, corners[1].y * 100f,
                sideX * 100f);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float w = getWidth();
        float h = getHeight();

        Path top = new Path();
        top.moveTo(corners[0].x * w, corners[0].y * h);
        top.lineTo(corners[1].x * w, corners[1].y * h);
        top.lineTo(corners[2].x * w, corners[2].y * h);
        top.lineTo(corners[3].x * w, corners[3].y * h);
        top.close();

        canvas.drawPath(top, blue);

        float x = sideX * w;
        canvas.drawLine(x, sideTopY * h, x, sideBottomY * h, red);

        if (calibrationMode) {
            for (int i = 0; i < corners.length; i++) {
                drawHandle(canvas, corners[i].x * w, corners[i].y * h);
            }
            drawHandle(canvas, x, sideTopY * h);
            drawHandle(canvas, x, sideBottomY * h);

            canvas.drawText("BLUE = top surface / corners", dp(10), dp(20), text);
            canvas.drawText("RED = vertical side / edge", dp(10), dp(38), text);
        }
    }

    private void drawHandle(Canvas canvas, float x, float y) {
        canvas.drawCircle(x, y, dp(8), white);
        Paint ring = blue;
        canvas.drawCircle(x, y, dp(8), ring);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!calibrationMode) {
            return false;
        }

        float x = event.getX();
        float y = event.getY();

        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            activeHandle = findHandle(x, y);
            return activeHandle >= 0;
        }

        if (event.getAction() == MotionEvent.ACTION_MOVE && activeHandle >= 0) {
            float nx = clamp(x / Math.max(1f, getWidth()), 0.02f, 0.98f);
            float ny = clamp(y / Math.max(1f, getHeight()), 0.02f, 0.98f);

            if (activeHandle >= 0 && activeHandle < 4) {
                corners[activeHandle].set(nx, ny);
            } else if (activeHandle == 4) {
                sideX = nx;
                sideTopY = Math.min(ny, sideBottomY - 0.03f);
            } else if (activeHandle == 5) {
                sideX = nx;
                sideBottomY = Math.max(ny, sideTopY + 0.03f);
            }
            invalidate();
            notifyChanged();
            return true;
        }

        if (event.getAction() == MotionEvent.ACTION_UP
                || event.getAction() == MotionEvent.ACTION_CANCEL) {
            activeHandle = -1;
            return true;
        }

        return true;
    }

    private int findHandle(float x, float y) {
        float best = dp(28);
        int found = -1;

        for (int i = 0; i < 4; i++) {
            float dx = x - corners[i].x * getWidth();
            float dy = y - corners[i].y * getHeight();
            float d = (float) Math.hypot(dx, dy);
            if (d < best) {
                best = d;
                found = i;
            }
        }

        float dx = x - sideX * getWidth();
        float dyTop = y - sideTopY * getHeight();
        float dyBottom = y - sideBottomY * getHeight();
        float topD = (float) Math.hypot(dx, dyTop);
        float bottomD = (float) Math.hypot(dx, dyBottom);

        if (topD < best) {
            found = 4;
            best = topD;
        }
        if (bottomD < best) {
            found = 5;
        }
        return found;
    }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private float dp(int value) {
        return value * getResources().getDisplayMetrics().density;
    }

    private void notifyChanged() {
        if (listener != null) {
            listener.onCalibrationChanged();
        }
    }
}
