package com.mj.stacktracker;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.media.MediaMetadataRetriever;
import android.os.Handler;
import android.os.Looper;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.graphics.Insets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

/**
 * Phase 2: video + manual geometry/calibration overlay.
 * No automatic CV, AI, counting or database is included.
 */
public final class MainActivity extends Activity {
    private static final int REQUEST_VIDEO = 1001;

    private ExoPlayer player;
    private PlayerView playerView;
    private CalibrationOverlayView overlayView;
    private TextView statusText;
    private EditText referenceMm;
    private TextView calibrationText;
    private boolean savedCalibration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int top;
            int bottom;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets bars = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            view.setPadding(0, top, 0, bottom);
            return insets;
        });

        TextView title = new TextView(this);
        title.setText("MJ Stack Tracker — Phase 2");
        title.setTextColor(0xFF202124);
        title.setTextSize(19);
        title.setGravity(Gravity.CENTER);
        title.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.addView(title);

        // Fixed 16:9 video viewport, matching Phase 1.
        int width = getResources().getDisplayMetrics().widthPixels;
        int videoHeight = Math.round(width * 9f / 16f);

        android.widget.FrameLayout videoLayer = new android.widget.FrameLayout(this);
        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerView.setBackgroundColor(Color.BLACK);
        videoLayer.addView(playerView, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        overlayView = new CalibrationOverlayView(this);
        overlayView.setListener(() -> {
            calibrationText.setText(overlayView.getCalibrationSummary());
            savedCalibration = false;
        });
        overlayView.setVisibility(View.GONE);
        videoLayer.addView(overlayView, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        root.addView(videoLayer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, videoHeight));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setPadding(dp(8), dp(6), dp(8), 0);

        Button select = new Button(this);
        select.setText("Select Video");
        select.setOnClickListener(v -> openVideoPicker());
        addButton(buttons, select);

        Button calibrate = new Button(this);
        calibrate.setText("Manual");
        calibrate.setOnClickListener(v -> toggleCalibration());
        addButton(buttons, calibrate);

        Button auto = new Button(this);
        auto.setText("Auto Detect");
        auto.setOnClickListener(v -> autoDetectGeometry());
        addButton(buttons, auto);

        Button reset = new Button(this);
        reset.setText("Reset");
        reset.setOnClickListener(v -> {
            overlayView.resetCalibration();
            savedCalibration = false;
            calibrationText.setText("Calibration reset.");
        });
        addButton(buttons, reset);

        Button clear = new Button(this);
        clear.setText("Clear");
        clear.setOnClickListener(v -> clearVideo());
        addButton(buttons, clear);

        root.addView(buttons);

        LinearLayout referenceRow = new LinearLayout(this);
        referenceRow.setOrientation(LinearLayout.HORIZONTAL);
        referenceRow.setGravity(Gravity.CENTER_VERTICAL);
        referenceRow.setPadding(dp(12), dp(2), dp(12), 0);

        TextView referenceLabel = new TextView(this);
        referenceLabel.setText("Known reference:");
        referenceLabel.setTextColor(0xFF202124);
        referenceRow.addView(referenceLabel);

        referenceMm = new EditText(this);
        referenceMm.setHint("mm");
        referenceMm.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        referenceMm.setSingleLine(true);
        referenceRow.addView(referenceMm, new LinearLayout.LayoutParams(
                dp(90), dp(52)));

        Button save = new Button(this);
        save.setText("Save");
        save.setOnClickListener(v -> saveCalibration());
        referenceRow.addView(save);

        root.addView(referenceRow);

        calibrationText = new TextView(this);
        calibrationText.setText("Calibration not active.");
        calibrationText.setTextColor(0xFF5F6368);
        calibrationText.setTextSize(12);
        calibrationText.setPadding(dp(12), dp(2), dp(12), 0);
        root.addView(calibrationText);

        statusText = new TextView(this);
        statusText.setText("Select a recorded video to begin.");
        statusText.setTextColor(0xFF5F6368);
        statusText.setTextSize(13);
        statusText.setPadding(dp(12), dp(6), dp(12), dp(4));
        root.addView(statusText);

        TextView scope = new TextView(this);
        scope.setText("Phase 2: manual geometry only. Blue = top/corners; Red = vertical edge. "
                + "No automatic detection or quantity counting yet.");
        scope.setTextColor(0xFF5F6368);
        scope.setTextSize(12);
        scope.setPadding(dp(12), 0, dp(12), dp(8));
        root.addView(scope);

        setContentView(root);
    }

    private void addButton(LinearLayout row, Button button) {
        row.addView(button, new LinearLayout.LayoutParams(
                0, dp(48), 1f));
    }

    private void toggleCalibration() {
        boolean enabled = !overlayView.isCalibrationMode();
        overlayView.setCalibrationMode(enabled);
        overlayView.setVisibility(enabled ? View.VISIBLE : View.GONE);
        calibrationText.setText(enabled
                ? "Drag blue corners and red edge handles to match the video."
                : "Calibration overlay hidden.");
    }

    private void saveCalibration() {
        String value = referenceMm.getText().toString().trim();
        if (value.isEmpty()) {
            referenceMm.setError("Enter a reference in mm.");
            return;
        }
        try {
            double mm = Double.parseDouble(value);
            if (mm <= 0) {
                referenceMm.setError("Reference must be greater than 0.");
                return;
            }
            savedCalibration = true;
            calibrationText.setText("Saved: " + mm + " mm | " +
                    overlayView.getCalibrationSummary());
            Toast.makeText(this, "Calibration saved for this session.",
                    Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            referenceMm.setError("Enter a valid number.");
        }
    }


    /**
     * Automatic candidate geometry detector.
     *
     * It analyzes one frame from the selected video and looks for strong,
     * persistent horizontal/vertical boundaries. This is deliberately a
     * candidate generator, not a claim of perfect CV recognition.
     *
     * If the evidence is weak, the UI leaves the current calibration intact
     * and asks the user to use Manual calibration.
     */
    private void autoDetectGeometry() {
        if (player == null) {
            Toast.makeText(this, "Select a video first.", Toast.LENGTH_SHORT).show();
            return;
        }

        statusText.setText("Analyzing a representative video frame...");
        new Thread(() -> {
            DetectionResult result = detectGeometryFromVideo();
            new Handler(Looper.getMainLooper()).post(() -> {
                if (result == null || result.confidence < 0.55f) {
                    statusText.setText("Automatic detection is uncertain. Use Manual calibration.");
                    Toast.makeText(this,
                            "Low confidence. Please adjust the blue/red handles manually.",
                            Toast.LENGTH_LONG).show();
                    overlayView.setVisibility(View.VISIBLE);
                    overlayView.setCalibrationMode(true);
                    return;
                }

                overlayView.applyDetectedGeometry(
                        result.left, result.top, result.right, result.bottom);
                overlayView.setVisibility(View.VISIBLE);
                overlayView.setCalibrationMode(false);
                calibrationText.setText(
                        String.format(java.util.Locale.US,
                                "Auto candidate accepted: %.0f%% confidence. Tap Manual to correct.",
                                result.confidence * 100f));
                savedCalibration = false;
                statusText.setText("Automatic geometry candidate applied.");
            });
        }, "MJ-geometry").start();
    }

    private DetectionResult detectGeometryFromVideo() {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        Bitmap bitmap = null;
        try {
            // Reuse the selected player's URI through its current media item.
            if (player == null || player.getCurrentMediaItem() == null
                    || player.getCurrentMediaItem().localConfiguration == null) {
                return null;
            }
            Uri uri = player.getCurrentMediaItem().localConfiguration.uri;
            retriever.setDataSource(this, uri);

            String durationString = retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_DURATION);
            long durationMs = 0L;
            if (durationString != null) {
                try {
                    durationMs = Long.parseLong(durationString);
                } catch (NumberFormatException ignored) {
                }
            }

            long[] candidates = new long[] {
                    Math.max(0L, durationMs / 2L),
                    Math.max(0L, Math.min(durationMs, 1000L))
            };

            for (long time : candidates) {
                bitmap = retriever.getFrameAtTime(
                        time * 1000L,
                        MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                if (bitmap == null) {
                    continue;
                }

                DetectionResult result = analyzeBitmap(bitmap);
                bitmap.recycle();
                bitmap = null;

                if (result != null && result.confidence >= 0.55f) {
                    return result;
                }
            }
            return null;
        } catch (Exception ignored) {
            return null;
        } finally {
            if (bitmap != null) {
                bitmap.recycle();
            }
            try {
                retriever.release();
            } catch (Exception ignored) {
            }
        }
    }

    /**
     * Lightweight geometry analysis using luminance gradients.
     * Finds the strongest long horizontal/vertical transitions inside
     * the central video region. It is intentionally conservative.
     */
    private DetectionResult analyzeBitmap(Bitmap source) {
        int targetW = 480;
        float scale = Math.min(1f, targetW / (float) source.getWidth());
        int w = Math.max(64, Math.round(source.getWidth() * scale));
        int h = Math.max(64, Math.round(source.getHeight() * scale));

        Bitmap b = Bitmap.createScaledBitmap(source, w, h, true);
        int[] pixels = new int[w * h];
        b.getPixels(pixels, 0, w, 0, 0, w, h);
        b.recycle();

        float[] row = new float[h];
        float[] col = new float[w];

        for (int y = 1; y < h - 1; y++) {
            float sum = 0f;
            for (int x = 1; x < w - 1; x++) {
                int c1 = pixels[y * w + x - 1];
                int c2 = pixels[y * w + x + 1];
                float l1 = luminance(c1);
                float l2 = luminance(c2);
                sum += Math.abs(l2 - l1);
            }
            row[y] = sum / Math.max(1, w - 2);
        }

        for (int x = 1; x < w - 1; x++) {
            float sum = 0f;
            for (int y = 1; y < h - 1; y++) {
                int c1 = pixels[(y - 1) * w + x];
                int c2 = pixels[(y + 1) * w + x];
                float l1 = luminance(c1);
                float l2 = luminance(c2);
                sum += Math.abs(l2 - l1);
            }
            col[x] = sum / Math.max(1, h - 2);
        }

        int top = peak(row, (int)(h * 0.10f), (int)(h * 0.65f));
        int bottom = peak(row, top + Math.max(8, h / 10), (int)(h * 0.90f));
        int left = peak(col, (int)(w * 0.05f), (int)(w * 0.70f));
        int right = peak(col, left + Math.max(8, w / 10), (int)(w * 0.95f));

        if (top < 0 || bottom < 0 || left < 0 || right < 0
                || bottom <= top || right <= left) {
            return null;
        }

        float horizontal = Math.min(row[top], row[bottom]);
        float vertical = Math.min(col[left], col[right]);
        float score = Math.min(1f, (horizontal + vertical) / 80f);

        // Reject tiny or implausible regions.
        float widthFraction = (right - left) / (float) w;
        float heightFraction = (bottom - top) / (float) h;
        if (widthFraction < 0.35f || heightFraction < 0.15f) {
            return null;
        }

        DetectionResult r = new DetectionResult();
        r.left = left / (float) w;
        r.top = top / (float) h;
        r.right = right / (float) w;
        r.bottom = bottom / (float) h;
        r.confidence = score;
        return r;
    }

    private int peak(float[] values, int start, int end) {
        start = Math.max(1, start);
        end = Math.min(values.length - 2, end);
        int best = -1;
        float bestValue = -1f;
        for (int i = start; i <= end; i++) {
            if (values[i] > bestValue) {
                bestValue = values[i];
                best = i;
            }
        }
        return best;
    }

    private float luminance(int color) {
        return (0.299f * ((color >> 16) & 0xFF))
                + (0.587f * ((color >> 8) & 0xFF))
                + (0.114f * (color & 0xFF));
    }

    private static final class DetectionResult {
        float left;
        float top;
        float right;
        float bottom;
        float confidence;
    }

    private void openVideoPicker() {
        Intent intent;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent = new Intent(MediaStore.ACTION_PICK_IMAGES);
            intent.setType("video/*");
        } else {
            intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("video/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        }
        try {
            startActivityForResult(intent, REQUEST_VIDEO);
        } catch (Exception e) {
            Toast.makeText(this, "Video picker unavailable on this device.",
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_VIDEO || resultCode != RESULT_OK || data == null) {
            return;
        }

        Uri uri = data.getData();
        if (uri == null) {
            statusText.setText("No video selected.");
            return;
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            try {
                getContentResolver().takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (SecurityException ignored) {
            }
        }

        playVideo(uri);
    }

    private void playVideo(Uri uri) {
        releasePlayer();
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setMediaItem(MediaItem.fromUri(uri));
        player.prepare();
        player.play();
        statusText.setText("Video loaded. Calibrate against a paused frame when needed.");
    }

    private void clearVideo() {
        releasePlayer();
        playerView.setPlayer(null);
        overlayView.setVisibility(View.GONE);
        overlayView.setCalibrationMode(false);
        savedCalibration = false;
        statusText.setText("No video selected. Tap Select Video.");
        calibrationText.setText("Calibration not active.");
    }

    private void releasePlayer() {
        if (player != null) {
            player.release();
            player = null;
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) {
            player.pause();
        }
    }

    @Override
    protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }
}
