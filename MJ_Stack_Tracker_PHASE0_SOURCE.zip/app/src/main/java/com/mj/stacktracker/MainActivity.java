package com.mj.stacktracker;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TextView;

/**
 * Phase 0 build proof only. Video playback, stack detection and counting are intentionally
 * not implemented in this baseline.
 */
public final class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView message = new TextView(this);
        message.setText("MJ Stack Tracker\nPhase 0\n\nBuild and install test app\n\nVideo analysis is not included yet.");
        message.setTextSize(22);
        message.setGravity(Gravity.CENTER);
        message.setPadding(28, 28, 28, 28);
        setContentView(message);
    }
}
