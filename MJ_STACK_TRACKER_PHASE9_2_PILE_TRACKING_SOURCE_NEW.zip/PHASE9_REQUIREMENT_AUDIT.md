# Phase 9.2 Requirement / Change Audit

## UI placement
- Mark work area, locked object, count/thickness, table calibration, and stack-side calibration are in VIDEO & ANALYSIS.
- The MODEL panel begins with the pile schematic and contains current pile rows and pile/ledger correction actions below it.
- History lists video sessions and human-readable pile records; raw candidate events are hidden by default under a technical-details toggle.
- Action buttons are 30 dp high with compact 8.5 sp labels.

## Tracking / history behaviour
- `PILE-01` is seeded from the selected object rectangle.
- In locked-master mode a new track is rejected unless it has spatial continuity with the locked object or a tracked child; child-sized contours cannot replace the Pile 1 identity; new child candidates need a spatial relationship to the locked root/known child, a spatially distinct footprint from the centre of the root, a detector score of at least 50, and three processed-frame persistence before confirmation.
- A confirmed child track creates `PILE_CREATED`; its approximate count is estimated from stack-side scale and per-piece thickness, or relative image height when side calibration is unavailable.
- `PILE_COUNT_UPDATED` records the remaining Pile 1 estimate. These estimates do not silently modify the confirmed inventory ledger.
- Pile events persist in SQLite, are displayed as a chronological, understandable timeline per video (created, estimate updated, not visible); tapping a timeline row seeks to its source timestamp. The model schematic computes the latest saved pile state at or before the current video playhead and updates as playback crosses timeline events. The app auto-generates a private local session folder on completion/stop, with a human-readable pile CSV, session JSON, optional separate technical event JSON, and source-video reference; sharing makes a ZIP of this folder.
- Session action dialog supports opening, sharing the session ZIP, sharing the source video + summary, and deleting the DB records plus report folder/ZIP. Source video is not copied into the report bundle and is never deleted.

- Regression tests cover rejection of distant unrelated contours, three-frame child confirmation, and retention of the Pile 1 reference box.

## Accuracy boundary
- The underlying detector remains OpenCV contour proposals. It is not a trained visual-semantic model.
- Automatic quantity values are visual estimates and can be wrong under occlusion, perspective, poor contrast, scene clutter, overlap, or changes in visible object orientation.
- This package still needs a successful Android GitHub Actions build and real-video test; it is not presented as production-verified.
