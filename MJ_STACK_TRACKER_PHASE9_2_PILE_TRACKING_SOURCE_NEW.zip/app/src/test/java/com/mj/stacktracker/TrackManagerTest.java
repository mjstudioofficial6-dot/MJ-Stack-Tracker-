package com.mj.stacktracker;

import org.junit.Test;

import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/** Regression tests for locked-object identity and split-candidate persistence. */
public class TrackManagerTest {
    @Test public void distantUnrelatedContourDoesNotCreatePile() {
        TrackManager manager = new TrackManager(true);
        manager.seedMaster(new float[]{0.20f, 0.20f, 0.60f, 0.60f});

        TrackManager.Update update = manager.update(Collections.singletonList(
                new DetectionCandidate(0.82f, 0.80f, 0.93f, 0.90f, 95f)));

        assertTrue(update.events.isEmpty());
        assertEquals(1, update.visible.size());
        assertEquals("PILE-01", update.visible.get(0).id);
        assertEquals(0.20f, update.visible.get(0).left, 0.0001f);
    }

    @Test public void separateChildMustPersistThreeFramesAndCannotReplacePileOne() {
        TrackManager manager = new TrackManager(true);
        manager.seedMaster(new float[]{0.20f, 0.20f, 0.60f, 0.60f});
        DetectionCandidate child = new DetectionCandidate(0.55f, 0.35f, 0.70f, 0.45f, 95f);

        TrackManager.Update first = manager.update(Collections.singletonList(child));
        assertTrue(containsEvent(first, "POSSIBLE_SPLIT", "PILE-02"));
        assertFalse(containsEvent(first, "CANDIDATE_CONFIRMED", "PILE-02"));

        TrackManager.Update second = manager.update(Collections.singletonList(child));
        assertFalse(containsEvent(second, "CANDIDATE_CONFIRMED", "PILE-02"));

        TrackManager.Update third = manager.update(Collections.singletonList(child));
        assertTrue(containsEvent(third, "CANDIDATE_CONFIRMED", "PILE-02"));
        assertNotNull(findBox(third, "PILE-01"));
        assertNotNull(findBox(third, "PILE-02"));
        assertEquals(0.20f, findBox(third, "PILE-01").left, 0.0001f);
    }

    private static boolean containsEvent(TrackManager.Update update, String type, String id) {
        for (TrackManager.Event event : update.events) {
            if (type.equals(event.type) && id.equals(event.trackId)) return true;
        }
        return false;
    }

    private static TrackManager.TrackedBox findBox(TrackManager.Update update, String id) {
        for (TrackManager.TrackedBox box : update.visible) if (id.equals(box.id)) return box;
        return null;
    }
}
