package com.mj.stacktracker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Conservative master-object association. In locked-master mode, Pile 1 is seeded from the
 * user's rectangle; new pile tracks are permitted only when they have spatial continuity with
 * the locked object or an already tracked child. This gates many unrelated ROI contours, but
 * it is still classical proposal tracking and not semantic proof of a physical pile.
 */
public final class TrackManager {
    public static final class TrackedBox {
        public final String id;
        public final float left, top, right, bottom, confidence;
        public final boolean matchedFromPrevious;
        TrackedBox(String id, float l, float t, float r, float b, float c, boolean matched) {
            this.id=id; left=l; top=t; right=r; bottom=b; confidence=c; matchedFromPrevious=matched;
        }
    }
    public static final class Event {
        public final String type, trackId, details;
        public final float confidence;
        Event(String type, String id, float confidence, String details) {
            this.type=type; trackId=id; this.confidence=confidence; this.details=details;
        }
    }
    public static final class Update {
        public final List<TrackedBox> visible;
        public final List<Event> events;
        public final float frameConfidence;
        Update(List<TrackedBox> visible, List<Event> events, float confidence) {
            this.visible=visible; this.events=events; frameConfidence=confidence;
        }
    }

    private static final int MAX_MISSED_FRAMES = 12;
    private static final int MIN_HITS_TO_CONFIRM = 3;
    private final List<Track> tracks = new ArrayList<>();
    private final boolean lockedMasterLineage;
    private int nextId = 2;

    public TrackManager() { this(false); }
    public TrackManager(boolean lockedMasterLineage) { this.lockedMasterLineage=lockedMasterLineage; }

    /** Establish the initial, user-drawn object as Pile 1 before analysing later frames. */
    public void seedMaster(float[] box) {
        if (box == null || box.length < 4) return;
        tracks.clear();
        nextId=2;
        Track root=new Track();
        root.id="PILE-01";
        root.left=clamp01(box[0]); root.top=clamp01(box[1]);
        root.right=clamp01(box[2]); root.bottom=clamp01(box[3]);
        if (root.right < root.left) { float v=root.left; root.left=root.right; root.right=v; }
        if (root.bottom < root.top) { float v=root.top; root.top=root.bottom; root.bottom=v; }
        root.confidence=100f; root.missed=0; root.hits=MIN_HITS_TO_CONFIRM; root.confirmed=true; root.master=true;
        tracks.add(root);
    }

    public Update update(List<DetectionCandidate> detections) {
        List<Event> events=new ArrayList<>();
        List<Track> before=new ArrayList<>();
        for (Track t:tracks) before.add(t.copy());
        boolean[] usedTrack=new boolean[tracks.size()];
        List<TrackedBox> visible=new ArrayList<>();
        List<DetectionCandidate> ordered=new ArrayList<>(detections==null?Collections.emptyList():detections);
        ordered.sort(Comparator.comparingDouble((DetectionCandidate c)->c.detectorScore).reversed());
        int matchedCount=0;

        for (DetectionCandidate d:ordered) {
            // Exclude very weak shapes before temporal association. This is a conservative gate,
            // not a learned classifier; difficult lighting can still cause missed or false tracks.
            if (d == null || d.detectorScore < 50f) continue;
            int bestIndex=-1; float bestScore=0f;
            for (int i=0;i<tracks.size();i++) {
                if (i>=usedTrack.length || usedTrack[i]) continue;
                Track t=tracks.get(i);
                if (!t.master && t.missed>MAX_MISSED_FRAMES) continue;
                // Pile 1 is the user-locked whole object, not a generic contour. A much
                // smaller detached component must not steal the Pile 1 identity.
                if (lockedMasterLineage && t.master && !looksLikeWholeMaster(d,t)) continue;
                float score=associationScore(d,t);
                if (score>bestScore) { bestScore=score; bestIndex=i; }
            }
            Track chosen;
            boolean matched=bestIndex>=0 && bestScore>=0.30f;
            if (matched) {
                usedTrack[bestIndex]=true; chosen=tracks.get(bestIndex); matchedCount++;
                // Root follows plausible detections to handle gradual motion/size change. Child
                // tracks use the same smoothing to reduce jitter between neighbouring frames.
                chosen.left=0.35f*chosen.left+0.65f*d.left;
                chosen.top=0.35f*chosen.top+0.65f*d.top;
                chosen.right=0.35f*chosen.right+0.65f*d.right;
                chosen.bottom=0.35f*chosen.bottom+0.65f*d.bottom;
                chosen.confidence=clamp(0.75f*d.detectorScore+0.25f*bestScore*100f);
                boolean hadGap=chosen.missed>0;
                chosen.missed=0; chosen.hits=hadGap?1:chosen.hits+1;
            } else {
                Track possibleParent=findSplitParent(d,before);
                // In strict lineage mode, detections without a spatial link to Pile 1 or a
                // known child are discarded instead of becoming random scene IDs.
                if (lockedMasterLineage && possibleParent==null) continue;
                if (possibleParent==null) continue;
                float overlap=iou(d.left,d.top,d.right,d.bottom,
                        possibleParent.left,possibleParent.top,possibleParent.right,possibleParent.bottom);
                if (possibleParent.master && overlap>0.72f) continue; // likely the same whole object
                chosen=new Track(); chosen.id=makeId(nextId++);
                chosen.left=d.left; chosen.top=d.top; chosen.right=d.right; chosen.bottom=d.bottom;
                chosen.confidence=clamp(d.detectorScore*0.68f); chosen.missed=0; chosen.hits=1; chosen.parentId=possibleParent.id;
                tracks.add(chosen);
                usedTrack=java.util.Arrays.copyOf(usedTrack,tracks.size()); usedTrack[tracks.size()-1]=true;
                events.add(new Event("POSSIBLE_SPLIT",chosen.id,chosen.confidence,
                        "Candidate linked spatially to "+possibleParent.id+"; parent="+possibleParent.id+". Pile creation waits for three-frame persistence; the confirmed ledger is unchanged."));
            }
            if (!chosen.confirmed && chosen.hits>=MIN_HITS_TO_CONFIRM) {
                chosen.confirmed=true;
                events.add(new Event("CANDIDATE_CONFIRMED",chosen.id,chosen.confidence,
                        "Candidate persisted across three processed frames; parent="+(chosen.parentId==null?"UNKNOWN":chosen.parentId)+". This confirms a visual track only, not a verified physical stack."));
            }
            if (chosen.confirmed) {
                visible.add(new TrackedBox(chosen.id,chosen.left,chosen.top,chosen.right,chosen.bottom,chosen.confidence,matched));
            }
        }

        for (int i=0;i<tracks.size();i++) {
            Track t=tracks.get(i);
            if (i>=usedTrack.length || !usedTrack[i]) {
                t.missed++;
                if (t.confirmed && t.missed==MAX_MISSED_FRAMES+1) {
                    events.add(new Event("TRACK_NOT_VISIBLE",t.id,t.confidence,
                            "This pile track was not visible for multiple processed frames. It may be hidden or outside the work area; it is not automatically marked removed."));
                }
            }
        }
        // Pile 1 remains the locked reference even when detection is temporarily absent. Its box
        // is retained as a reference until the user resets the lock; child IDs require continuity.
        if (lockedMasterLineage) {
            for (Track t:tracks) if (t.master) {
                boolean already=false;
                for (TrackedBox b:visible) if (b.id.equals(t.id)) { already=true; break; }
                if (!already) visible.add(new TrackedBox(t.id,t.left,t.top,t.right,t.bottom,
                        Math.max(30f,t.confidence*(t.missed>0?0.98f:1f)),false));
            }
        }
        for (int i=tracks.size()-1;i>=0;i--) {
            Track t=tracks.get(i);
            if (t.master) continue;
            if ((!t.confirmed && t.missed>3) || (t.confirmed && t.missed>MAX_MISSED_FRAMES+30)) tracks.remove(i);
        }
        float average=0f; int childVisible=0;
        for (TrackedBox b:visible) { average+=b.confidence; childVisible++; }
        average=childVisible==0?0f:average/childVisible;
        float continuity=ordered.isEmpty()?0f:(float)matchedCount/Math.max(1,ordered.size());
        float frameConfidence=visible.isEmpty()?0f:clamp(average*(0.76f+0.24f*continuity));
        return new Update(Collections.unmodifiableList(visible),events,frameConfidence);
    }

    public void reset() { tracks.clear(); nextId=2; }
    private String makeId(int number) { return lockedMasterLineage?String.format(Locale.US,"PILE-%02d",number):String.format(Locale.US,"S%02d",number); }

    private Track findSplitParent(DetectionCandidate d,List<Track> previous) {
        Track best=null; float bestDistance=Float.MAX_VALUE; float cx=d.centerX(),cy=d.centerY();
        for (Track t:previous) {
            if (!t.confirmed) continue;
            if (!t.master && t.missed>MAX_MISSED_FRAMES) continue;
            float expand=Math.max(0.035f,Math.max(t.right-t.left,t.bottom-t.top)*0.30f);
            boolean near=cx>=t.left-expand&&cx<=t.right+expand&&cy>=t.top-expand&&cy<=t.bottom+expand;
            float score=iou(d.left,d.top,d.right,d.bottom,t.left,t.top,t.right,t.bottom);
            float dist=(float)Math.hypot(cx-(t.left+t.right)*0.5f,cy-(t.top+t.bottom)*0.5f);
            if (t.master) {
                // A contour lying almost entirely inside the original box and near its centre
                // is normally a detail of that same object, not a newly separated pile.
                float masterW=Math.max(1e-4f,t.right-t.left),masterH=Math.max(1e-4f,t.bottom-t.top);
                float masterArea=masterW*masterH;
                float intersection=intersectionArea(d.left,d.top,d.right,d.bottom,t.left,t.top,t.right,t.bottom);
                float candidateArea=Math.max(1e-5f,d.area());
                float contained=intersection/candidateArea;
                float normalizedDistance=(float)Math.hypot((cx-(t.left+t.right)*0.5f)/masterW,(cy-(t.top+t.bottom)*0.5f)/masterH);
                if (contained>0.88f && normalizedDistance<0.18f) continue;
                // A contour nearly as large as the locked object is likely its same visible
                // boundary, not an additional pile. Child candidates must be meaningfully smaller.
                if (candidateArea/masterArea>0.68f && score>0.40f) continue;
            }
            // A child must first appear near a known pile. Once created, its track may move
            // anywhere inside the user-defined work area while being associated over frames.
            if ((near||score>0.025f) && dist<bestDistance) { best=t; bestDistance=dist; }
        }
        return best;
    }

    private boolean looksLikeWholeMaster(DetectionCandidate d,Track t) {
        float masterArea=Math.max(1e-5f,(t.right-t.left)*(t.bottom-t.top));
        float ratio=d.area()/masterArea;
        // Keep a broad range for perspective and imperfect manual boxes, but reject obvious
        // child-sized contours. The locked box remains the reference if detection is lost.
        if (ratio < 0.62f || ratio > 2.4f) return false;
        float distance=(float)Math.hypot(d.centerX()-(t.left+t.right)*0.5f,d.centerY()-(t.top+t.bottom)*0.5f);
        float gate=Math.max(0.035f,0.90f*Math.max(t.right-t.left,t.bottom-t.top));
        float overlap=iou(d.left,d.top,d.right,d.bottom,t.left,t.top,t.right,t.bottom);
        return overlap>=0.08f || distance<=gate;
    }

    private float intersectionArea(float al,float at,float ar,float ab,float bl,float bt,float br,float bb) {
        float l=Math.max(al,bl),t=Math.max(at,bt),r=Math.min(ar,br),b=Math.min(ab,bb);
        return Math.max(0f,r-l)*Math.max(0f,b-t);
    }

    private float associationScore(DetectionCandidate d,Track t) {
        float overlap=iou(d.left,d.top,d.right,d.bottom,t.left,t.top,t.right,t.bottom);
        float dx=d.centerX()-(t.left+t.right)*0.5f,dy=d.centerY()-(t.top+t.bottom)*0.5f;
        float distance=(float)Math.sqrt(dx*dx+dy*dy);
        float dw=Math.max(d.width(),t.right-t.left),dh=Math.max(d.height(),t.bottom-t.top);
        float gate=Math.max(0.025f,0.75f*Math.max(dw,dh));
        if (distance>gate*2.5f && overlap<0.05f) return 0f;
        float distanceScore=Math.max(0f,1f-distance/(gate*2.5f));
        float a1=Math.max(1e-5f,d.area()),a2=Math.max(1e-5f,(t.right-t.left)*(t.bottom-t.top));
        float ratio=Math.max(a1,a2)/Math.min(a1,a2);
        float sizeScore=ratio>10f?0f:1f-(ratio-1f)/10f;
        return 0.58f*overlap+0.30f*distanceScore+0.12f*sizeScore;
    }

    private float iou(float al,float at,float ar,float ab,float bl,float bt,float br,float bb) {
        float l=Math.max(al,bl),t=Math.max(at,bt),r=Math.min(ar,br),b=Math.min(ab,bb);
        float inter=Math.max(0f,r-l)*Math.max(0f,b-t);
        float aa=Math.max(0f,ar-al)*Math.max(0f,ab-at),ba=Math.max(0f,br-bl)*Math.max(0f,bb-bt);
        float union=aa+ba-inter; return union<=0f?0f:inter/union;
    }
    private float clamp(float v) { return Math.max(0f,Math.min(100f,v)); }
    private float clamp01(float v) { return Math.max(0f,Math.min(1f,v)); }

    private static final class Track {
        String id, parentId; float left,top,right,bottom,confidence; int missed,hits; boolean confirmed,master;
        Track copy() { Track c=new Track();c.id=id;c.parentId=parentId;c.left=left;c.top=top;c.right=right;c.bottom=bottom;c.confidence=confidence;c.missed=missed;c.hits=hits;c.confirmed=confirmed;c.master=master;return c; }
    }
}
