# MJ Stack Tracker — Pile Tracking Phase 9.2

## Changes in this build

- **Video & Analysis panel:** video selection, movement-area marking, locked-object selection, count/thickness fields, both calibration controls, analyze/stop, and zoom reset are grouped together.
- **Model panel:** the 416-layer schematic, current pile list, and split/merge/inventory correction actions remain here.
- **Compact controls:** action buttons are reduced to 30 dp high with smaller text.
- **Locked object:** renamed from “LOCK INITIAL STACK” to **LOCK OBJECT**. The selected object seeds `PILE-01`; new child tracks are permitted only when they appear near the locked object/known child track and are spatially distinct from the central area of Pile 1. Child-sized contours cannot steal Pile 1 identity.
- **Work-area overlay:** the work-area rectangle hides after it is saved; the saved area remains active for detection. Choose MARK WORK AREA again to show/edit it.
- **Pile list/history:** starts with Pile 1 and the count entered by the user (default 416). When a visual child candidate persists across three processed frames, the app records a new pile and displays an approximate count. After analysis, the digital pile schematic follows the video playhead using saved Pile-created/count-updated timestamps, so play the clip to watch Pile 2, Pile 3, etc. appear in sequence. The History timeline stays complete; tapping a pile event seeks the source video to that time. Pile 1’s estimate is reduced by estimated child counts, but these remain estimates and do not update the confirmed ledger.
- **Session folder:** when analysis ends or is stopped, the app automatically writes one local folder per session with `session.json`, a readable `pile-history.csv`, separate optional `technical-events.json`, `source-video-reference.txt`, and a short README, then creates a shareable ZIP. History offers Open, Share Session ZIP, Share Source Video + Summary, and Delete History + Session Folder. Delete removes that session’s database records and local report folder/ZIP, never the original video in Gallery. To avoid duplicating a large video, the ZIP contains its reference rather than a copy of the video.
- **Technical detections:** raw contour/candidate logs are hidden by default because they are diagnostics; open “SHOW TECHNICAL DETECTIONS” only when troubleshooting.
- Existing JSON/CSV export and local SQLite history remain.

## Important accuracy limitation

This remains a classical OpenCV contour-based tracker; it is **not a trained semantic object detector**. It can reject unrelated detections that have no spatial lineage to the locked object, but reflective items, hands, overlap, perspective changes, occlusion, and motion can still produce missed or false candidates. Automatic pile quantities are **visual estimates**, not verified exact counts. With stack-side calibration they use projected height divided by the per-piece thickness; without it they use the child/master image-height ratio. That approximation can be wrong if the visible box height is not aligned with the stack thickness or the camera perspective changes. Estimated counts are kept out of the confirmed conservation ledger and should be reviewed against the video.

The schematic displays the latest saved pile estimates; it does not establish true 3D shape or prove that each conceptual layer is visible. Recalibrate after changing video zoom, framing, camera position, or orientation.

## Build from your Android phone using GitHub Actions

Upload these two files to the repository:

1. `MJ_STACK_TRACKER_PHASE9_2_PILE_TRACKING_SOURCE.zip` — upload to the repository **root** (same level as `app` would normally be).
2. `build-phase9-2-pile-tracking.yml` — upload to `.github/workflows/build-phase9-2-pile-tracking.yml`.

Use the filenames exactly. Do not keep `_copy`, `(1)`, or add `.zip` twice. Then open **GitHub → Actions → Build MJ Stack Tracker Phase 9.2 Pile Tracking**. The workflow validates the ZIP entries, extracts one source tree, runs the unit tests and assembles a debug APK. Download the artifact `MJ-Stack-Tracker-Phase9.2-debug-apk`; the APK is named `app-debug.apk` inside it.

Version: `0.9.2` (`versionCode 11`), package ID: `com.mj.stacktracker.phase9`. The package ID is unchanged to support an in-place upgrade if the same debug signing key is used.

## Suggested real-phone test

1. Select a recorded video. Mark the full possible movement area. After saving, confirm its blue rectangle is hidden.
2. Pause on the complete original pile, set its known count (e.g. 416) and piece thickness, then press LOCK OBJECT and draw around the object.
3. If the side of the stack is clearly visible, calibrate a known stack-side length. Calibrate the table plane separately only if needed for table-plane measurements.
4. Run analysis on a **short test clip first**. Check that Pile 1 starts at the known count, only spatially linked child candidates become new piles, and all `≈` counts are visibly marked as estimates.
5. Review history, share the Session ZIP and source video, delete a test session, and export CSV/JSON. Make sure the gallery video itself remains present after deleting history.
6. Check false detections and missed splits on several labelled clips before trusting any estimated counts.
