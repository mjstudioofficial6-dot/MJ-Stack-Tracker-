MJ Stack Tracker — Phase 1

Scope:
- Select one local video using the system picker.
- Play video with Media3 ExoPlayer.
- Use built-in play/pause/seek controls.
- Clear the selected video.
- No camera permission.
- No broad storage permission.
- No OpenCV, AI, counting, database, OCR, or cloud runtime.

Acceptance test:
1. Build through GitHub Actions.
2. Install APK on Android phone.
3. Tap Select Video.
4. Select a local video.
5. Video appears and plays.
6. Pause/play works.
7. Seek bar works.
8. Clear returns to the empty state.
9. App does not request camera or broad storage permission.
10. App does not crash on cancelling the picker.
