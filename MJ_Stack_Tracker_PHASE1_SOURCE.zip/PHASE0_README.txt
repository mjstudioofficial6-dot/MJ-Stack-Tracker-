MJ Stack Tracker — Phase 0 source

Purpose: prove that the Android project compiles in GitHub Actions, yields a debug APK,
and that APK installs and launches on the phone.

This build deliberately does NOT include video playback, overlays, OpenCV, AI, counting,
SQLite, camera access, cloud APIs, or internet permission. It is not the completed tracker.

Versions:
- Android Gradle Plugin: 9.4.0
- Gradle: 9.6.0 (installed by the CI workflow because the initial ZIP intentionally has no wrapper)
- JDK: 17
- compileSdk/targetSdk: 36
- minSdk: 26

Project files must be at the root of this ZIP, not inside a nested project folder.
