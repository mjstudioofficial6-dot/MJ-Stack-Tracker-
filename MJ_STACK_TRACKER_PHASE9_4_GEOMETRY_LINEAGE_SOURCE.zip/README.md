# MJ Stack Tracker — Geometry + Locked-Lineage Tracking (Phase 9.4)

## What Phase 9.4 changes

- The locked original object is the lineage root **Pile 1**. Its live tracking rectangle follows matching detected contours; it is not left at the old lock coordinates. Until a child is confirmed, a tiny contour cannot take over Pile 1 if its area differs from the original by more than 5.5×; after a confirmed split the gate allows a larger measured shrinkage. When evidence does not match, the live box disappears temporarily instead of claiming a small face is the whole pile.
- A split may produce multiple children in the same frame. A confirmed child may itself split, producing grandchildren. Each public pile ID keeps its parent link.
- New pile IDs require a candidate linked to a confirmed pile boundary, persistence across processed frames, and visible separation. Unrelated contours and contours fully inside a parent are not automatically promoted.
- If any pile, including Pile 1, is hidden or goes outside the marked area, its live box stops drawing. Its ID, last count and timestamp remain in History; invisibility is not treated as physical removal.
- A possible overlap/merge is recorded as a review status. The app does not silently delete the covered pile or rewrite its count.
- The detector allows up to 32 non-overlapping contour proposals per frame so a many-way split is not blocked by a small proposal cap. Proposals still need lineage checks to become piles.
- Rotated-contour dimensions are projected mathematically onto the calibrated stack-height axis. This avoids the former 0/90-degree major-vs-minor jump when the contour rotates.
- Counts are calculated from geometry: calibrated projected stack-axis height divided by the entered per-piece thickness when calibration agrees with the known original count; otherwise measured stack-axis span is compared with the locked original's measured span and known starting count. No child count is hard-coded as an example. Counts are estimates and are not forced to add up to 416.
- Persistent geometry changes are written as timestamped history events. History details include approximate dimensions and rough count uncertainty where the geometry calculation can estimate it. Pile 1's measured count may decrease as its visible stack geometry shrinks; newly separated piles get their own measured estimate. Balance differences are flagged for review rather than hidden by arithmetic forcing.

## What is actually measured

The app measures visible image contours and their rotated bounding dimensions. Table-plane scale is used for approximate visible length/width, and stack-side scale plus the calibrated stack-axis direction is used for approximate stack height. With consistent calibration, the count estimate is `measured stack-axis height (mm) / piece thickness (mm)`. If calibration conflicts with the known initial count, the app falls back to the measured child/original stack-axis span ratio multiplied by the known initial count. The app never treats a confidence score as measured accuracy.

This is still a classical OpenCV contour-proposal detector, not a trained semantic object-segmentation model. A contour can represent only a visible face rather than the whole physical pile, and hands, touching piles, occlusion, blur, reflections and perspective can confuse it. For a useful count, the marked region must be tight around the table area, the lock must surround the entire intact original pile, and the stack-side calibration line must run along the visible thickness direction of the pile. A single line does not solve full 3D perspective. Therefore this build makes tracking/measurement logic stricter but cannot honestly promise exact piece counts for every video without validating that actual video.

## Build on an Android phone

Upload these **two new files** to the repository:

1. `MJ_STACK_TRACKER_PHASE9_4_GEOMETRY_LINEAGE_SOURCE.zip` — upload to the repository root. Do not unzip it in GitHub.
2. `build-phase9-4-geometry-lineage.yml` — upload into `.github/workflows/` with exactly that filename.

Then open **GitHub → Actions → Build MJ Stack Tracker Phase 9.4 Geometry Lineage** and run the workflow. It verifies the archive, checks key regression controls, clears stale `app/` and Gradle project files from the runner, extracts only this ZIP, runs `testDebugUnitTest`, assembles a debug APK and verifies its package/version/signature.

Expected artifact: `MJ-Stack-Tracker-Phase9.4-debug-apk`; APK filename inside: `app-debug.apk`.

- Version: `0.9.4`, versionCode `13`.
- Application ID remains `com.mj.stacktracker.phase9` so an upgrade is possible if the debug signing key remains the same.
- Runtime uses no camera permission and no internet permission. Select an existing recorded video from the device.
- Build status: unit tests for the pure-Java geometry/tracker logic are run locally as part of source review. A full Android Gradle build is only confirmed when the new GitHub Actions run finishes successfully; it has not been claimed in advance.

## Test checklist

1. Select a short recorded clip and mark the whole movement area, excluding clocks, decorations and unrelated bright objects.
2. Pause while the entire original pile is intact, enter its known piece count and nominal thickness, select **LOCK OBJECT**, and draw around the full original.
3. Calibrate stack height along a visible pile-side thickness edge with a known real length. Re-check the calibration warning if it disagrees with the known starting count.
4. Play through one split, multiple simultaneous splits and a later split of a child pile. IDs should follow the object descendants rather than remain pinned at the initial rectangle.
5. Place a child on top of another pile, or move a pile out of view. It should be marked possibly merged/occluded or not visible; its history must remain.
6. Check the measured dimensions and estimate on the exact frames. Review warnings if estimates do not conserve the known total. Do not treat unverified estimates as exact counts.
7. Confirm session history/export works and deleting a session does not delete the Gallery source video.
