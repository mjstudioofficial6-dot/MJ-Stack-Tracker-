package com.mj.stacktracker;

/** A contour proposal with both its axis-aligned box and measured rotated-rectangle geometry. */
public final class DetectionCandidate {
    public final float left, top, right, bottom;
    /** Heuristic image-shape score from 0 to 100; it is not ground-truth accuracy. */
    public final float detectorScore;
    /** Major/minor rotated-rectangle axis lengths measured in source-video pixels. */
    public final float majorAxisPixels, minorAxisPixels;
    /** Major-axis direction in source-video pixel coordinates, degrees from +x. */
    public final float majorAxisAngleDegrees;
    /** Optional geometry/shape quality signals in [0,1]. */
    public final float solidity, neutralCoverage;
    public String trackId = "";

    /** Compatibility constructor for unit tests and callers that only have a box. */
    public DetectionCandidate(float left, float top, float right, float bottom, float detectorScore) {
        this(left, top, right, bottom, detectorScore, 0f, 0f, Float.NaN, 0f, 0f);
    }

    public DetectionCandidate(float left, float top, float right, float bottom, float detectorScore,
                              float majorAxisPixels, float minorAxisPixels, float majorAxisAngleDegrees,
                              float solidity, float neutralCoverage) {
        this.left = clamp(Math.min(left, right));
        this.top = clamp(Math.min(top, bottom));
        this.right = clamp(Math.max(left, right));
        this.bottom = clamp(Math.max(top, bottom));
        this.detectorScore = clampScore(detectorScore);
        this.majorAxisPixels = finitePositive(majorAxisPixels) ? majorAxisPixels : 0f;
        this.minorAxisPixels = finitePositive(minorAxisPixels) ? Math.min(minorAxisPixels, this.majorAxisPixels > 0f ? this.majorAxisPixels : minorAxisPixels) : 0f;
        this.majorAxisAngleDegrees = majorAxisAngleDegrees;
        this.solidity = clamp01(solidity);
        this.neutralCoverage = clamp01(neutralCoverage);
    }

    public float centerX() { return (left + right) * 0.5f; }
    public float centerY() { return (top + bottom) * 0.5f; }
    public float width() { return Math.max(0f, right - left); }
    public float height() { return Math.max(0f, bottom - top); }
    public float area() { return width() * height(); }
    public float aspectRatio() { return Math.max(width(), height()) / Math.max(1e-5f, Math.min(width(), height())); }

    private static boolean finitePositive(float v) { return Float.isFinite(v) && v > 0f; }
    private static float clampScore(float v) { return Math.max(0f, Math.min(100f, Float.isFinite(v) ? v : 0f)); }
    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, Float.isFinite(v) ? v : 0f)); }
    private static float clamp(float v) { return Math.max(0f, Math.min(1f, Float.isFinite(v) ? v : 0f)); }
}
