package com.mj.stacktracker;

/**
 * Geometry-derived measurements for identical flat pieces stacked into piles.
 * Counts are estimates: the measured stack-axis span is divided by piece thickness, or
 * proportioned against the known original stack when calibration is not trustworthy.
 */
public final class StackGeometry {
    private StackGeometry() {}

    public static final class Measurement {
        public final double lengthMm;
        public final double widthMm;
        public final double stackHeightMm;
        public final double stackAxisPixels;
        public final double absolutePieces;
        public final double relativePieces;
        public final double countSigma;
        public final String countMethod;
        public final boolean hasPhysicalHeight;

        Measurement(double lengthMm, double widthMm, double stackHeightMm, double stackAxisPixels,
                    double absolutePieces, double relativePieces, double countSigma,
                    String countMethod, boolean hasPhysicalHeight) {
            this.lengthMm = lengthMm;
            this.widthMm = widthMm;
            this.stackHeightMm = stackHeightMm;
            this.stackAxisPixels = stackAxisPixels;
            this.absolutePieces = absolutePieces;
            this.relativePieces = relativePieces;
            this.countSigma = countSigma;
            this.countMethod = countMethod;
            this.hasPhysicalHeight = hasPhysicalHeight;
        }

        public int roundedPieces(boolean useAbsolute) {
            double value = useAbsolute ? absolutePieces : relativePieces;
            if (!Double.isFinite(value) || value <= 0d) return -1;
            return (int)Math.max(1d, Math.min(100000d, Math.round(value)));
        }
    }

    /** Projected span of a rotated rectangle along the calibrated stack-height axis. */
    public static double axisSpanPixels(double majorPixels, double minorPixels,
                                        double majorAngleDegrees, double axisAngleDegrees) {
        if (!positive(majorPixels) || !positive(minorPixels)) return Double.NaN;
        if (!Double.isFinite(axisAngleDegrees) || !Double.isFinite(majorAngleDegrees)) {
            return Math.min(majorPixels, minorPixels);
        }
        // Orthogonal projection of the rotated rectangle onto the calibrated physical
        // stack-height axis. Selecting only major/minor at a 45-degree threshold loses
        // a large part of the real projected span and creates count jumps during rotation.
        double delta = Math.toRadians(normalizeAxisDelta(majorAngleDegrees - axisAngleDegrees));
        return Math.abs(Math.cos(delta)) * majorPixels + Math.abs(Math.sin(delta)) * minorPixels;
    }

    /** Projection of an axis-aligned locked rectangle along a selected image-space axis. */
    public static double projectedBoxSpanPixels(double widthPixels, double heightPixels, double axisAngleDegrees) {
        if (!positive(widthPixels) || !positive(heightPixels)) return Double.NaN;
        if (!Double.isFinite(axisAngleDegrees)) return Math.min(widthPixels, heightPixels);
        double r = Math.toRadians(axisAngleDegrees);
        return Math.abs(Math.cos(r)) * widthPixels + Math.abs(Math.sin(r)) * heightPixels;
    }

    public static Measurement measure(double majorPixels, double minorPixels, double majorAngleDegrees,
                                      double tablePixelsPerMm, double sidePixelsPerMm,
                                      double sideAxisAngleDegrees, double pieceThicknessMm,
                                      double originalStackAxisPixels, int originalPieceCount) {
        double major = positive(majorPixels) ? majorPixels : Double.NaN;
        double minor = positive(minorPixels) ? minorPixels : Double.NaN;
        double axisSpan = axisSpanPixels(major, minor, majorAngleDegrees, sideAxisAngleDegrees);
        double lengthMm = positive(tablePixelsPerMm) && Double.isFinite(major) ? major / tablePixelsPerMm : Double.NaN;
        double widthMm = positive(tablePixelsPerMm) && Double.isFinite(minor) ? minor / tablePixelsPerMm : Double.NaN;
        double heightMm = positive(sidePixelsPerMm) && Double.isFinite(axisSpan) ? axisSpan / sidePixelsPerMm : Double.NaN;
        double absolutePieces = positive(heightMm) && positive(pieceThicknessMm) ? heightMm / pieceThicknessMm : Double.NaN;
        double relativePieces = positive(axisSpan) && positive(originalStackAxisPixels) && originalPieceCount > 0
                ? originalPieceCount * axisSpan / originalStackAxisPixels : Double.NaN;
        double sigma = Double.NaN;
        String method = "relative stack-axis span against locked original";
        if (Double.isFinite(absolutePieces) && positive(pieceThicknessMm)) {
            double sigmaHeightMm = Math.max(heightMm * 0.05d, positive(sidePixelsPerMm) ? 0.5d / sidePixelsPerMm : 0.5d);
            double sigmaThicknessMm = pieceThicknessMm * 0.05d;
            sigma = MetricMath.countSigma(heightMm, pieceThicknessMm, sigmaHeightMm, sigmaThicknessMm);
            method = "calibrated stack-axis height / piece thickness";
        } else if (Double.isFinite(relativePieces)) {
            sigma = Math.max(2d, relativePieces * 0.25d);
        }
        return new Measurement(lengthMm, widthMm, heightMm, axisSpan, absolutePieces,
                relativePieces, sigma, method, Double.isFinite(heightMm));
    }

    public static boolean calibrationConsistentWithKnownCount(double originalStackAxisPixels,
                                                               double sidePixelsPerMm,
                                                               double pieceThicknessMm,
                                                               int knownOriginalCount,
                                                               double allowedRelativeError) {
        if (!positive(originalStackAxisPixels) || !positive(sidePixelsPerMm) || !positive(pieceThicknessMm)
                || knownOriginalCount <= 0 || !Double.isFinite(allowedRelativeError) || allowedRelativeError < 0d) return false;
        double measured = originalStackAxisPixels / sidePixelsPerMm / pieceThicknessMm;
        return Double.isFinite(measured) && Math.abs(measured - knownOriginalCount) / knownOriginalCount <= allowedRelativeError;
    }

    private static double normalizeAxisDelta(double degrees) {
        double d = degrees % 180d;
        if (d > 90d) d -= 180d;
        if (d < -90d) d += 180d;
        return d;
    }
    private static boolean positive(double v) { return Double.isFinite(v) && v > 0d; }
}
