package com.mj.stacktracker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Multi-pile, locked-lineage tracker.
 *
 * The original lock seeds Pile 1; a matched contour updates its predicted position so the green
 * marker follows motion instead of staying at the lock coordinates. Any number of child tracks
 * may be born from one parent in the same frame, and a confirmed child may itself spawn children.
 * A public pile ID is allocated only after persistent parent-linked separation. The detector is
 * still a classical contour proposal system: lineage gates reduce false positives but do not make
 * contour proposals semantic proof of a real physical stack.
 */
public final class TrackManager {
    public static final class TrackedBox {
        public final String id, parentId;
        public final float left, top, right, bottom, confidence;
        public final boolean matchedFromPrevious;
        public final float majorAxisPixels, minorAxisPixels, majorAxisAngleDegrees;

        TrackedBox(String id, float l, float t, float r, float b, float c, boolean matched) {
            this(id, null, l, t, r, b, c, matched, 0f, 0f, Float.NaN);
        }
        TrackedBox(String id, String parentId, float l, float t, float r, float b, float c,
                   boolean matched, float majorAxisPixels, float minorAxisPixels, float majorAxisAngleDegrees) {
            this.id=id; this.parentId=parentId; left=l; top=t; right=r; bottom=b; confidence=c;
            matchedFromPrevious=matched; this.majorAxisPixels=majorAxisPixels;
            this.minorAxisPixels=minorAxisPixels; this.majorAxisAngleDegrees=majorAxisAngleDegrees;
        }
        public float width(){return Math.max(0f,right-left);}
        public float height(){return Math.max(0f,bottom-top);}
        public float area(){return width()*height();}
    }

    public static final class Event {
        public final String type, trackId, parentId, details;
        public final float confidence;
        Event(String type, String id, String parentId, float confidence, String details) {
            this.type=type; trackId=id; this.parentId=parentId; this.confidence=confidence; this.details=details;
        }
        Event(String type, String id, float confidence, String details) { this(type,id,null,confidence,details); }
    }

    public static final class Update {
        public final List<TrackedBox> visible;
        public final List<Event> events;
        public final float frameConfidence;
        Update(List<TrackedBox> visible, List<Event> events, float confidence) {
            this.visible=visible; this.events=events; frameConfidence=confidence;
        }
    }

    private static final int MAX_MISSED_FRAMES = 12;
    private static final int MIN_HITS_TO_CONFIRM = 3;
    private static final int MIN_DETACHED_FRAMES_TO_CONFIRM = 2;
    private static final float MIN_DETECTOR_SCORE = 58f;
    private static final float MAX_PARENT_CONTAINMENT = 0.80f;
    private static final float MIN_CHILD_OUTSIDE_FRACTION = 0.22f;

    private final List<Track> tracks = new ArrayList<>();
    private final boolean lockedMasterLineage;
    private int nextId = 2;
    private int nextPendingId = 1;

    public TrackManager() { this(false); }
    public TrackManager(boolean lockedMasterLineage) { this.lockedMasterLineage=lockedMasterLineage; }

    /** Establish the user's drawn original stack as Pile 1 before processing later video frames. */
    public void seedMaster(float[] box) {
        if (box == null || box.length < 4) return;
        tracks.clear(); nextId=2; nextPendingId=1;
        Track root=new Track(); root.id="PILE-01"; root.master=true; root.confirmed=true;
        root.left=clamp01(box[0]); root.top=clamp01(box[1]); root.right=clamp01(box[2]); root.bottom=clamp01(box[3]);
        if(root.right<root.left){float v=root.left;root.left=root.right;root.right=v;}
        if(root.bottom<root.top){float v=root.top;root.top=root.bottom;root.bottom=v;}
        root.confidence=100f;root.hits=MIN_HITS_TO_CONFIRM;root.missed=0;tracks.add(root);
    }

    public Update update(List<DetectionCandidate> detections) {
        List<Event> events=new ArrayList<>();
        List<Track> before=copyTracks(tracks);
        List<DetectionCandidate> ordered=new ArrayList<>(detections==null?Collections.emptyList():detections);
        ordered.removeAll(Collections.singleton(null));
        ordered.sort(Comparator.comparingDouble((DetectionCandidate c)->c.detectorScore).reversed());

        // Global greedy matching prevents candidate iteration order from repeatedly stealing a track.
        List<Pair> pairs=new ArrayList<>();
        for(int ti=0;ti<tracks.size();ti++){
            Track t=tracks.get(ti);
            if(!t.master&&t.missed>MAX_MISSED_FRAMES)continue;
            for(int di=0;di<ordered.size();di++){
                DetectionCandidate d=ordered.get(di);
                if(d.detectorScore<MIN_DETECTOR_SCORE)continue;
                float score=associationScore(d,t);
                float threshold=t.master?0.20f:0.27f;
                if(score>=threshold)pairs.add(new Pair(ti,di,score));
            }
        }
        pairs.sort((a,b)->Float.compare(b.score,a.score));
        boolean[] usedDetection=new boolean[ordered.size()];
        Set<String> matchedTrackIds=new HashSet<>();
        Set<String> matchedChildIds=new HashSet<>();
        List<Match> acceptedMatches=new ArrayList<>();
        int matchedCount=0;
        for(Pair pair:pairs){
            if(pair.trackIndex>=tracks.size()||usedDetection[pair.detectionIndex])continue;
            Track t=tracks.get(pair.trackIndex);
            if(matchedTrackIds.contains(t.id))continue;
            DetectionCandidate d=ordered.get(pair.detectionIndex);
            updateTrackFromDetection(t,d,pair.score,before);
            usedDetection[pair.detectionIndex]=true;matchedTrackIds.add(t.id);matchedCount++;
            if(!t.master)matchedChildIds.add(t.id);
            acceptedMatches.add(new Match(t,d,pair.detectionIndex));
            if(!t.confirmed&&canConfirm(t)){
                t.confirmed=true;
                if(lockedMasterLineage&&!t.master&&t.id.startsWith("PENDING-"))t.id=makeId(nextId++);
                events.add(new Event("CANDIDATE_CONFIRMED",t.id,t.parentId,t.confidence,
                        "Persistent child pile linked to parent "+safeParent(t.parentId)+". Track follows movement and may itself split. "
                                +"Estimated piece count must come from measured stack geometry and be reviewed if the view is ambiguous."));
                matchedTrackIds.remove("PENDING-CONFIRMED-PLACEHOLDER");
                matchedTrackIds.add(t.id);
                if(!t.master)matchedChildIds.add(t.id);
            }
            if(t.confirmed&&t.mergeAlerted)t.mergeAlerted=false;
        }

        // If a larger contour has swallowed a previously tracked child, preserve the old identity
        // in History and flag a possible merge/occlusion rather than silently calling it removed.
        emitPossibleMerges(acceptedMatches,before,matchedTrackIds,events);

        // A single parent may create MANY children on the same frame. Do not limit this to one.
        // A child may also be the parent of a later generation of piles.
        for(int di=0;di<ordered.size();di++){
            if(usedDetection[di])continue;
            DetectionCandidate d=ordered.get(di);
            if(d.detectorScore<MIN_DETECTOR_SCORE)continue;
            Track parent=findSplitParent(d,tracks);
            if(parent==null)parent=findSplitParent(d,before);
            if(parent==null)continue;
            Track pending=new Track();
            pending.id=lockedMasterLineage?String.format(Locale.US,"PENDING-%04d",nextPendingId++):makeId(nextId++);
            pending.parentId=parent.id;pending.master=false;pending.confirmed=false;
            pending.left=d.left;pending.top=d.top;pending.right=d.right;pending.bottom=d.bottom;
            pending.confidence=clamp(d.detectorScore*0.70f);pending.hits=1;pending.missed=0;
            pending.birthCenterX=d.centerX();pending.birthCenterY=d.centerY();
            pending.birthParentGap=rectGap(d,parent);
            pending.birthParentScale=Math.max(parent.right-parent.left,parent.bottom-parent.top);
            pending.majorAxisPixels=d.majorAxisPixels;pending.minorAxisPixels=d.minorAxisPixels;
            pending.majorAxisAngleDegrees=d.majorAxisAngleDegrees;
            tracks.add(pending);usedDetection[di]=true;matchedTrackIds.add(pending.id);
        }

        // Tracks not matched in this frame are never drawn at their old fixed screen position.
        for(Track t:tracks){
            if(!matchedTrackIds.contains(t.id)){
                t.missed++;
                if(t.confirmed&&t.missed==MAX_MISSED_FRAMES+1){
                    events.add(new Event("TRACK_NOT_VISIBLE",t.id,t.parentId,t.confidence,
                            "This pile is no longer visibly trackable at this timestamp. Its ID and prior estimates remain in History; disappearance does not mean removal."));
                }
            }
        }
        for(int i=tracks.size()-1;i>=0;i--){
            Track t=tracks.get(i);
            if(t.master)continue;
            if((!t.confirmed&&t.missed>3)||(t.confirmed&&t.missed>MAX_MISSED_FRAMES+30))tracks.remove(i);
        }

        List<TrackedBox> visible=new ArrayList<>();
        float avg=0f;int n=0;
        for(Track t:tracks){
            // Only boxes matched to a detection in the current frame are emitted.
            if(!t.confirmed||!matchedTrackIds.contains(t.id))continue;
            visible.add(asBox(t,true));avg+=t.confidence;n++;
        }
        float continuity=ordered.isEmpty()?0f:(float)matchedCount/Math.max(1,ordered.size());
        float frameConfidence=n==0?0f:clamp((avg/n)*(0.76f+0.24f*continuity));
        return new Update(Collections.unmodifiableList(visible),events,frameConfidence);
    }

    public void reset(){tracks.clear();nextId=2;nextPendingId=1;}

    private void updateTrackFromDetection(Track t,DetectionCandidate d,float score,List<Track> before){
        float oldCx=(t.left+t.right)*0.5f,oldCy=(t.top+t.bottom)*0.5f;
        float newCx=d.centerX(),newCy=d.centerY();
        float deltaX=newCx-oldCx,deltaY=newCy-oldCy;
        t.velocityX=0.55f*t.velocityX+0.45f*deltaX;
        t.velocityY=0.55f*t.velocityY+0.45f*deltaY;
        // Follow the measured object position strongly. A smoothed box keeps contour jitter readable.
        t.left=0.25f*t.left+0.75f*d.left;t.top=0.25f*t.top+0.75f*d.top;
        t.right=0.25f*t.right+0.75f*d.right;t.bottom=0.25f*t.bottom+0.75f*d.bottom;
        t.confidence=clamp(0.72f*d.detectorScore+0.28f*score*100f);
        boolean hadGap=t.missed>0;t.missed=0;t.hits=hadGap?1:t.hits+1;
        if(d.majorAxisPixels>0f){
            t.majorAxisPixels=smoothGeometry(t.majorAxisPixels,d.majorAxisPixels,0.60f);
            t.minorAxisPixels=smoothGeometry(t.minorAxisPixels,d.minorAxisPixels,0.60f);
            t.majorAxisAngleDegrees=smoothAxisAngle(t.majorAxisAngleDegrees,d.majorAxisAngleDegrees,0.60f);
        }
        if(lockedMasterLineage&&!t.master&&!t.confirmed)updateSeparationEvidence(t,d,before);
    }

    private boolean canConfirm(Track t){
        return t.hits>=MIN_HITS_TO_CONFIRM&&(!lockedMasterLineage||t.master||t.separationFrames>=MIN_DETACHED_FRAMES_TO_CONFIRM);
    }

    private float associationScore(DetectionCandidate d,Track t){
        float currentW=Math.max(1e-4f,t.right-t.left),currentH=Math.max(1e-4f,t.bottom-t.top);
        float predCx=(t.left+t.right)*0.5f+t.velocityX;
        float predCy=(t.top+t.bottom)*0.5f+t.velocityY;
        float pl=predCx-currentW*0.5f,pr=predCx+currentW*0.5f;
        float pt=predCy-currentH*0.5f,pb=predCy+currentH*0.5f;
        float overlap=iou(d.left,d.top,d.right,d.bottom,pl,pt,pr,pb);
        float dist=(float)Math.hypot(d.centerX()-predCx,d.centerY()-predCy);
        float scale=Math.max(Math.max(d.width(),d.height()),Math.max(currentW,currentH));
        float speed=(float)Math.hypot(t.velocityX,t.velocityY);
        float gate=Math.max(0.018f,scale*0.38f+speed*1.50f+Math.min(0.08f,t.missed*0.004f));
        if(dist>gate*2.1f&&overlap<0.02f)return 0f;
        float distanceScore=Math.max(0f,1f-dist/(gate*2.1f));
        float dArea=Math.max(1e-6f,d.area()),tArea=Math.max(1e-6f,currentW*currentH);
        float ratio=Math.max(dArea,tArea)/Math.min(dArea,tArea);
        if(ratio>24f)return 0f;
        float sizeScore=1f-(ratio-1f)/23f;
        float a1=d.aspectRatio(),a2=Math.max(currentW,currentH)/Math.max(1e-5f,Math.min(currentW,currentH));
        float shapeRatio=Math.max(a1,a2)/Math.max(1e-5f,Math.min(a1,a2));
        float shapeScore=shapeRatio>10f?0.02f:1f-(shapeRatio-1f)/9f;
        float angleScore=1f;
        if(d.majorAxisPixels>0f&&t.majorAxisPixels>0f&&Float.isFinite(d.majorAxisAngleDegrees)&&Float.isFinite(t.majorAxisAngleDegrees)){
            double rad=Math.toRadians(axisDelta(d.majorAxisAngleDegrees-t.majorAxisAngleDegrees));
            angleScore=(float)Math.max(0.1d,Math.abs(Math.cos(rad)));
        }
        // The locked root is mobile, but a tiny bright contour must not take over Pile 1.
        // Before any real child has been confirmed, allow only moderate area change. After a
        // confirmed direct child exists, allow a larger parent-size change because a genuine
        // split can reduce the remaining pile substantially. If evidence is ambiguous, hide
        // the live root box for that frame rather than relabel a small card/shine as Pile 1.
        if(lockedMasterLineage&&t.master){
            boolean confirmedDirectChild=false;
            for(Track other:tracks){
                if(!other.master&&other.confirmed&&t.id.equals(other.parentId)&&other.missed<=MAX_MISSED_FRAMES){
                    confirmedDirectChild=true;break;
                }
            }
            float maxAreaRatio=confirmedDirectChild?18f:5.5f;
            if(ratio>maxAreaRatio)return 0f;
        }
        return clamp01(0.43f*overlap+0.32f*distanceScore+0.13f*sizeScore+0.07f*shapeScore+0.05f*angleScore);
    }

    private Track findSplitParent(DetectionCandidate d,List<Track> candidates){
        if(candidates==null)return null;
        Track best=null;float bestScore=-1f;
        float candidateArea=Math.max(1e-6f,d.area());
        for(Track t:candidates){
            if(!t.confirmed||(!t.master&&t.missed>MAX_MISSED_FRAMES))continue;
            float parentArea=Math.max(1e-6f,(t.right-t.left)*(t.bottom-t.top));
            float parentScale=Math.max(t.right-t.left,t.bottom-t.top);
            // A component may be larger than the remaining parent after a large split.
            if(candidateArea>parentArea*1.28f)continue;
            float contained=intersectionArea(d.left,d.top,d.right,d.bottom,t.left,t.top,t.right,t.bottom)/candidateArea;
            float outside=1f-contained;
            if(contained>MAX_PARENT_CONTAINMENT||outside<MIN_CHILD_OUTSIDE_FRACTION)continue;
            float gap=rectGap(d,t);
            float tolerance=Math.max(0.0035f,parentScale*0.035f);
            if(gap>tolerance)continue;
            float predCx=(t.left+t.right)*0.5f+t.velocityX,predCy=(t.top+t.bottom)*0.5f+t.velocityY;
            float dist=(float)Math.hypot(d.centerX()-predCx,d.centerY()-predCy);
            if(dist>Math.max(0.035f,parentScale*1.25f))continue;
            float edgeLink=1f-Math.min(1f,gap/Math.max(1e-5f,tolerance));
            float outsideScore=Math.min(1f,outside/0.50f);
            float score=0.55f*edgeLink+0.25f*outsideScore+0.20f*(1f-Math.min(1f,dist/Math.max(0.035f,parentScale*1.25f)));
            if(score>bestScore){bestScore=score;best=t;}
        }
        return best;
    }

    private void updateSeparationEvidence(Track child,DetectionCandidate d,List<Track> previous){
        Track parent=findById(previous,child.parentId);
        if(parent==null)parent=findById(tracks,child.parentId);
        if(parent==null)return;
        float candidateArea=Math.max(1e-6f,d.area());
        float inside=intersectionArea(d.left,d.top,d.right,d.bottom,parent.left,parent.top,parent.right,parent.bottom)/candidateArea;
        float outside=1f-inside;
        float gap=rectGap(d,parent);
        float parentScale=Math.max(parent.right-parent.left,parent.bottom-parent.top);
        float minGap=Math.max(0.0035f,parentScale*0.025f);
        float moved=(float)Math.hypot(d.centerX()-child.birthCenterX,d.centerY()-child.birthCenterY);
        boolean clearlyDetached=gap>=minGap&&outside>=0.90f&&moved>=Math.max(0.006f,parentScale*0.04f);
        if(clearlyDetached)child.separationFrames++;else child.separationFrames=Math.max(0,child.separationFrames-1);
    }

    private void emitPossibleMerges(List<Match> accepted,List<Track> previous,Set<String> matchedIds,List<Event> events){
        for(Match m:accepted){
            Track receiver=m.track;
            float candidateArea=Math.max(1e-6f,m.detection.area());
            for(Track old:previous){
                if(old.master||!old.confirmed||old.id.equals(receiver.id)||matchedIds.contains(old.id)||old.mergeAlerted)continue;
                float oldArea=Math.max(1e-6f,(old.right-old.left)*(old.bottom-old.top));
                float intersection=intersectionArea(m.detection.left,m.detection.top,m.detection.right,m.detection.bottom,old.left,old.top,old.right,old.bottom);
                float overlap=iou(m.detection.left,m.detection.top,m.detection.right,m.detection.bottom,old.left,old.top,old.right,old.bottom);
                float oldCoverage=intersection/oldArea;
                float dist=(float)Math.hypot(m.detection.centerX()-(old.left+old.right)*0.5f,m.detection.centerY()-(old.top+old.bottom)*0.5f);
                float nearGate=Math.max(0.02f,Math.max(old.right-old.left,old.bottom-old.top)*0.50f);
                if(overlap>=0.18f||oldCoverage>=0.65f||(candidateArea>=oldArea*1.20f&&dist<=nearGate)){
                    old.mergeAlerted=true;
                    Track current=findById(tracks,old.id);if(current!=null)current.mergeAlerted=true;
                    events.add(new Event("PILE_MERGE_SUSPECTED",old.id,old.parentId,Math.min(receiver.confidence,old.confidence),
                            "Pile may be stacked onto or hidden by "+receiver.id+". Keep its count/ID in History; no physical removal is inferred."));
                }
            }
        }
    }

    private Track findById(List<Track> list,String id){if(id==null||list==null)return null;for(Track t:list)if(id.equals(t.id))return t;return null;}
    private List<Track> copyTracks(List<Track> input){List<Track> out=new ArrayList<>();for(Track t:input)out.add(t.copy());return out;}
    private TrackedBox asBox(Track t,boolean matched){return new TrackedBox(t.id,t.parentId,t.left,t.top,t.right,t.bottom,t.confidence,matched,t.majorAxisPixels,t.minorAxisPixels,t.majorAxisAngleDegrees);}
    private String makeId(int number){return lockedMasterLineage?String.format(Locale.US,"PILE-%02d",number):String.format(Locale.US,"S%02d",number);}
    private String safeParent(String parent){return parent==null?"the locked object":parent;}
    private float smoothGeometry(float old,float now,float weight){return old<=0f?now:old*(1f-weight)+now*weight;}
    private float smoothAxisAngle(float old,float now,float weight){if(!Float.isFinite(now))return old;if(!Float.isFinite(old))return now;double a=Math.toRadians(old*2d),b=Math.toRadians(now*2d);double x=(1d-weight)*Math.cos(a)+weight*Math.cos(b),y=(1d-weight)*Math.sin(a)+weight*Math.sin(b);return (float)(0.5d*Math.toDegrees(Math.atan2(y,x)));}
    private float axisDelta(float d){d%=180f;if(d>90f)d-=180f;if(d< -90f)d+=180f;return d;}
    private float intersectionArea(float al,float at,float ar,float ab,float bl,float bt,float br,float bb){float l=Math.max(al,bl),t=Math.max(at,bt),r=Math.min(ar,br),b=Math.min(ab,bb);return Math.max(0f,r-l)*Math.max(0f,b-t);}
    private float rectGap(DetectionCandidate d,Track t){float dx=Math.max(0f,Math.max(t.left-d.right,d.left-t.right));float dy=Math.max(0f,Math.max(t.top-d.bottom,d.top-t.bottom));return (float)Math.hypot(dx,dy);}
    private float iou(float al,float at,float ar,float ab,float bl,float bt,float br,float bb){float inter=intersectionArea(al,at,ar,ab,bl,bt,br,bb);float aa=Math.max(0f,ar-al)*Math.max(0f,ab-at),ba=Math.max(0f,br-bl)*Math.max(0f,bb-bt);float union=aa+ba-inter;return union<=0f?0f:inter/union;}
    private float clamp(float v){return Math.max(0f,Math.min(100f,Float.isFinite(v)?v:0f));}
    private float clamp01(float v){return Math.max(0f,Math.min(1f,Float.isFinite(v)?v:0f));}

    private static final class Pair {final int trackIndex,detectionIndex;final float score;Pair(int t,int d,float s){trackIndex=t;detectionIndex=d;score=s;}}
    private static final class Match {final Track track;final DetectionCandidate detection;final int detectionIndex;Match(Track t,DetectionCandidate d,int i){track=t;detection=d;detectionIndex=i;}}
    private static final class Track {
        String id,parentId;float left,top,right,bottom,confidence,velocityX,velocityY;
        float majorAxisPixels,minorAxisPixels,majorAxisAngleDegrees=Float.NaN;
        int missed,hits,separationFrames;float birthCenterX,birthCenterY,birthParentGap,birthParentScale;
        boolean confirmed,master,mergeAlerted;
        Track copy(){Track c=new Track();c.id=id;c.parentId=parentId;c.left=left;c.top=top;c.right=right;c.bottom=bottom;c.confidence=confidence;c.velocityX=velocityX;c.velocityY=velocityY;c.majorAxisPixels=majorAxisPixels;c.minorAxisPixels=minorAxisPixels;c.majorAxisAngleDegrees=majorAxisAngleDegrees;c.missed=missed;c.hits=hits;c.separationFrames=separationFrames;c.birthCenterX=birthCenterX;c.birthCenterY=birthCenterY;c.birthParentGap=birthParentGap;c.birthParentScale=birthParentScale;c.confirmed=confirmed;c.master=master;c.mergeAlerted=mergeAlerted;return c;}
    }
}
