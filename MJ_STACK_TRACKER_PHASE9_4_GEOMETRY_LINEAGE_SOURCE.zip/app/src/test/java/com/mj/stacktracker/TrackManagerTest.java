package com.mj.stacktracker;

import org.junit.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static org.junit.Assert.*;

/** Regression tests for motion following, multiple children, recursive splits and lineage safety. */
public class TrackManagerTest {
    private static final float[] MASTER={0.20f,0.20f,0.60f,0.60f};
    private static DetectionCandidate root(){return new DetectionCandidate(0.20f,0.20f,0.60f,0.60f,99f);}
    private static DetectionCandidate childA(float left){return new DetectionCandidate(left,0.27f,left+0.15f,0.37f,95f);}
    private static DetectionCandidate childB(float left){return new DetectionCandidate(left,0.43f,left+0.15f,0.53f,94f);}
    private static DetectionCandidate childAt(float left,float top,float bottom,float score){return new DetectionCandidate(left,top,left+0.15f,bottom,score);}
    private static TrackManager manager(){TrackManager m=new TrackManager(true);m.seedMaster(MASTER);return m;}

    @Test public void unrelatedContourDoesNotCreatePileAndStaleRootBoxIsHidden(){
        TrackManager m=manager();
        TrackManager.Update u=m.update(Collections.singletonList(new DetectionCandidate(0.82f,0.80f,0.93f,0.90f,99f)));
        assertTrue(u.events.isEmpty());assertNull(find(u,"PILE-01"));assertNull(find(u,"PILE-02"));
    }

    @Test public void lockedObjectFollowsMovementInsteadOfStayingAtLockCoordinates(){
        TrackManager m=new TrackManager(true);m.seedMaster(new float[]{0.10f,0.20f,0.30f,0.40f});
        TrackManager.Update first=m.update(Collections.singletonList(new DetectionCandidate(0.10f,0.20f,0.30f,0.40f,99f)));
        TrackManager.Update second=m.update(Collections.singletonList(new DetectionCandidate(0.13f,0.20f,0.33f,0.40f,99f)));
        TrackManager.Update third=m.update(Collections.singletonList(new DetectionCandidate(0.16f,0.20f,0.36f,0.40f,99f)));
        assertNotNull(find(first,"PILE-01"));assertNotNull(find(second,"PILE-01"));
        assertTrue("tracking rectangle should move with the object",find(third,"PILE-01").left>0.14f);
    }


    @Test public void masterPileDisappearanceIsLoggedButIdentityCanReturn(){
        TrackManager m=manager();
        assertNotNull(find(m.update(Collections.singletonList(root())),"PILE-01"));
        boolean notVisible=false;
        for(int i=0;i<14;i++){
            TrackManager.Update u=m.update(Collections.<DetectionCandidate>emptyList());
            notVisible|=hasEvent(u,"TRACK_NOT_VISIBLE","PILE-01");
        }
        assertTrue("Pile 1 disappearance must be recorded, not treated as deletion",notVisible);
        TrackManager.Update returned=m.update(Collections.singletonList(root()));
        assertNotNull("the same Pile 1 identity can reacquire its contour",find(returned,"PILE-01"));
        assertNull(find(returned,"PILE-02"));
    }

    @Test public void smallBrightContourCannotTakeOverPileOneBeforeAnySplitIsConfirmed(){
        TrackManager m=new TrackManager(true);m.seedMaster(new float[]{0.20f,0.20f,0.45f,0.45f});
        // This candidate is spatially nearby but its area is 1/25 of the locked object.
        // It may be a single card face/reflection, not the complete remaining pile.
        DetectionCandidate tiny=new DetectionCandidate(0.36f,0.29f,0.41f,0.34f,99f);
        TrackManager.Update u=m.update(Collections.singletonList(tiny));
        assertNull(find(u,"PILE-01"));
        assertNull(find(u,"PILE-02"));
        assertTrue(u.events.isEmpty());
    }

    @Test public void oneParentCanCreateFourChildPilesInSameSplit(){
        TrackManager m=manager();
        java.util.function.Function<Float,List<DetectionCandidate>> frameAt=left -> Arrays.asList(
                root(), childAt(left,0.22f,0.26f,98f), childAt(left,0.28f,0.32f,97f),
                childAt(left,0.34f,0.38f,96f), childAt(left,0.40f,0.44f,95f));
        m.update(frameAt.apply(0.55f));
        m.update(frameAt.apply(0.62f));
        m.update(frameAt.apply(0.64f));
        TrackManager.Update confirmed=m.update(frameAt.apply(0.65f));
        assertNotNull(find(confirmed,"PILE-01"));
        assertEquals("the four child piles plus Pile 1 must all be tracked",5,confirmed.visible.size());
        for(int number=2;number<=5;number++){
            TrackManager.TrackedBox child=find(confirmed,String.format(java.util.Locale.US,"PILE-%02d",number));
            assertNotNull("split child " + number + " must have its own track",child);
            assertEquals("PILE-01",child.parentId);
        }
    }

    @Test public void aConfirmedChildCanItselfSplitIntoGrandchildren(){
        TrackManager m=manager();
        // Confirm Pile 2 at the right edge of Pile 1.
        m.update(Arrays.asList(root(),childA(0.55f)));
        m.update(Arrays.asList(root(),childA(0.62f)));
        TrackManager.Update confirmed=m.update(Arrays.asList(root(),childA(0.64f)));
        assertNotNull(find(confirmed,"PILE-02"));
        // A second component first touches Pile 2, then separates across frames.
        DetectionCandidate grand1=new DetectionCandidate(0.72f,0.28f,0.84f,0.35f,96f);
        DetectionCandidate parent2=new DetectionCandidate(0.64f,0.27f,0.79f,0.37f,95f);
        m.update(Arrays.asList(root(),parent2,grand1));
        for(int i=0;i<3;i++){
            float left=0.80f+i*0.005f;
            TrackManager.Update u=m.update(Arrays.asList(root(),parent2,new DetectionCandidate(left,0.28f,left+0.12f,0.35f,96f)));
            if(i==2)assertNotNull("grandchild track should get its own ID",find(u,"PILE-03"));
        }
        assertEquals("PILE-02",find(m.update(Arrays.asList(root(),parent2,new DetectionCandidate(0.81f,0.28f,0.93f,0.35f,96f))),"PILE-03").parentId);
    }

    @Test public void nestedContoursDoNotBecomeChildPiles(){
        TrackManager m=manager();
        DetectionCandidate inner=new DetectionCandidate(0.36f,0.30f,0.49f,0.40f,98f);
        for(int i=0;i<8;i++){
            TrackManager.Update u=m.update(Arrays.asList(root(),inner));
            assertEquals(1,u.visible.size());assertEquals("PILE-01",u.visible.get(0).id);
            assertFalse(hasEvent(u,"CANDIDATE_CONFIRMED","PILE-02"));
        }
    }

    @Test public void mergedOrCoveredPileIsLoggedButNotMarkedRemoved(){
        TrackManager m=manager();
        m.update(Arrays.asList(root(),childA(0.55f)));
        m.update(Arrays.asList(root(),childA(0.62f)));
        TrackManager.Update confirmed=m.update(Arrays.asList(root(),childA(0.64f)));
        assertNotNull(find(confirmed,"PILE-02"));
        DetectionCandidate larger=new DetectionCandidate(0.20f,0.20f,0.80f,0.60f,99f);
        TrackManager.Update merged=m.update(Collections.singletonList(larger));
        assertTrue(hasEvent(merged,"PILE_MERGE_SUSPECTED","PILE-02"));
    }

    @Test public void invisiblePileStopsDrawingButItsNotVisibleEventCanBeSaved(){
        TrackManager m=manager();
        m.update(Arrays.asList(root(),childA(0.55f)));
        m.update(Arrays.asList(root(),childA(0.62f)));
        TrackManager.Update confirmed=m.update(Arrays.asList(root(),childA(0.64f)));
        assertNotNull(find(confirmed,"PILE-02"));
        TrackManager.Update last=null;boolean savedNotVisible=false;
        for(int i=0;i<14;i++){last=m.update(Collections.singletonList(root()));savedNotVisible|=hasEvent(last,"TRACK_NOT_VISIBLE","PILE-02");}
        assertNull(find(last,"PILE-02"));assertTrue(savedNotVisible);
    }

    private static TrackManager.TrackedBox find(TrackManager.Update u,String id){for(TrackManager.TrackedBox b:u.visible)if(id.equals(b.id))return b;return null;}
    private static boolean hasEvent(TrackManager.Update u,String type,String id){for(TrackManager.Event e:u.events)if(type.equals(e.type)&&id.equals(e.trackId))return true;return false;}
}
