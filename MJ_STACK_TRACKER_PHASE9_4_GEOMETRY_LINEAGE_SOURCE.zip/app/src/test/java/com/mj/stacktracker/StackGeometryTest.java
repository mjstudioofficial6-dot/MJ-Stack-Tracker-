package com.mj.stacktracker;

import org.junit.Test;
import static org.junit.Assert.*;

/** Regression tests for rotated stack-height selection and geometry-based count estimates. */
public class StackGeometryTest {
    @Test public void sideAxisUsesTrueProjectionOfRotatedRectangle(){
        assertEquals(100d,StackGeometry.axisSpanPixels(100,20,0,0),0.001);
        assertEquals(84.8528137d,StackGeometry.axisSpanPixels(100,20,0,45),0.001);
        assertEquals(20d,StackGeometry.axisSpanPixels(100,20,0,90),0.001);
    }

    @Test public void calibratedHeightCalculatesCountFromPixelsAndPieceThickness(){
        StackGeometry.Measurement m=StackGeometry.measure(100,10,0,2,2,90,0.5,100,416);
        assertEquals(50d,m.lengthMm,0.001);
        assertEquals(5d,m.widthMm,0.001);
        assertEquals(5d,m.stackHeightMm,0.001);
        assertEquals(10d,m.absolutePieces,0.001);
        assertEquals(10,m.roundedPieces(true));
    }

    @Test public void relativeEstimateUsesMeasuredSpanAndKnownStartingCountNotSampleCounts(){
        StackGeometry.Measurement m=StackGeometry.measure(100,25,0,Double.NaN,Double.NaN,90,0.33,100,416);
        assertEquals(104d,m.relativePieces,0.001);
        assertEquals(104,m.roundedPieces(false));
        assertFalse(m.hasPhysicalHeight);
    }

    @Test public void incompatibleCalibrationIsRejectedInsteadOfSilentlyChangingKnownCount(){
        assertTrue(StackGeometry.calibrationConsistentWithKnownCount(137.28,1,0.33,416,0.05));
        assertFalse(StackGeometry.calibrationConsistentWithKnownCount(30,1,0.33,416,0.25));
    }

    @Test public void invalidCalibrationProducesUncalibratedDimensionsInsteadOfFakeValues(){
        StackGeometry.Measurement m=StackGeometry.measure(100,20,0,Double.NaN,Double.NaN,Double.NaN,0.33,100,416);
        assertTrue(Double.isNaN(m.lengthMm));assertTrue(Double.isNaN(m.widthMm));
        assertEquals(83.2,m.relativePieces,0.001);
    }
}
