# Phase 9.4 — Geometry and Locked-Lineage Requirement Audit

## Specific failures seen in the Phase 9.3 screenshots

1. The green rectangle sometimes followed a small bright contour, not necessarily the complete physical pile. The screen's heuristic confidence is not a real object-recognition accuracy percentage.
2. Pile creation used parent-boundary/persistence evidence but the tracker could allow only one child per parent in a frame in an earlier revision, preventing a multi-way split from being represented correctly.
3. Rotated geometry selected either the major or minor bounding dimension at a 45-degree boundary. Rotating a pile or camera axis could change the count estimate abruptly even without a physical change.
4. Count estimates based on a contour's projected span can be wrong when the detector contour is only a visible face, calibration is misaligned, or perspective changes. The app must flag inconsistent calibration and avoid forcing estimates to the known total.

## Phase 9.4 code-level controls

- `TrackManager` matches tracks against predicted positions, updates each visible box from the current detection, allows multiple children from one parent, preserves recursive parent IDs, and gives children public IDs only after persistent, detached parent-linked evidence. Before a child is confirmed, a contour whose area differs from the locked root by more than 5.5× cannot take over Pile 1; after a direct child is confirmed the limit relaxes to 18× so a real reduction in parent size can be followed. Ambiguous cases hide the root box instead of drawing it on a tiny face.
- Unrelated far-away proposals and fully nested contours are rejected from lineage. Child tracks can themselves be split parents after confirmation.
- An absent confirmed root or child stops rendering a stale box. `TRACK_NOT_VISIBLE`/`PILE_STATUS` keeps the prior pile ID/count in history; `PILE_MERGE_SUSPECTED` retains history and does not call it removed.
- `FrameDetector` measures a rotated contour bounding rectangle and considers up to 32 non-overlapping proposals per frame. These are contour proposals, not semantic segmentation.
- `StackGeometry.axisSpanPixels` uses the true rectangular projection `|cos(delta)| × major + |sin(delta)| × minor` along the calibrated stack-height axis. Dimensions/counts are derived from measured pixels and calibration, not preset output quantities.
- If calibrated height divided by thickness disagrees with the known initial piece count by more than the allowed error, absolute calibration is rejected and estimates use measured stack-axis span ratio against the known initial object. This does not guarantee accuracy if the detected contour is not the complete pile.
- Count updates require a persistent geometry change over three processed frames. The software does not silently force child+parent estimates to equal the original inventory; it emits an explicit review event when the totals disagree.
- History is human-readable and timestamped, including created pile count, parent pile number, changed count, not-visible status, merge/occlusion suspicion, and approximate measured dimensions.
- Existing JSON `JSONArray.put(Object)` workaround is retained. AndroidX Core `1.17.0` remains declared for `FileProvider`.

## Regression tests

`TrackManagerTest` covers: unrelated contour rejection, root movement, simultaneous sibling children, grandchild creation, nested contour rejection, suspected merge retention, and a hidden track disappearing from the overlay but retaining a status event.

`StackGeometryTest` covers: projection along a calibrated axis at 0°, 45° and 90°, converting calibrated height/thickness to count, relative count from measured span, rejecting incompatible calibration, and refusing to generate physical dimensions from invalid calibration.

The local source-review run compiles and executes the pure-Java tracker/geometry tests with a lightweight local JUnit-compatible runner. These checks do not replace the GitHub Actions Android Gradle build. A successful APK build should only be claimed after the workflow's unit test, assemble, metadata, and signature steps pass.

## Known limitation that is not hidden

The current detector is classical OpenCV contour proposal plus tracking gates. It cannot infer an invisible back edge, separate overlapping identical objects when image evidence has merged, or guarantee semantic whole-pile segmentation. Calibration is a local 2D scale, not full perspective-correct 3D reconstruction. The build improves track lineage and avoids misleading arithmetic, but exact counts require short labelled-video validation and possibly a future segmentation/model module if contour evidence is insufficient.
