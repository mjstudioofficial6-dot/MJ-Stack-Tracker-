# MJ Stack Tracker — BUILD-0

## Purpose

BUILD-0 is a deliberately minimal Android build checkpoint. It verifies the Android project structure and GitHub Actions build path before adding video playback, tracking overlays, OpenCV, stack matching, or automated quantity estimation.

## Fixed configuration

- Android application ID: `com.mjthakur.stacktracker`
- Language: Java
- Android Gradle Plugin: `9.4.0`
- Gradle distribution used by CI: `9.6.0`
- JDK: `17`
- Compile/target SDK: `36`
- Minimum SDK: `26`
- No third-party Android runtime dependencies in BUILD-0
- No camera permission, cloud AI, Firebase, login, or network runtime requirement

## Important build detail

This source archive intentionally does not rely on a pre-uploaded Gradle Wrapper binary. The GitHub Actions workflow first extracts the archive into the repository workspace, verifies that `build.gradle` and `settings.gradle` are at the project root, provisions pinned Gradle 9.6.0, generates a Gradle Wrapper on the runner, and builds with that wrapper. This avoids the earlier failure where Gradle setup ran while the repository contained only a ZIP and no visible Gradle project files.

## What BUILD-0 does not yet do

This is not the finished stack tracker. It only provides a minimal app screen so the repository/build pipeline can be verified. Video importing, playback, manual calibration, red/blue overlays, image enhancement, perspective correction, automatic quantity estimation, split/merge tracking, database history, and export are subsequent development steps.

## Build command after extraction

```bash
gradle --no-daemon wrapper --gradle-version 9.6.0 --distribution-type bin
./gradlew --no-daemon --stacktrace clean assembleDebug
```

Expected debug APK path:

```text
app/build/outputs/apk/debug/app-debug.apk
```

A successful workflow build still needs installation and launch testing on the target Android phone.
