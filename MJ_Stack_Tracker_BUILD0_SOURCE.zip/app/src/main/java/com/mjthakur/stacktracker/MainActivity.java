package com.mjthakur.stacktracker;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Build-0 checkpoint only. This screen confirms that the Android project can be
 * compiled and launched before video, OpenCV, tracking, and database features
 * are added in small, testable stages.
 */
public final class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_VERTICAL);
        int padding = dp(24);
        root.setPadding(padding, padding, padding, padding);
        root.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView title = new TextView(this);
        title.setText("MJ Stack Tracker");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);

        TextView version = new TextView(this);
        version.setText("BUILD-0  |  Android project check");
        version.setTextSize(16);
        version.setPadding(0, dp(8), 0, dp(20));
        root.addView(version);

        TextView status = new TextView(this);
        status.setText(
                "This is the first build checkpoint.\n\n"
                + "Next modules will be added one at a time:\n"
                + "1. Video import and player\n"
                + "2. Red/blue tracking overlay\n"
                + "3. Frame filters and calibration\n"
                + "4. Digital stack and quantity engine\n"
                + "5. Local history and verification\n\n"
                + "No camera access, cloud AI, login, or network service is used by this checkpoint."
        );
        status.setTextSize(16);
        status.setLineSpacing(dp(3), 1.0f);
        root.addView(status);

        setContentView(root);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
