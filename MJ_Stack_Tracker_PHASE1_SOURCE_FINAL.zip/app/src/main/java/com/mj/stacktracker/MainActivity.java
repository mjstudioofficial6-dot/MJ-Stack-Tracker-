package com.mj.stacktracker;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

/**
 * Phase 1 UI correction: local video selection and playback only.
 * The player uses a landscape 16:9 viewport; the surrounding app UI stays white.
 * No OpenCV, AI, counting, database, or camera access is included.
 */
public final class MainActivity extends Activity {
    private static final int REQUEST_VIDEO = 1001;

    private ExoPlayer player;
    private PlayerView playerView;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFFFFFFF);

        // Android 15/16 edge-to-edge: keep app content below the status bar
        // and above the navigation area instead of drawing text underneath them.
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int top;
            int bottom;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets bars = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            view.setPadding(0, top, 0, bottom);
            return insets;
        });

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER);
        header.setPadding(dp(12), dp(8), dp(12), dp(10));

        TextView title = new TextView(this);
        title.setText("MJ Stack Tracker");
        title.setTextColor(0xFF202124);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);
        header.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView subtitle = new TextView(this);
        subtitle.setText("Phase 1 — Video Player");
        subtitle.setTextColor(0xFF5F6368);
        subtitle.setTextSize(13);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        subtitleParams.topMargin = dp(2);
        header.addView(subtitle, subtitleParams);

        root.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        // YouTube-like landscape video viewport: full available width, 16:9 height.
        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerView.setBackgroundColor(0xFF000000);
        int screenWidthPx = getResources().getDisplayMetrics().widthPixels;
        int videoHeightPx = Math.round(screenWidthPx * 9f / 16f);
        root.addView(playerView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, videoHeightPx));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(dp(12), dp(8), dp(12), 0);

        Button selectButton = new Button(this);
        selectButton.setText("Select Video");
        selectButton.setOnClickListener(v -> openVideoPicker());
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(
                0, dp(48), 1.0f);
        buttonParams.rightMargin = dp(6);
        controls.addView(selectButton, buttonParams);

        Button clearButton = new Button(this);
        clearButton.setText("Clear");
        clearButton.setOnClickListener(v -> clearVideo());
        LinearLayout.LayoutParams clearParams = new LinearLayout.LayoutParams(
                0, dp(48), 1.0f);
        clearParams.leftMargin = dp(6);
        controls.addView(clearButton, clearParams);

        root.addView(controls, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        statusText = new TextView(this);
        statusText.setText("No video selected. Tap Select Video.");
        statusText.setTextColor(0xFF5F6368);
        statusText.setTextSize(14);
        statusText.setPadding(dp(16), dp(10), dp(16), dp(4));
        root.addView(statusText, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView scope = new TextView(this);
        scope.setText("Phase 1: local video playback, pause and seek.\n"
                + "Counting and video analysis will be added in later phases.");
        scope.setTextColor(0xFF5F6368);
        scope.setTextSize(13);
        scope.setPadding(dp(16), dp(4), dp(16), dp(12));
        root.addView(scope, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void openVideoPicker() {
        Intent intent;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent = new Intent(MediaStore.ACTION_PICK_IMAGES);
            intent.setType("video/*");
        } else {
            intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("video/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        }
        try {
            startActivityForResult(intent, REQUEST_VIDEO);
        } catch (Exception e) {
            Toast.makeText(this, "Video picker unavailable on this device.",
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_VIDEO || resultCode != RESULT_OK || data == null) {
            return;
        }

        Uri uri = data.getData();
        if (uri == null) {
            statusText.setText("No video selected.");
            return;
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            try {
                getContentResolver().takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (SecurityException ignored) {
                // Some providers do not offer persistable permission.
            }
        }

        playVideo(uri);
    }

    private void playVideo(Uri uri) {
        releasePlayer();

        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setMediaItem(MediaItem.fromUri(uri));
        player.prepare();
        player.play();

        statusText.setText("Video loaded. Use the player controls to play, pause and seek.");
    }

    private void clearVideo() {
        releasePlayer();
        playerView.setPlayer(null);
        statusText.setText("No video selected. Tap Select Video.");
    }

    private void releasePlayer() {
        if (player != null) {
            player.release();
            player = null;
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) {
            player.pause();
        }
    }

    @Override
    protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }
}
