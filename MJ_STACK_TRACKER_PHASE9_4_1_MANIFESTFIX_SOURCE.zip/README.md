# MJ Stack Tracker — Phase 9.4.1 Manifest Fix

This is a **new corrective source package**, not a renamed copy. It fixes the exact failure in the Phase 9.4 GitHub Actions screenshots:

`Error parsing app/src/main/AndroidManifest.xml`

**Root cause confirmed:** `AndroidManifest.xml` line 5 used a raw ampersand (`&`) in the `android:label` attribute (`Geometry & Lineage`). XML attributes must escape it as `&amp;`. The corrected label is `MJ Stack Tracker — Geometry &amp; Lineage 9.4.1`.

## Files to upload from your phone

1. Upload `MJ_STACK_TRACKER_PHASE9_4_1_MANIFESTFIX_SOURCE.zip` to the repository root. **Do not unzip it in GitHub.**
2. Upload `build-phase9-4-1-manifestfix.yml` into `.github/workflows/` using that exact filename.
3. Run **GitHub → Actions → Build MJ Stack Tracker Phase 9.4.1 Manifest Fix → Run workflow**.

The workflow now parses every XML file inside the source ZIP *before* invoking Gradle. If any XML is malformed, it stops with the precise path and parser error instead of waiting until `processDebugMainManifest`.

## Build metadata

- Version name: `0.9.4.1`
- Version code: `14`
- Application ID unchanged: `com.mj.stacktracker.phase9`
- The prior Phase 9.4 source and package names are not reused as this release's identifiers.
- Expected Actions artifact: `MJ-Stack-Tracker-Phase9.4.1-debug-apk`
- APK inside artifact: `app-debug.apk`

## Important status note

The corrected manifest and every XML file in this package were parsed locally, and the source ZIP was integrity-checked. The complete Android Gradle build has **not** been run in this environment. Consider the APK build verified only after the GitHub workflow's XML preflight, unit tests, `assembleDebug`, package/version check, and signing verification all pass.

## Runtime and measurement limitations

The app remains offline at runtime, uses an existing video selected from the phone, and requests neither camera nor internet permission. Tracking and count estimation still depend on visible OpenCV contours and calibration. A confirmed/clean Android build does not by itself prove that every physical pile can be measured exactly; test splits, merges, occlusion, and the actual measurement output using a short labelled video.
