# Phase 10.2 Requirement Audit

## Preserved
- Native Android Java app.
- Local video picker and Media3 playback.
- OpenCV image analysis on-device.
- Offline runtime; no camera or Internet permission.
- Initial inventory remains 416 cards.
- No manual mm calibration and no 1/2/3-card teaching popup.
- Existing application ID preserved for upgrade compatibility.

## Phase 10.2 repairs
- Presence tracking no longer depends on quantity confidence.
- Stable unknown-quantity pile regions are visible in the Pile-wise list.
- A new child cannot inherit PILE-01's 416-card quantity from proximity alone.
- Root matching uses its immutable opening geometry, preventing track drift.
- Split transition marks the old root as not currently accounted when multiple child regions appear.
- Unknown pile observations cannot alter counts or create transfer events.
- Short occlusion identity continuity is supported.
- Quantity measurement stores two-edge span for diagnostics, while the count gate still requires at least three periodic edges.
- UI displays visible unknown pile count and quantity rejection reason.

## Acceptance still outstanding
- Run the Phase 10.2 GitHub Actions workflow and install the APK.
- Verify four child identities on the supplied video on the Android build.
- Record true per-pile quantities at labelled video timestamps.
- Verify one-card and 20–25-card physical move accuracy against an independent ground-truth log.
- Verify end-to-end source/destination transfer matching on physical test footage.
