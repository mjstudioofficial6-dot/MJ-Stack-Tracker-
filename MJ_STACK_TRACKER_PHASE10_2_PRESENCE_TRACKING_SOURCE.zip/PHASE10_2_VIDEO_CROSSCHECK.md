# Phase 10.2 — Original Video Cross-check

## Input

`VID_20261028_173908.mp4` (test video supplied in the conversation; deliberately not bundled in source ZIP)

- 1920 × 1080
- 30 FPS
- 650 frames
- 21.667 seconds

## Reproduced tabletop candidate policy

The local OpenCV 4.13 reproduction used the Phase 10.1 tabletop colour mask, tabletop ROI, morphology, contour extraction, normalized geometry gates and IoU suppression. It sampled at the same 180 ms interval as the Android analyzer.

| Metric | Result |
|---|---:|
| Requested sample timestamps | 121 |
| Frames decoded by local reproduction | 121 |
| Frames with at least one tabletop candidate | 84 |
| Maximum simultaneous candidates | 4 |
| Final samples (20.16–21.60 s) with four candidates | 9 of 9 |

The four final candidate bounding boxes at 1280×720 analysis size, from the final sampled frame, were approximately:

| Candidate | x | y | width | height |
|---|---:|---:|---:|---:|
| A | 744 | 443 | 72 | 42 |
| B | 667 | 459 | 68 | 37 |
| C | 441 | 444 | 77 | 35 |
| D | 565 | 463 | 64 | 31 |

## Phase 10.1 failure diagnosed

1. The detector found four final candidate regions, but the quantity estimator returned zero quantity-valid observations in the APK's final status.
2. The source estimator required visible repeated layer-edge evidence. Two peaks alone produced edge periodicity around 0.0583, below the 0.08 threshold.
3. When fewer than three peaks existed, the measurement code fell back to the entire candidate bounding-box extent. This could select the long face dimension rather than a stack-layer span and then produce an out-of-range relative ratio.
4. The transfer engine created new tracks only inside `if (observation.countValid)`. Consequently, valid tabletop candidates with unknown quantities were dropped rather than displayed as separate piles.
5. The previous root guard compared child footprint to the most recently matched root box, allowing PILE-01 to drift across successive smaller regions. Phase 10.2 compares presence-only root matching against the immutable opening anchor instead.

## Phase 10.2 corrections

- The selected measurement axis now prefers a direction with multiple peaks rather than a single high-energy edge on the other axis.
- Edge-to-edge span is retained for two or more peaks for diagnostics, but the count estimator still refuses a quantity unless at least three visible layer edges and periodic spacing are present.
- Rejection reasons are exposed, so the app can report why candidate counts remain unknown.
- Presence-only regions are tracked with stable IDs after two observations.
- Unknown pile identity is never treated as a numeric quantity.
- Root identity is anchored to the opening footprint; a multi-region split no longer leaves the full 416 count attached to an invisible child.
- Track IDs tolerate short occlusions, and a returning pile can match its existing track.
- UI displays visible pile count and visible unknown-quantity count separately.

## Regression evidence

A Java test feeds the actual four final-frame candidate boxes through the temporal engine sequence extracted from the supplied video. It verifies four visible, separate unknown pile tracks, all 416 cards unassigned, and no invented transfer. A second test verifies that synthetic valid measured changes of 1, 20 and 25 cards can be paired into source/destination transfer events. These tests validate engine behavior once measurements are declared valid; they do not establish visual 1/20/25-card sensitivity.

## Unverified

- Exact number of cards in each final pile.
- One-card change detection on the original video.
- 20–25-card physical movement accuracy.
- Real-video source/destination transfer matching.
- Full Android build and APK runtime of Phase 10.2 (must be confirmed by its GitHub Actions run and phone test).
