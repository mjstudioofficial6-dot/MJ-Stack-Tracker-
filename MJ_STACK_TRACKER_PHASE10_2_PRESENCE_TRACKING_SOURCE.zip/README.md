# MJ Stack Tracker — Phase 10.2 Presence Tracking

## What this build fixes

Phase 10.1 successfully decoded the supplied video and detected up to four tabletop candidate regions, but it still showed only `PILE-01` and did not list the child piles. The cause was in the tracking contract: `AutomaticTransferEngine` created a new pile track only when the quantity estimator had already returned a valid card count. A visible pile with an untrusted quantity was therefore discarded before it could receive an identity.

Phase 10.2 separates **pile presence** from **card quantity**:

- A region that persists across two samples can receive a stable `PILE-02`, `PILE-03`, etc. identity.
- The row displays `Quantity unknown` until repeated, quantity-valid image measurements are available.
- Presence-only observations never change the inventory ledger and never create transfer events.
- The original `PILE-01` identity is anchored to its opening footprint, so it cannot drift from one smaller child pile to another and keep all 416 cards incorrectly assigned.
- After a split, if the original deck is no longer matched and multiple child regions appear, the original 416 cards become unassigned until child quantities can be measured.
- Short occlusions are tolerated for track identity, but hidden quantities are not counted as currently accounted inventory.

## Quantity measurement safeguards

The earlier image measurement used the full candidate bounding-box span whenever fewer than three edge peaks were found. This could use the wrong extent as a stack-layer measurement. Phase 10.2 instead retains the detected edge-to-edge span when at least two peaks exist, and prefers the axis that actually has multiple edge peaks over an axis with only one strong boundary.

This does **not** make two peaks enough for counting. The quantity estimator deliberately requires at least three visible layer edges and sufficient periodicity/confidence. A pile can therefore be tracked and shown while its quantity stays unknown. The confidence threshold is not lowered just to make the result look complete.

## Current verification

- Original test video inspected: 1920×1080, 30 FPS, 650 frames, approximately 21.67 seconds.
- A local OpenCV reproduction sampled 121 timestamps at 180 ms, decoded 121, found tabletop candidates in 84 samples, and found up to four candidates in one frame.
- The final 9 sampled frames each contained four candidate regions.
- A Java regression test uses the four actual final-frame candidate boxes and verifies that the engine stabilizes four separate unknown-quantity pile tracks without inventing a transfer or a card count.
- 24 pure-Java regression test methods passed locally, including presence tracking, split/root identity, temporary occlusion, synthetic 1/20/25-card transfer pairing, count rejection and tabletop false-positive tests.
- All app main Java sources passed syntax/type compilation against lightweight Android/Media3/OpenCV API stubs; this does not replace a real Android SDK build.
- The final source ZIP, XML files and the workflow's 26 embedded source-validation gates passed local checks.
- The Android Gradle build and APK packaging still need to run in the new GitHub Actions workflow.

These are pile-presence and engine-regression checks. They are **not** proof of exact card-count accuracy on this video.

## GitHub upload

Upload the following three files:

1. `MJ_STACK_TRACKER_PHASE10_2_PRESENCE_TRACKING_SOURCE.zip` — repository root.
2. `build-phase10-2-presence-tracking.yml` — `.github/workflows/build-phase10-2-presence-tracking.yml`.
3. `README.md` — repository root.

Keep the previous Phase 10 and Phase 10.1 files until the new build succeeds and the APK is installed. The source archive contains the Android project at its root; do not extract it into an extra nested folder before uploading it as the source ZIP.

## Build

Open GitHub → Actions → **Build MJ Stack Tracker Phase 10.2 Presence Tracking** → Run workflow.

The workflow validates the source ZIP and required files, runs `testDebugUnitTest`, builds the debug APK, checks its package/version/signature and verifies that CAMERA and INTERNET permissions are absent. It uploads the APK and build diagnostics as separate artifacts.

## Phone test

Use the same `VID_20261028_173908.mp4` video:

1. Select the video and press PLAY & ANALYZE.
2. Confirm analysis reaches the end of the 121 requested samples.
3. In the final part, look for four visible pile regions with separate IDs.
4. Until quantities pass the visual gate, each should say `Quantity unknown (pile region tracked)`; the app must not invent a 104/104/104/104 split.
5. The original `PILE-01` may remain in history as not currently visible; it must not be treated as a currently visible 416-card pile after the split.
6. Transfer History should remain empty unless independently measured source and destination quantity changes match.

For exact quantity validation, use a separately recorded ground-truth event log. The present video does not identify the exact card quantity in every pile at every timestamp, and it cannot establish one-card accuracy by itself.

## Compatibility and constraints

- Application ID remains `com.mj.stacktracker.phase9` for upgrade compatibility with the prior APK.
- Version name: `1.0.2`.
- Version code: `18`.
- Native Android Java application.
- On-device OpenCV and Media3 video playback.
- Offline runtime; no Firebase, remote AI or server-side video analysis.
- No camera permission and no Internet permission.
- GitHub Actions is used only for build/test packaging.
- Starting inventory: 416 cards.
- No manual mm calibration or 1/2/3-card teaching popup is introduced.
