# Phase 10.2 Test Plan

## Unit/regression tests

1. Opening known inventory seeds PILE-01 at 416.
2. Unknown child pile receives a stable ID but no quantity.
3. A smaller nearby child cannot inherit PILE-01's 416 quantity.
4. Four presence-only regions become four separate unknown pile tracks.
5. A pile returns to the same identity after a short occlusion.
6. Original video final candidate boxes produce four stable unknown pile identities.
7. Two valid measured pile counts preserve the 416-card inventory.
8. A transfer is emitted only when source decrease and destination increase match exactly.
9. Presence-only changes never create a transfer.
10. Synthetic valid 1, 20 and 25-card measurement deltas are represented correctly by the transfer engine.
11. Two edge peaks without periodic evidence remain unassigned.
12. Non-periodic edges remain unassigned.
13. Out-of-range relative spans remain unassigned.
14. Arithmetic-only relative estimator tests cover 1, 2, 20 and half-deck count ratios.
15. Tabletop candidate policy accepts the opening deck and four final pile boxes.
16. Tabletop candidate policy rejects representative scenery, table text, small props and dealer-side equipment.

## GitHub build checks

- Validate ZIP integrity and safe paths.
- Require each expected source/test file.
- Parse all XML files.
- Verify application ID and Phase 10.2 version metadata.
- Verify offline permissions and local processing dependencies.
- Run `gradle clean testDebugUnitTest assembleDebug`.
- Verify APK package metadata, signature and permission list.
- Upload APK, SHA-256/signing data and diagnostics.

## Manual phone acceptance

- Install the Phase 10.2 APK as an upgrade over Phase 10.1.
- Select the same video.
- Confirm playback and analysis completion.
- Confirm final four visible regions have separate IDs and unknown quantities rather than disappearing.
- Confirm no child is assigned a guessed count.
- Confirm transfer history is created only after both sides have stable measured count changes.

## Accuracy acceptance (not yet passed)

Prepare an independent timestamped ground-truth log with true card counts. Test 0/1/2/5/20/25-card moves, split, merge, hand occlusion, camera/video jitter, and return-to-view. Report precision, recall, count MAE, 1-card sensitivity and transfer match rate. Do not label exact counting verified before those results exist.
