package com.mj.stacktracker.automatic;

import android.graphics.Bitmap;
import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Phase 10.2 tabletop-focused candidate detection and conservative card-layer measurement.
 * The analysis remains fully on-device; the user does not draw an ROI or enter mm.
 */
public final class CardStackVision {
    private static final int MAX_WIDTH = 1280;
    private final RelativeCountEstimator estimator = new RelativeCountEstimator(416);
    private int referenceStableFrames = 0;
    private CardMeasurement previousReference;

    public static final class FrameResult {
        public final List<PileObservation> piles;
        public final boolean referenceReady;
        public final String message;
        public final int candidateCount;
        public final int validCount;
        public final String quantityRejectionSummary;

        FrameResult(List<PileObservation> p, boolean ready, String m,
                    int candidates, int valid, String rejectionSummary) {
            piles = p;
            referenceReady = ready;
            message = m;
            candidateCount = candidates;
            validCount = valid;
            quantityRejectionSummary = rejectionSummary == null ? "" : rejectionSummary;
        }
    }

    public FrameResult analyze(Bitmap bitmap) { return analyze(bitmap, true); }

    public FrameResult analyze(Bitmap bitmap, boolean allowReferenceCalibration) {
        if (bitmap == null || bitmap.isRecycled()) {
            return new FrameResult(new ArrayList<>(), estimator.isReady(), "Invalid frame.", 0, 0, "");
        }

        Mat rgba = new Mat();
        Mat hsv = new Mat();
        Mat whiteMask = new Mat();
        Mat roiMask = new Mat();
        Mat hierarchy = new Mat();
        Mat gray = new Mat();
        List<MatOfPoint> contours = new ArrayList<>();
        try {
            Utils.bitmapToMat(bitmap, rgba);
            double scale = Math.min(1.0, MAX_WIDTH / (double) Math.max(1, rgba.cols()));
            if (scale < 0.999) {
                Mat resized = new Mat();
                Imgproc.resize(rgba, resized,
                        new Size(Math.max(1, Math.round(rgba.cols() * scale)),
                                Math.max(1, Math.round(rgba.rows() * scale))));
                rgba.release();
                rgba = resized;
            }

            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY);
            Imgproc.cvtColor(rgba, hsv, Imgproc.COLOR_RGBA2RGB);
            Imgproc.cvtColor(hsv, hsv, Imgproc.COLOR_RGB2HSV);

            // White/grey card surfaces stand out from the dark playing cloth.
            // Restrict pixels before contour extraction to avoid background scenery.
            Core.inRange(hsv, new Scalar(0, 0, 130), new Scalar(180, 95, 255), whiteMask);
            roiMask = Mat.zeros(gray.rows(), gray.cols(), CvType.CV_8UC1);
            int roiLeft = (int) Math.round(gray.cols() * 0.18);
            int roiRight = (int) Math.round(gray.cols() * 0.82);
            int roiTop = (int) Math.round(gray.rows() * 0.30);
            int roiBottom = (int) Math.round(gray.rows() * 0.86);
            Imgproc.rectangle(roiMask, new Point(roiLeft, roiTop),
                    new Point(roiRight, roiBottom), new Scalar(255), -1);
            Core.bitwise_and(whiteMask, roiMask, whiteMask);

            Mat kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(5, 3));
            Imgproc.morphologyEx(whiteMask, whiteMask, Imgproc.MORPH_CLOSE,
                    kernel, new Point(-1, -1), 2);
            kernel.release();

            Imgproc.findContours(whiteMask, contours, hierarchy,
                    Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE);

            List<RawCandidate> candidates = new ArrayList<>();
            double imageArea = (double) gray.cols() * gray.rows();
            for (MatOfPoint contour : contours) {
                double area = Imgproc.contourArea(contour);
                if (area <= 0) continue;
                Rect bounds = Imgproc.boundingRect(contour);
                double boxArea = Math.max(1.0, (double) bounds.width * bounds.height);
                double rectangularity = Math.min(1.0, area / boxArea);
                if (!TabletopCandidatePolicy.accepts(bounds.x, bounds.y,
                        bounds.width, bounds.height, area, gray.cols(), gray.rows(), rectangularity)) {
                    continue;
                }

                double cx = (bounds.x + bounds.width * 0.5) / gray.cols();
                double cy = (bounds.y + bounds.height * 0.5) / gray.rows();
                double roiDistance = Math.hypot(cx - 0.48, cy - 0.64);
                double positionScore = 1.0 - Math.min(1.0, roiDistance / 0.45);
                double sizeScore = Math.min(1.0, Math.sqrt(area / imageArea) / 0.10);
                double detectorScore = 0.55 * rectangularity + 0.25 * sizeScore + 0.20 * positionScore;

                RawCandidate candidate = measure(gray, bounds, rectangularity, detectorScore);
                if (candidate != null) candidates.add(candidate);
            }

            candidates.sort(Comparator.comparingDouble((RawCandidate c) -> c.score).reversed());
            candidates = suppress(candidates, 12);

            if (!estimator.isReady() && allowReferenceCalibration) {
                RawCandidate original = selectOriginal(candidates);
                if (original != null) {
                    if (previousReference != null && similar(previousReference, original.measurement)) {
                        referenceStableFrames++;
                    } else {
                        referenceStableFrames = 1;
                        estimator.resetReference();
                    }
                    previousReference = original.measurement;

                    // Use only the first stable views of the intact deck. This prevents
                    // a later split pile or a background object from redefining 416.
                    if (referenceStableFrames <= 9) estimator.addReference(original.measurement);
                } else {
                    referenceStableFrames = 0;
                    previousReference = null;
                }
                if (!estimator.isReady()) {
                    return new FrameResult(new ArrayList<>(), false,
                            "Tabletop candidates: " + candidates.size()
                                    + ". Locking the original 416-card deck from stable opening frames…",
                            candidates.size(), 0, "reference not ready");
                }
            }

            List<PileObservation> observations = new ArrayList<>();
            int validCount = 0;
            java.util.Map<String, Integer> rejected = new java.util.LinkedHashMap<>();
            for (RawCandidate candidate : candidates) {
                RelativeCountEstimator.Estimate estimate = estimator.estimate(candidate.measurement);
                if (!estimate.valid && !estimate.rejectionReason.isEmpty()) {
                    Integer old = rejected.get(estimate.rejectionReason);
                    rejected.put(estimate.rejectionReason, old == null ? 1 : old + 1);
                }
                CardMeasurement m = candidate.measurement;
                // Preserve a presence-only observation when geometry is plausible
                // but quantity confidence is insufficient. Phase 10.2 tracks this as
                // an Unknown-quantity pile region; it cannot change the inventory count.
                observations.add(new PileObservation(m.left, m.top, m.right, m.bottom,
                        estimate.valid ? estimate.count : 0,
                        estimate.valid ? estimate.confidence : m.confidence,
                        estimate.valid));
                if (estimate.valid) validCount++;
            }
            String rejectionSummary = summarizeRejections(rejected);
            String message;
            if (validCount == 0) {
                message = "Tabletop candidates: " + candidates.size()
                        + ". Quantity unresolved: " + (rejectionSummary.isEmpty()
                        ? "no reliable layer evidence" : rejectionSummary) + ".";
            } else {
                message = "Tabletop candidates: " + candidates.size()
                        + ". Quantity-valid pile observations: " + validCount + ".";
            }
            return new FrameResult(observations, true, message,
                    candidates.size(), validCount, rejectionSummary);
        } catch (Throwable error) {
            return new FrameResult(new ArrayList<>(), estimator.isReady(),
                    "Frame rejected: " + error.getClass().getSimpleName(), 0, 0,
                    "frame processing error");
        } finally {
            for (MatOfPoint contour : contours) contour.release();
            rgba.release(); hsv.release(); whiteMask.release(); roiMask.release();
            hierarchy.release(); gray.release();
        }
    }

    private RawCandidate measure(Mat gray, Rect bounds,
                                 double rectangularity, double detectorScore) {
        if (bounds.width < 8 || bounds.height < 8) return null;
        Mat roi = gray.submat(bounds);
        Mat dx = new Mat();
        Mat dy = new Mat();
        Mat absX = new Mat();
        Mat absY = new Mat();
        try {
            Imgproc.Sobel(roi, dx, CvType.CV_16S, 1, 0, 3);
            Imgproc.Sobel(roi, dy, CvType.CV_16S, 0, 1, 3);
            Core.convertScaleAbs(dx, absX);
            Core.convertScaleAbs(dy, absY);
            double[] projectionX = projection(absX, false);
            double[] projectionY = projection(absY, true);
            Signal sx = signal(projectionX);
            Signal sy = signal(projectionY);
            // Prefer the axis that actually contains multiple layer-edge peaks.
            // A single very strong boundary on the other axis must not win just
            // because its gradient energy is larger.
            boolean useY;
            if (sy.peakCount >= 2 && sx.peakCount < 2) useY = true;
            else if (sx.peakCount >= 2 && sy.peakCount < 2) useY = false;
            else useY = sy.score >= sx.score;
            double layerSpan = useY ? bounds.height : bounds.width;
            double faceSpan = useY ? bounds.width : bounds.height;
            Signal chosen = useY ? sy : sx;
            // Use the detected edge-to-edge span whenever at least two edges exist.
            // The count estimator still requires >=3 periodic edges before it can
            // validate a quantity; this value improves diagnostics without relaxing
            // that confidence rule.
            double measuredSpan = chosen.peakCount >= 2 && chosen.peakSpan > 1
                    ? chosen.peakSpan : layerSpan;
            double edgePeriodicity = Math.max(0, Math.min(1,
                    chosen.regularity * 0.65 + Math.min(1, chosen.peakCount / 12.0) * 0.35));
            double sharpness = Math.max(0, Math.min(1, chosen.energy / 42.0));
            double normalizedSpan = measuredSpan / Math.max(1, faceSpan);
            double quality = 0.38 * detectorScore + 0.25 * rectangularity
                    + 0.22 * edgePeriodicity + 0.15 * sharpness;

            float left = bounds.x / (float) gray.cols();
            float top = bounds.y / (float) gray.rows();
            float right = (bounds.x + bounds.width) / (float) gray.cols();
            float bottom = (bounds.y + bounds.height) / (float) gray.rows();
            CardMeasurement measurement = new CardMeasurement(left, top, right, bottom,
                    normalizedSpan, edgePeriodicity, sharpness, rectangularity,
                    quality, chosen.peakCount);
            return new RawCandidate(measurement, detectorScore);
        } finally {
            roi.release(); dx.release(); dy.release(); absX.release(); absY.release();
        }
    }

    private double[] projection(Mat gradient, boolean vertical) {
        int length = vertical ? gradient.rows() : gradient.cols();
        int orthogonal = vertical ? gradient.cols() : gradient.rows();
        double[] output = new double[length];
        int step = Math.max(1, orthogonal / 90);
        int start = (int) (orthogonal * 0.12);
        int end = (int) (orthogonal * 0.88);
        int samples = Math.max(1, (int) Math.ceil((orthogonal * 0.76) / Math.max(1, orthogonal / 90)));
        for (int i = 0; i < length; i++) {
            double sum = 0;
            for (int j = start; j < end; j += step) {
                double[] value = vertical ? gradient.get(i, j) : gradient.get(j, i);
                if (value != null && value.length > 0) sum += value[0];
            }
            output[i] = sum / samples;
        }
        return output;
    }

    private Signal signal(double[] profile) {
        if (profile.length < 8) return new Signal(0, 0, 0, 0, 0);
        double[] smooth = new double[profile.length];
        for (int i = 1; i < profile.length - 1; i++) {
            smooth[i] = (profile[i - 1] + 2 * profile[i] + profile[i + 1]) * 0.25;
        }
        double[] sorted = smooth.clone();
        java.util.Arrays.sort(sorted);
        double median = sorted[sorted.length / 2];
        double[] deviations = new double[sorted.length];
        for (int i = 0; i < deviations.length; i++) deviations[i] = Math.abs(smooth[i] - median);
        java.util.Arrays.sort(deviations);
        double mad = deviations[deviations.length / 2] + 1e-6;
        double threshold = median + Math.max(3.0, 2.4 * mad);
        int peaks = 0;
        int last = -3;
        double peakSum = 0;
        List<Double> positions = new ArrayList<>();
        for (int i = 2; i < smooth.length - 2; i++) {
            if (smooth[i] >= threshold && smooth[i] >= smooth[i - 1]
                    && smooth[i] > smooth[i + 1] && i - last >= 2) {
                peaks++;
                last = i;
                peakSum += smooth[i];
                double ym = smooth[i - 1], y0 = smooth[i], yp = smooth[i + 1];
                double denominator = ym - 2 * y0 + yp;
                double offset = Math.abs(denominator) < 1e-9 ? 0.0
                        : 0.5 * (ym - yp) / denominator;
                positions.add(i + Math.max(-0.5, Math.min(0.5, offset)));
            }
        }
        double regularity = 0;
        double peakSpan = positions.size() >= 2
                ? Math.max(1, positions.get(positions.size() - 1) - positions.get(0)) : 0;
        if (positions.size() >= 3) {
            List<Double> gaps = new ArrayList<>();
            for (int i = 1; i < positions.size(); i++) gaps.add(positions.get(i) - positions.get(i - 1));
            double mean = 0;
            for (double gap : gaps) mean += gap;
            mean /= gaps.size();
            double variance = 0;
            for (double gap : gaps) variance += (gap - mean) * (gap - mean);
            variance /= gaps.size();
            regularity = mean <= 0 ? 0 : Math.max(0, 1 - Math.sqrt(variance) / mean);
        }
        double energy = peakSum / Math.max(1, peaks);
        double score = Math.min(1, peaks / 8.0) * 0.45 + regularity * 0.35
                + Math.min(1, energy / 55.0) * 0.20;
        return new Signal(peaks, regularity, energy, score, peakSpan);
    }

    private String summarizeRejections(java.util.Map<String, Integer> rejected) {
        if (rejected == null || rejected.isEmpty()) return "";
        String bestReason = "";
        int bestCount = 0;
        for (java.util.Map.Entry<String, Integer> entry : rejected.entrySet()) {
            if (entry.getValue() > bestCount) {
                bestCount = entry.getValue();
                bestReason = entry.getKey();
            }
        }
        return bestReason + " (" + bestCount + ")";
    }

    private RawCandidate selectOriginal(List<RawCandidate> candidates) {
        RawCandidate best = null;
        double bestScore = -1;
        for (RawCandidate candidate : candidates) {
            CardMeasurement m = candidate.measurement;
            double score = candidate.score * 0.72 + m.confidence * 0.28;
            if (score > bestScore) { bestScore = score; best = candidate; }
        }
        return best;
    }

    private boolean similar(CardMeasurement a, CardMeasurement b) {
        double centerDistance = Math.hypot(a.centerX() - b.centerX(), a.centerY() - b.centerY());
        double widthDifference = Math.abs(a.width() - b.width());
        double heightDifference = Math.abs(a.height() - b.height());
        return centerDistance < 0.04
                && widthDifference < Math.max(0.025, Math.max(a.width(), b.width()) * 0.25)
                && heightDifference < Math.max(0.025, Math.max(a.height(), b.height()) * 0.25);
    }

    private List<RawCandidate> suppress(List<RawCandidate> input, int max) {
        List<RawCandidate> output = new ArrayList<>();
        for (RawCandidate candidate : input) {
            boolean duplicate = false;
            for (RawCandidate previous : output) {
                if (iou(candidate.measurement, previous.measurement) > 0.55) {
                    duplicate = true;
                    break;
                }
            }
            if (!duplicate) output.add(candidate);
            if (output.size() >= max) break;
        }
        return output;
    }

    private double iou(CardMeasurement a, CardMeasurement b) {
        double left = Math.max(a.left, b.left);
        double top = Math.max(a.top, b.top);
        double right = Math.min(a.right, b.right);
        double bottom = Math.min(a.bottom, b.bottom);
        double intersection = Math.max(0, right - left) * Math.max(0, bottom - top);
        double union = a.area() + b.area() - intersection;
        return union <= 0 ? 0 : intersection / union;
    }

    private static final class Signal {
        final int peakCount;
        final double regularity, energy, score, peakSpan;
        Signal(int peaks, double regularity, double energy, double score, double peakSpan) {
            this.peakCount = peaks;
            this.regularity = regularity;
            this.energy = energy;
            this.score = score;
            this.peakSpan = peakSpan;
        }
    }

    private static final class RawCandidate {
        final CardMeasurement measurement;
        final double score;
        RawCandidate(CardMeasurement measurement, double score) {
            this.measurement = measurement;
            this.score = score;
        }
    }
}
