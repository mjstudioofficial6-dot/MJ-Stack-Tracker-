package com.mj.stacktracker.automatic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Immutable UI snapshot of tracked piles and confidently matched transfers. */
public final class AnalysisSnapshot {
    public static final class Pile {
        public final String id;
        /** Zero when quantityKnown is false. Never present zero as a measured count. */
        public final int count;
        public final double confidence;
        public final boolean visible;
        public final boolean quantityKnown;
        public final boolean verified;
        public final float centerX;
        public final float centerY;

        Pile(String id, int count, double confidence, boolean visible,
             boolean quantityKnown, boolean verified, float x, float y) {
            this.id = id;
            this.count = count;
            this.confidence = confidence;
            this.visible = visible;
            this.quantityKnown = quantityKnown;
            this.verified = verified;
            this.centerX = x;
            this.centerY = y;
        }
    }

    public final List<Pile> piles;
    public final List<TransferEvent> transfers;
    public final int initialCount;
    /** Cards with a committed count in a currently visible pile. */
    public final int accountedCount;
    public final int unassignedCount;
    public final int visiblePileCount;
    public final int visibleUnknownPileCount;
    public final boolean balanced;
    public final long timestampMs;

    AnalysisSnapshot(List<Pile> piles, List<TransferEvent> transfers,
                     int initialCount, int accountedCount, int unassignedCount,
                     int visiblePileCount, int visibleUnknownPileCount,
                     boolean balanced, long timestampMs) {
        this.piles = Collections.unmodifiableList(new ArrayList<>(piles));
        this.transfers = Collections.unmodifiableList(new ArrayList<>(transfers));
        this.initialCount = initialCount;
        this.accountedCount = accountedCount;
        this.unassignedCount = unassignedCount;
        this.visiblePileCount = visiblePileCount;
        this.visibleUnknownPileCount = visibleUnknownPileCount;
        this.balanced = balanced;
        this.timestampMs = timestampMs;
    }
}
