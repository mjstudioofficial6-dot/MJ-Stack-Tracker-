package com.mj.stacktracker.automatic;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.List;

/**
 * Conservative relative estimator referenced to the known original 416-card stack.
 * Measurements with too little visible layer structure stay unresolved.
 */
public final class RelativeCountEstimator {
    public static final class Estimate {
        public final int count;
        public final double confidence;
        public final double normalizedRatio;
        public final boolean valid;
        public final String rejectionReason;

        Estimate(int count, double confidence, double ratio, boolean valid, String reason) {
            this.count = count;
            this.confidence = confidence;
            this.normalizedRatio = ratio;
            this.valid = valid;
            this.rejectionReason = reason == null ? "" : reason;
        }
    }

    private final int initialCount;
    private final Deque<Double> referenceSamples = new ArrayDeque<>();
    private double referenceRatio = Double.NaN;

    public RelativeCountEstimator(int initialCount) {
        if (initialCount < 1) throw new IllegalArgumentException("Initial count must be positive");
        this.initialCount = initialCount;
    }

    /** Build the 416-card reference from several stable, layer-readable opening views. */
    public synchronized boolean addReference(CardMeasurement measurement) {
        if (measurementFailure(measurement) != null) return false;
        referenceSamples.addLast(measurement.normalizedLayerSpan);
        while (referenceSamples.size() > 9) referenceSamples.removeFirst();
        if (referenceSamples.size() < 3) return false;
        referenceRatio = median(new ArrayList<>(referenceSamples));
        return Double.isFinite(referenceRatio) && referenceRatio > 1e-5;
    }

    public synchronized void resetReference() {
        referenceSamples.clear();
        referenceRatio = Double.NaN;
    }

    public synchronized boolean isReady() {
        return Double.isFinite(referenceRatio) && referenceRatio > 1e-5;
    }

    public synchronized double getReferenceRatio() { return referenceRatio; }

    public synchronized Estimate estimate(CardMeasurement measurement) {
        if (!isReady()) return invalid(Double.NaN, "416-card reference is not ready");
        String failure = measurementFailure(measurement);
        if (failure != null) return invalid(Double.NaN, failure);

        double ratio = measurement.normalizedLayerSpan / referenceRatio;
        if (!Double.isFinite(ratio) || ratio < 0.0005 || ratio > 1.15) {
            return invalid(ratio, "relative layer span is outside the calibrated range");
        }
        double raw = initialCount * ratio;
        if (!Double.isFinite(raw) || raw < 0.5 || raw > initialCount * 1.08) {
            return invalid(ratio, "derived quantity is outside the 416-card inventory range");
        }

        int count = (int) Math.round(raw);
        double referenceAgreement = 1.0 - Math.min(1.0, Math.abs(raw - count) / 0.5);
        double confidence = 0.32 * measurement.confidence
                + 0.24 * measurement.edgePeriodicity
                + 0.18 * measurement.sharpness
                + 0.16 * measurement.rectangularity
                + 0.10 * referenceAgreement;
        boolean valid = count >= 1 && count <= initialCount && confidence >= 0.64;
        if (!valid) return new Estimate(count, clamp(confidence), ratio, false,
                "measurement confidence is below the safe counting threshold");
        return new Estimate(count, clamp(confidence), ratio, true, "");
    }

    private String measurementFailure(CardMeasurement measurement) {
        if (measurement == null) return "measurement is missing";
        if (!Double.isFinite(measurement.normalizedLayerSpan)
                || measurement.normalizedLayerSpan <= 0) return "layer span is not measurable";
        if (measurement.confidence < 0.40) return "candidate visual confidence is too low";
        if (measurement.rectangularity < 0.22) return "candidate shape is not sufficiently stack-like";
        if (measurement.sharpness < 0.12) return "candidate edges are too blurred";
        // Two peaks are only two edges. They cannot demonstrate a repeated layer
        // spacing pattern, so they remain presence-only rather than being converted
        // into a quantity by relaxing the old 0.08 periodicity cutoff.
        if (measurement.visibleEdgePeaks < 3) {
            return "fewer than three visible layer edges; quantity remains unknown";
        }
        if (measurement.edgePeriodicity < 0.08) {
            return "layer-edge spacing is not sufficiently periodic";
        }
        return null;
    }

    private Estimate invalid(double ratio, String reason) {
        return new Estimate(0, 0, ratio, false, reason);
    }

    private static double median(List<Double> values) {
        if (values.isEmpty()) return Double.NaN;
        Collections.sort(values);
        int n = values.size();
        return n % 2 == 1 ? values.get(n / 2)
                : (values.get(n / 2 - 1) + values.get(n / 2)) * 0.5;
    }

    private static double clamp(double value) { return Math.max(0, Math.min(1, value)); }
}
