package com.mj.stacktracker.automatic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Temporal pile tracker with separate presence and quantity states.
 *
 * A pile may be tracked as a visible region while its card quantity remains unknown.
 * Only repeated, quantity-valid observations may change the inventory ledger or
 * generate a transfer. Unknown observations are never converted into guessed counts.
 */
public final class AutomaticTransferEngine {
    private static final int STABLE_COUNT_SAMPLES = 3;
    private static final int STABLE_PRESENCE_SAMPLES = 2;
    private static final int ACCOUNTING_VISIBLE_MISSES = 2;
    private static final int MAX_MATCH_GAP_SAMPLES = 8;
    private static final long TRANSFER_WINDOW_MS = 1800;

    private static final class Track {
        final String id;
        float l, t, r, b, cx, cy;
        final float anchorCx, anchorCy;
        final double anchorArea;
        int visibleMisses;
        int seen;
        int presenceRepeats;
        int committedCount;
        int candidateCount;
        int candidateRepeats;
        double confidence;
        boolean countKnown;
        long lastSeen;

        Track(String id, PileObservation observation, long timestampMs) {
            this.id = id;
            updateBox(observation);
            anchorCx = observation.cx();
            anchorCy = observation.cy();
            anchorArea = observation.area();
            lastSeen = timestampMs;
            seen = 1;
            presenceRepeats = 1;
            confidence = observation.confidence;
        }

        void updateBox(PileObservation observation) {
            l = observation.left;
            t = observation.top;
            r = observation.right;
            b = observation.bottom;
            cx = observation.cx();
            cy = observation.cy();
        }
    }

    private static final class Delta {
        final String pileId;
        final int amount;
        final long timestampMs;
        final double confidence;

        Delta(String pileId, int amount, long timestampMs, double confidence) {
            this.pileId = pileId;
            this.amount = amount;
            this.timestampMs = timestampMs;
            this.confidence = confidence;
        }
    }

    private final int initialCount;
    private final List<Track> tracks = new ArrayList<>();
    private final List<TransferEvent> transfers = new ArrayList<>();
    private final List<Delta> pendingDeltas = new ArrayList<>();
    private int nextPile = 2;

    public AutomaticTransferEngine(int initialCount) {
        if (initialCount < 1) throw new IllegalArgumentException("initialCount");
        this.initialCount = initialCount;
    }

    public synchronized AnalysisSnapshot update(long timestampMs,
                                                List<PileObservation> observations) {
        if (observations == null) observations = Collections.emptyList();

        for (Track track : tracks) track.visibleMisses++;

        List<PileObservation> validObservations = new ArrayList<>();
        for (PileObservation observation : observations) {
            if (observation == null || !Double.isFinite(observation.confidence)) continue;
            if (observation.confidence < 0.42 || observation.area() <= 0.00008) continue;
            validObservations.add(observation);
        }

        // Establish the known 416-card starting pile from the first stable-reference
        // frame. The inventory seed is known by project setup; later child quantities
        // still require valid image measurements.
        if (tracks.isEmpty() && !validObservations.isEmpty()) {
            PileObservation root = chooseOpeningObservation(validObservations);
            Track master = new Track("PILE-01", root, timestampMs);
            master.committedCount = initialCount;
            master.candidateCount = initialCount;
            master.candidateRepeats = STABLE_COUNT_SAMPLES;
            master.presenceRepeats = STABLE_PRESENCE_SAMPLES;
            master.countKnown = true;
            tracks.add(master);
        }

        List<Match> matches = new ArrayList<>();
        boolean openingPileMatched = false;
        for (Track track : tracks) {
            if (track.visibleMisses > MAX_MATCH_GAP_SAMPLES) continue;
            for (int observationIndex = 0;
                 observationIndex < validObservations.size(); observationIndex++) {
                PileObservation observation = validObservations.get(observationIndex);
                double distance = Math.hypot(track.cx - observation.cx(), track.cy - observation.cy());
                double overlap = intersectionOverUnion(track, observation);
                double sizeRatio = observation.area() / Math.max(trackArea(track), 1e-8);

                // A presence-only child must not inherit PILE-01's 416-card quantity
                // simply because it is close to the old deck location.
                if ("PILE-01".equals(track.id) && !observation.countValid) {
                    // Compare to the immutable opening-deck anchor, not the last matched
                    // box. Comparing to the last box let PILE-01 drift onto a succession
                    // of smaller child piles after a split and keep all 416 cards assigned.
                    double anchorSizeRatio = observation.area() / Math.max(track.anchorArea, 1e-8);
                    double anchorDistance = Math.hypot(
                            track.anchorCx - observation.cx(), track.anchorCy - observation.cy());
                    if (anchorSizeRatio < 0.65 || anchorSizeRatio > 1.55
                            || anchorDistance > 0.16) continue;
                }

                double sizePenalty = Math.abs(Math.log(Math.max(1e-6, sizeRatio)));
                double countPenalty = (track.countKnown && observation.countValid)
                        ? Math.min(1.0, Math.abs(track.committedCount - observation.estimatedCount)
                        / (double) initialCount) : 0.35;
                double cost = 0.38 * (1.0 - overlap)
                        + 0.24 * Math.min(1.0, distance / 0.28)
                        + 0.25 * countPenalty
                        + 0.13 * Math.min(1.0, sizePenalty / 1.4);

                if ((overlap >= 0.025 || distance <= 0.24)
                        && sizeRatio >= 0.18 && sizeRatio <= 5.5 && cost < 0.90) {
                    matches.add(new Match(track, observationIndex, cost));
                }
            }
        }

        matches.sort(Comparator.comparingDouble(match -> match.cost));
        boolean[] usedTracks = new boolean[tracks.size()];
        boolean[] usedObservations = new boolean[validObservations.size()];
        List<Delta> frameDeltas = new ArrayList<>();

        for (Match match : matches) {
            int trackIndex = tracks.indexOf(match.track);
            if (trackIndex < 0 || usedTracks[trackIndex]
                    || usedObservations[match.observationIndex]) continue;
            usedTracks[trackIndex] = true;
            usedObservations[match.observationIndex] = true;
            if ("PILE-01".equals(match.track.id)) openingPileMatched = true;
            updateTrack(match.track, validObservations.get(match.observationIndex),
                    timestampMs, frameDeltas);
        }

        // If the root deck is no longer matched while multiple tabletop regions
        // appear, treat this as a split transition rather than keeping all 416 cards
        // accounted in a stale, invisible parent. The cards move to Unassigned until
        // the child quantities pass the counting gate.
        if (!openingPileMatched && validObservations.size() >= 2) {
            for (Track track : tracks) {
                if ("PILE-01".equals(track.id)) {
                    track.visibleMisses = ACCOUNTING_VISIBLE_MISSES + 1;
                    break;
                }
            }
        }

        // IMPORTANT Phase 10.2 correction:
        // create a presence-only identity for a new region even when quantity is
        // unresolved. Phase 10.1 discarded these observations, so visible child piles
        // never appeared in the pile list. Their count remains unknown until measured.
        for (int i = 0; i < validObservations.size(); i++) {
            if (usedObservations[i]) continue;
            PileObservation observation = validObservations.get(i);
            Track track = new Track(String.format(Locale.US, "PILE-%02d", nextPile++),
                    observation, timestampMs);
            if (observation.countValid) {
                track.candidateCount = observation.estimatedCount;
                track.candidateRepeats = 1;
            }
            tracks.add(track);
        }

        for (Track track : tracks) {
            if (track.visibleMisses == 0) track.lastSeen = timestampMs;
        }

        // Discard only long-missing tracks which never had a committed quantity.
        // Quantity-known historical tracks remain available for inventory reconciliation.
        tracks.removeIf(track -> !track.countKnown
                && track.visibleMisses > MAX_MATCH_GAP_SAMPLES);

        pairTransfers(frameDeltas);
        return createSnapshot(timestampMs);
    }

    private PileObservation chooseOpeningObservation(List<PileObservation> observations) {
        PileObservation best = observations.get(0);
        double bestScore = Double.NEGATIVE_INFINITY;
        for (PileObservation observation : observations) {
            double sizeScore = Math.min(1.0, Math.sqrt(observation.area()) / 0.6);
            double initialCountFit = observation.countValid
                    ? 1.0 - Math.min(1.0,
                    Math.abs(observation.estimatedCount - initialCount) / (double) initialCount)
                    : 0.0;
            double score = 0.60 * (observation.countValid ? initialCountFit : sizeScore)
                    + 0.40 * observation.confidence;
            if (score > bestScore) {
                bestScore = score;
                best = observation;
            }
        }
        return best;
    }

    private void updateTrack(Track track, PileObservation observation,
                             long timestampMs, List<Delta> deltas) {
        track.visibleMisses = 0;
        track.seen++;
        track.presenceRepeats++;
        track.lastSeen = timestampMs;
        track.updateBox(observation);
        track.confidence = observation.confidence;

        if (!observation.countValid) return;

        if (observation.estimatedCount == track.candidateCount) {
            track.candidateRepeats++;
        } else {
            track.candidateCount = observation.estimatedCount;
            track.candidateRepeats = 1;
        }

        if (track.candidateRepeats < STABLE_COUNT_SAMPLES) return;

        if (!track.countKnown) {
            track.committedCount = track.candidateCount;
            track.countKnown = true;
            if (track.committedCount > 0) {
                deltas.add(new Delta(track.id, track.committedCount,
                        timestampMs, track.confidence));
            }
        } else if (track.candidateCount != track.committedCount) {
            int delta = track.candidateCount - track.committedCount;
            track.committedCount = track.candidateCount;
            if (delta != 0) {
                deltas.add(new Delta(track.id, delta, timestampMs, track.confidence));
            }
        }
    }

    private void pairTransfers(List<Delta> deltas) {
        List<Delta> decreases = new ArrayList<>();
        List<Delta> increases = new ArrayList<>();
        for (Delta delta : deltas) {
            if (delta.amount < 0) decreases.add(delta);
            else if (delta.amount > 0) increases.add(delta);
        }

        for (Delta decrease : decreases) {
            int quantity = -decrease.amount;
            Delta best = null;
            for (Delta increase : increases) {
                if (increase.pileId.equals(decrease.pileId)
                        || Math.abs(increase.timestampMs - decrease.timestampMs) > TRANSFER_WINDOW_MS) {
                    continue;
                }
                if (increase.amount == quantity) {
                    best = increase;
                    break;
                }
            }
            if (best != null) {
                transfers.add(new TransferEvent(
                        Math.max(decrease.timestampMs, best.timestampMs),
                        decrease.pileId, best.pileId, quantity,
                        Math.min(decrease.confidence, best.confidence)));
                increases.remove(best);
            } else {
                pendingDeltas.add(decrease);
            }
        }

        // A destination may become count-valid one or two sampled frames later.
        for (Delta increase : increases) {
            Delta best = null;
            for (Delta decrease : pendingDeltas) {
                if (increase.pileId.equals(decrease.pileId)
                        || Math.abs(increase.timestampMs - decrease.timestampMs) > TRANSFER_WINDOW_MS) {
                    continue;
                }
                if (increase.amount == -decrease.amount) {
                    best = decrease;
                    break;
                }
            }
            if (best != null) {
                transfers.add(new TransferEvent(
                        Math.max(increase.timestampMs, best.timestampMs),
                        best.pileId, increase.pileId, increase.amount,
                        Math.min(increase.confidence, best.confidence)));
                pendingDeltas.remove(best);
            }
        }

        long newestTimestamp = 0;
        for (Delta delta : deltas) newestTimestamp = Math.max(newestTimestamp, delta.timestampMs);
        if (newestTimestamp > 0) {
            final long newest = newestTimestamp;
            pendingDeltas.removeIf(delta -> newest - delta.timestampMs > TRANSFER_WINDOW_MS * 3);
        }
    }

    private AnalysisSnapshot createSnapshot(long timestampMs) {
        List<AnalysisSnapshot.Pile> rows = new ArrayList<>();
        int accounted = 0;
        int visiblePileCount = 0;
        int visibleUnknownPileCount = 0;

        for (Track track : tracks) {
            boolean visible = track.visibleMisses <= ACCOUNTING_VISIBLE_MISSES;
            boolean stablePresence = track.presenceRepeats >= STABLE_PRESENCE_SAMPLES;
            if (!track.countKnown && !stablePresence) continue;

            if (visible) {
                visiblePileCount++;
                if (!track.countKnown) visibleUnknownPileCount++;
                else accounted += track.committedCount;
            }

            rows.add(new AnalysisSnapshot.Pile(
                    track.id,
                    track.countKnown ? track.committedCount : 0,
                    track.confidence,
                    visible,
                    track.countKnown,
                    track.countKnown && track.candidateRepeats >= STABLE_COUNT_SAMPLES,
                    track.cx,
                    track.cy));
        }

        rows.sort(Comparator.comparing(pile -> pile.id));
        int unassigned = Math.max(0, initialCount - accounted);
        return new AnalysisSnapshot(rows, transfers, initialCount, accounted,
                unassigned, visiblePileCount, visibleUnknownPileCount,
                accounted == initialCount, timestampMs);
    }

    private static double trackArea(Track track) {
        return Math.max(0, track.r - track.l) * Math.max(0, track.b - track.t);
    }

    private static double intersectionOverUnion(Track track, PileObservation observation) {
        double left = Math.max(track.l, observation.left);
        double top = Math.max(track.t, observation.top);
        double right = Math.min(track.r, observation.right);
        double bottom = Math.min(track.b, observation.bottom);
        double intersection = Math.max(0, right - left) * Math.max(0, bottom - top);
        double union = trackArea(track) + observation.area() - intersection;
        return union <= 0 ? 0 : intersection / union;
    }

    private static final class Match {
        final Track track;
        final int observationIndex;
        final double cost;

        Match(Track track, int observationIndex, double cost) {
            this.track = track;
            this.observationIndex = observationIndex;
            this.cost = cost;
        }
    }
}
