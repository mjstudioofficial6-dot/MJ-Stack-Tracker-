package com.mj.stacktracker.automatic;

import org.junit.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static org.junit.Assert.*;

public class AutomaticTransferEngineTest {
    private PileObservation measured(float left, float top, float right, float bottom, int count) {
        return new PileObservation(left, top, right, bottom, count, 0.95, true);
    }

    private PileObservation presence(float left, float top, float right, float bottom) {
        return new PileObservation(left, top, right, bottom, 0, 0.80, false);
    }

    @Test public void knownStartingDeckCanBeTrackedFromPresenceOnlyEvidence() {
        AutomaticTransferEngine engine = new AutomaticTransferEngine(416);
        AnalysisSnapshot snapshot = engine.update(0,
                Arrays.asList(presence(0.40f, 0.35f, 0.60f, 0.65f)));
        assertEquals(416, snapshot.accountedCount);
        assertEquals(0, snapshot.unassignedCount);
        assertEquals(1, snapshot.piles.size());
        assertEquals("PILE-01", snapshot.piles.get(0).id);
        assertEquals(416, snapshot.piles.get(0).count);
        assertTrue(snapshot.piles.get(0).quantityKnown);
        assertTrue(snapshot.piles.get(0).visible);
    }

    @Test public void presenceOnlyChildGetsIdentityButNoInventedQuantity() {
        AutomaticTransferEngine engine = new AutomaticTransferEngine(416);
        PileObservation root = measured(0.35f, 0.35f, 0.65f, 0.65f, 416);
        PileObservation child = presence(0.70f, 0.35f, 0.82f, 0.65f);
        engine.update(0, Arrays.asList(root));
        engine.update(180, Arrays.asList(root, child));
        AnalysisSnapshot snapshot = engine.update(360, Arrays.asList(root, child));

        assertEquals(416, snapshot.accountedCount);
        assertEquals(1, snapshot.visibleUnknownPileCount);
        assertEquals(2, snapshot.visiblePileCount);
        AnalysisSnapshot.Pile childRow = find(snapshot, "PILE-02");
        assertNotNull(childRow);
        assertFalse(childRow.quantityKnown);
        assertEquals(0, childRow.count);
        assertTrue(childRow.visible);
        assertTrue(snapshot.transfers.isEmpty());
    }

    @Test public void smallerNearbyPresenceOnlyChildCannotInherit416Root() {
        AutomaticTransferEngine engine = new AutomaticTransferEngine(416);
        PileObservation opening = presence(0.40f, 0.40f, 0.60f, 0.60f);
        PileObservation smallerChild = presence(0.43f, 0.44f, 0.57f, 0.56f);
        engine.update(0, Arrays.asList(opening));
        engine.update(180, Arrays.asList(smallerChild));
        engine.update(360, Arrays.asList(smallerChild));
        AnalysisSnapshot snapshot = engine.update(540, Arrays.asList(smallerChild));

        assertEquals(0, snapshot.accountedCount);
        assertEquals(416, snapshot.unassignedCount);
        assertEquals(2, snapshot.piles.size());
        AnalysisSnapshot.Pile root = find(snapshot, "PILE-01");
        AnalysisSnapshot.Pile child = find(snapshot, "PILE-02");
        assertNotNull(root);
        assertNotNull(child);
        assertFalse(root.visible);
        assertEquals(416, root.count);
        assertTrue(child.visible);
        assertFalse(child.quantityKnown);
        assertEquals(0, child.count);
    }

    @Test public void fourPresenceOnlyPilesBecomeFourUnknownTracks() {
        AutomaticTransferEngine engine = new AutomaticTransferEngine(416);
        PileObservation opening = presence(0.42f, 0.35f, 0.58f, 0.65f);
        engine.update(0, Arrays.asList(opening));
        List<PileObservation> four = Arrays.asList(
                presence(0.34f, 0.61f, 0.40f, 0.67f),
                presence(0.44f, 0.64f, 0.49f, 0.69f),
                presence(0.53f, 0.63f, 0.59f, 0.69f),
                presence(0.62f, 0.61f, 0.68f, 0.67f));
        engine.update(180, four);
        AnalysisSnapshot snapshot = engine.update(360, four);

        assertEquals(4, snapshot.visibleUnknownPileCount);
        assertEquals(4, snapshot.visiblePileCount);
        assertEquals(416, snapshot.unassignedCount);
        assertEquals(0, snapshot.accountedCount);
        assertEquals(4, countVisibleUnknown(snapshot));
        assertTrue(snapshot.transfers.isEmpty());
    }

    @Test public void unknownPileRemainsTrackedAcrossShortOcclusion() {
        AutomaticTransferEngine engine = new AutomaticTransferEngine(416);
        PileObservation opening = presence(0.42f, 0.35f, 0.58f, 0.65f);
        PileObservation child = presence(0.66f, 0.60f, 0.74f, 0.68f);
        engine.update(0, Arrays.asList(opening));
        engine.update(180, Arrays.asList(opening, child));
        engine.update(360, Arrays.asList(opening, child));
        AnalysisSnapshot occluded = engine.update(540, Arrays.asList(opening));
        assertNotNull(find(occluded, "PILE-02"));
        assertTrue(find(occluded, "PILE-02").visible); // one-frame grace
        engine.update(720, Arrays.asList(opening));
        AnalysisSnapshot fullyOccluded = engine.update(900, Arrays.asList(opening));
        assertFalse(find(fullyOccluded, "PILE-02").visible);

        AnalysisSnapshot returned = engine.update(1080, Arrays.asList(opening, child));
        assertNotNull(find(returned, "PILE-02"));
        assertTrue(find(returned, "PILE-02").visible);
        assertFalse(find(returned, "PILE-02").quantityKnown);
    }

    @Test public void splitCountsRemainConservedWhenBothMeasurementsAreValid() {
        AutomaticTransferEngine engine = new AutomaticTransferEngine(416);
        AnalysisSnapshot snapshot = null;
        for (int i = 0; i < 4; i++) {
            snapshot = engine.update(i * 180L,
                    Arrays.asList(measured(0.35f, 0.35f, 0.65f, 0.65f, 416)));
        }
        assertEquals(416, snapshot.accountedCount);
        for (int i = 4; i < 12; i++) {
            snapshot = engine.update(i * 180L, Arrays.asList(
                    measured(0.15f, 0.35f, 0.37f, 0.65f, 336),
                    measured(0.55f, 0.35f, 0.75f, 0.65f, 80)));
        }
        assertEquals(416, snapshot.accountedCount);
        assertEquals(0, snapshot.unassignedCount);
        assertTrue(snapshot.piles.size() >= 2);
    }

    @Test public void transferPairIsRecognizedOnlyFromMatchedQuantityDeltas() {
        AutomaticTransferEngine engine = new AutomaticTransferEngine(416);
        AnalysisSnapshot snapshot = null;
        for (int i = 0; i < 4; i++) {
            snapshot = engine.update(i * 180L,
                    Arrays.asList(measured(0.35f, 0.35f, 0.65f, 0.65f, 416)));
        }
        for (int i = 4; i < 12; i++) {
            snapshot = engine.update(i * 180L, Arrays.asList(
                    measured(0.15f, 0.35f, 0.37f, 0.65f, 360),
                    measured(0.55f, 0.35f, 0.75f, 0.65f, 56)));
        }
        assertEquals(416, snapshot.accountedCount);
        assertFalse(snapshot.transfers.isEmpty());
        TransferEvent event = snapshot.transfers.get(0);
        assertEquals(56, event.quantity);
        assertEquals("PILE-01", event.sourcePileId);
        assertEquals("PILE-02", event.destinationPileId);
    }

    @Test public void presenceOnlyChangesNeverCreateTransferOrCountDelta() {
        AutomaticTransferEngine engine = new AutomaticTransferEngine(416);
        PileObservation opening = presence(0.40f, 0.35f, 0.60f, 0.65f);
        engine.update(0, Arrays.asList(opening));
        List<PileObservation> childPiles = Arrays.asList(
                presence(0.32f, 0.61f, 0.39f, 0.68f),
                presence(0.43f, 0.61f, 0.50f, 0.68f),
                presence(0.54f, 0.61f, 0.61f, 0.68f),
                presence(0.65f, 0.61f, 0.72f, 0.68f));
        engine.update(180, childPiles);
        AnalysisSnapshot snapshot = engine.update(360, childPiles);
        assertTrue(snapshot.transfers.isEmpty());
        assertEquals(416, snapshot.initialCount);
        assertEquals(416, snapshot.unassignedCount);
        assertEquals(4, snapshot.visibleUnknownPileCount);
    }


    @Test public void actualVideoFinalPileBoxesRemainFourSeparateUnknownTracks() {
        AutomaticTransferEngine engine = new AutomaticTransferEngine(416);
        // Opening stack box measured from the 0.36 s frame (1280 x 720 analysis size).
        PileObservation opening = presence(604f / 1280f, 377f / 720f,
                672f / 1280f, 461f / 720f);
        engine.update(360, Arrays.asList(opening));

        // Candidate bounding boxes taken from the user's 14–21.5 s video frames.
        engine.update(14000, Arrays.asList(presence(551f/1280f,443f/720f,631f/1280f,494f/720f)));
        engine.update(16000, Arrays.asList(
                presence(552f/1280f,443f/720f,630f/1280f,490f/720f),
                presence(441f/1280f,443f/720f,518f/1280f,479f/720f)));
        engine.update(18000, Arrays.asList(
                presence(667f/1280f,459f/720f,735f/1280f,496f/720f),
                presence(441f/1280f,444f/720f,518f/1280f,479f/720f)));
        engine.update(20000, Arrays.asList(
                presence(667f/1280f,459f/720f,735f/1280f,495f/720f),
                presence(441f/1280f,444f/720f,518f/1280f,479f/720f),
                presence(565f/1280f,463f/720f,629f/1280f,493f/720f)));
        List<PileObservation> fourFinalPiles = Arrays.asList(
                presence(744f/1280f,443f/720f,816f/1280f,485f/720f),
                presence(667f/1280f,459f/720f,735f/1280f,496f/720f),
                presence(441f/1280f,443f/720f,518f/1280f,479f/720f),
                presence(565f/1280f,463f/720f,629f/1280f,494f/720f));
        engine.update(21320, fourFinalPiles);
        AnalysisSnapshot finalFrame = engine.update(21500, fourFinalPiles);

        assertEquals(4, finalFrame.visiblePileCount);
        assertEquals(4, finalFrame.visibleUnknownPileCount);
        assertEquals(416, finalFrame.unassignedCount);
        assertEquals(0, finalFrame.accountedCount);
        assertTrue(finalFrame.transfers.isEmpty());
    }

    @Test public void validMeasuredOneTwentyAndTwentyFiveCardTransfersAreRepresented() {
        int[] deltas = new int[] {1, 20, 25};
        for (int delta : deltas) {
            AutomaticTransferEngine engine = new AutomaticTransferEngine(416);
            engine.update(0, Arrays.asList(measured(0.35f, 0.35f, 0.65f, 0.65f, 416)));
            AnalysisSnapshot snapshot = null;
            for (int i = 1; i <= 6; i++) {
                snapshot = engine.update(i * 180L, Arrays.asList(
                        measured(0.15f, 0.35f, 0.37f, 0.65f, 416 - delta),
                        measured(0.55f, 0.35f, 0.75f, 0.65f, delta)));
            }
            assertEquals("inventory conservation for delta " + delta, 416, snapshot.accountedCount);
            boolean found = false;
            for (TransferEvent event : snapshot.transfers) {
                if (event.quantity == delta) found = true;
            }
            assertTrue("expected transfer of " + delta + " cards", found);
        }
    }

    private AnalysisSnapshot.Pile find(AnalysisSnapshot snapshot, String id) {
        for (AnalysisSnapshot.Pile pile : snapshot.piles) if (pile.id.equals(id)) return pile;
        return null;
    }

    private int countVisibleUnknown(AnalysisSnapshot snapshot) {
        int count = 0;
        for (AnalysisSnapshot.Pile pile : snapshot.piles) {
            if (pile.visible && !pile.quantityKnown) count++;
        }
        return count;
    }
}
