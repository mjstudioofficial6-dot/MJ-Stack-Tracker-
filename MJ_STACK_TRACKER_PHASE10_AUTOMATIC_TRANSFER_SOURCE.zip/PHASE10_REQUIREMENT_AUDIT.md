# Phase 10 Source Audit

## User requirement translated into product behavior
- User selects and plays one recorded video.
- The initial known inventory is 416 same-type cards.
- App automatically identifies the opening stack and any visible descendant piles.
- App estimates how many cards remain in each visible pile and pairs decreases at source piles with increases at destination piles.
- App reports unassigned cards when cards are hidden, in transit, or not reliably measurable.
- No user-facing mm calibration, object drawing, fixed 0.33mm/card calculation, or manual 1/2/3 teaching.

## Implemented components
- Local frame extraction from MediaMetadataRetriever.
- OpenCV whole-frame candidate detection and edge-profile measurements.
- Relative reference count calculation based on the known 416-card opening stack.
- Temporal pile tracking and stable quantity commits.
- Source/destination delta pairing and conservation status.
- Simplified video/result UI.

## Validation and limitations
- Pure-Java count and transfer logic is unit-tested with synthetic observations.
- XML and package structure are checked by GitHub Actions.
- A passing Android build proves compilation, not actual-video accuracy.
- Classical vision candidates may fail under occlusion, blur, low resolution, unusual backgrounds, or rotations. Exact one-card sensitivity must be measured on labelled frames from the user's clip.
