package com.mj.stacktracker.automatic;
import org.junit.Test;
import java.util.Arrays;
import static org.junit.Assert.*;
public class AutomaticTransferEngineTest {
 private PileObservation p(float l,float t,float r,float b,int c){return new PileObservation(l,t,r,b,c,.95,true);}
 @Test public void splitCountsRemainConserved(){
  AutomaticTransferEngine e=new AutomaticTransferEngine(416);AnalysisSnapshot s=null;
  for(int i=0;i<4;i++)s=e.update(i*180,Arrays.asList(p(.35f,.35f,.65f,.65f,416)));
  assertEquals(416,s.accountedCount);
  for(int i=4;i<12;i++)s=e.update(i*180,Arrays.asList(p(.15f,.35f,.37f,.65f,336),p(.55f,.35f,.75f,.65f,80)));
  assertEquals(416,s.accountedCount);assertTrue(s.piles.size()>=2);
 }
 @Test public void transferPairIsRecognizedAndParentIdentityKept(){
  AutomaticTransferEngine e=new AutomaticTransferEngine(416);AnalysisSnapshot s=null;
  for(int i=0;i<4;i++)s=e.update(i*180,Arrays.asList(p(.35f,.35f,.65f,.65f,416)));
  for(int i=4;i<12;i++)s=e.update(i*180,Arrays.asList(p(.15f,.35f,.37f,.65f,360),p(.55f,.35f,.75f,.65f,56)));
  assertEquals(416,s.accountedCount);assertFalse(s.transfers.isEmpty());
  TransferEvent event=s.transfers.get(0);assertEquals(56,event.quantity);
  assertEquals("PILE-01",event.sourcePileId);assertEquals("PILE-02",event.destinationPileId);
 }
}
