package com.mj.stacktracker.automatic;
import org.junit.Test;
import static org.junit.Assert.*;
public class RelativeCountEstimatorTest {
 private RelativeCountEstimator calibrated(){
  RelativeCountEstimator e=new RelativeCountEstimator(416);
  for(int i=0;i<5;i++)e.addReference(new CardMeasurement(.2f,.2f,.8f,.8f,.50,.95,.95,.95,.97,400));
  return e;
 }
 @Test public void reference416AndHalfHeightProducesHalfDeck(){
  RelativeCountEstimator.Estimate x=calibrated().estimate(new CardMeasurement(.2f,.2f,.8f,.8f,.25,.95,.95,.95,.97,200));
  assertTrue(x.valid);assertEquals(208,x.count);
 }
 @Test public void relativeReferenceCanRepresentSingleCard(){
  double ratio=0.50/416.0;
  RelativeCountEstimator.Estimate x=calibrated().estimate(new CardMeasurement(.2f,.2f,.8f,.8f,ratio,.95,.95,.95,.97,4));
  assertTrue(x.valid);assertEquals(1,x.count);
 }
 @Test public void relativeReferenceCanRepresentTwoCards(){
  double ratio=2.0*0.50/416.0;
  RelativeCountEstimator.Estimate x=calibrated().estimate(new CardMeasurement(.2f,.2f,.8f,.8f,ratio,.95,.95,.95,.97,8));
  assertTrue(x.valid);assertEquals(2,x.count);
 }
 @Test public void relativeReferenceCanRepresentTwentyCards(){
  double ratio=20.0*0.50/416.0;
  RelativeCountEstimator.Estimate x=calibrated().estimate(new CardMeasurement(.2f,.2f,.8f,.8f,ratio,.95,.95,.95,.97,20));
  assertTrue(x.valid);assertEquals(20,x.count);
 }
 @Test public void noReferenceMustNotInventCount(){
  RelativeCountEstimator e=new RelativeCountEstimator(416);
  RelativeCountEstimator.Estimate x=e.estimate(new CardMeasurement(.2f,.2f,.8f,.8f,.25,.95,.95,.95,.97,200));
  assertFalse(x.valid);
 }
}
