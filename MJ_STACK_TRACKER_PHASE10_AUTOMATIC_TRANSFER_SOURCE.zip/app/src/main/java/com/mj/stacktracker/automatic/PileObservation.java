package com.mj.stacktracker.automatic;

/** A single frame observation after image measurement and count estimation. */
public final class PileObservation {
    public final float left,top,right,bottom;
    public final int estimatedCount;
    public final double confidence;
    public final boolean countValid;
    public PileObservation(float l,float t,float r,float b,int count,double confidence,boolean valid){
        left=l;top=t;right=r;bottom=b;estimatedCount=count;this.confidence=confidence;countValid=valid;
    }
    public float cx(){return (left+right)*0.5f;}
    public float cy(){return (top+bottom)*0.5f;}
    public float width(){return Math.max(0,right-left);}
    public float height(){return Math.max(0,bottom-top);}
    public double area(){return width()*height();}
}
