package com.mj.stacktracker.automatic;

public final class TransferEvent {
    public final long timestampMs;
    public final String sourcePileId,destinationPileId;
    public final int quantity;
    public final double confidence;
    TransferEvent(long ts,String source,String destination,int quantity,double confidence){
        timestampMs=ts;sourcePileId=source;destinationPileId=destination;
        this.quantity=quantity;this.confidence=confidence;
    }
}
