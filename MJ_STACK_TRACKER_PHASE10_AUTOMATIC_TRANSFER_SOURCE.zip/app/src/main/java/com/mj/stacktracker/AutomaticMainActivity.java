package com.mj.stacktracker;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import com.mj.stacktracker.automatic.AnalysisSnapshot;
import com.mj.stacktracker.automatic.AutomaticAnalyzer;
import com.mj.stacktracker.automatic.TransferEvent;
import java.util.Locale;

/** Simple end-user screen: select and play a video; all visual analysis runs locally. */
public final class AutomaticMainActivity extends Activity {
    private static final int PICK_VIDEO=4101;
    private PlayerView playerView;
    private ExoPlayer player;
    private TextView status,summary,piles,transfers,progressLabel;
    private ProgressBar progress;
    private Uri selectedUri;
    private AutomaticAnalyzer analyzer;
    private boolean analysisStarted=false;
    private Button selectButton,playButton;

    @Override protected void onCreate(Bundle state){super.onCreate(state);analyzer=new AutomaticAnalyzer(this);buildUi();}
    private void buildUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.WHITE);root.setPadding(dp(12),dp(12),dp(12),dp(16));
        TextView title=new TextView(this);title.setText("MJ Stack Tracker");title.setTextColor(0xFF111827);title.setTextSize(22);title.setGravity(Gravity.CENTER_VERTICAL);title.setPadding(0,0,0,dp(8));root.addView(title);
        TextView subtitle=new TextView(this);subtitle.setText("Automatic 416-card quantity & transfer tracking");subtitle.setTextColor(0xFF52616B);subtitle.setTextSize(13);root.addView(subtitle);
        LinearLayout buttons=new LinearLayout(this);buttons.setOrientation(LinearLayout.HORIZONTAL);buttons.setPadding(0,dp(10),0,dp(8));
        selectButton=new Button(this);selectButton.setText("SELECT VIDEO");selectButton.setOnClickListener(v->pickVideo());buttons.addView(selectButton,new LinearLayout.LayoutParams(0,dp(48),1));
        playButton=new Button(this);playButton.setText("PLAY & ANALYZE");playButton.setEnabled(false);playButton.setOnClickListener(v->playAndAnalyze());LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(48),1);bp.leftMargin=dp(8);buttons.addView(playButton,bp);root.addView(buttons);
        playerView=new PlayerView(this);playerView.setUseController(true);playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);playerView.setBackgroundColor(Color.BLACK);playerView.setMinimumHeight(dp(190));root.addView(playerView,new LinearLayout.LayoutParams(-1,dp(220)));
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(1000);root.addView(progress,new LinearLayout.LayoutParams(-1,dp(5)));
        progressLabel=text("Choose a recorded video. Press PLAY & ANALYZE to start.",12,0xFF52616B);progressLabel.setPadding(0,dp(6),0,dp(5));root.addView(progressLabel);
        ScrollView scroll=new ScrollView(this);LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        section(content,"RESULT");summary=text("Starting inventory: 416 cards\nAnalysis has not started.",17,0xFF111827);summary.setPadding(dp(10),dp(12),dp(10),dp(12));summary.setBackgroundColor(0xFFF3F6F8);content.addView(summary);
        section(content,"PILE-WISE CARD COUNT");piles=text("No pile counts yet.",14,0xFF263238);piles.setPadding(dp(10),dp(8),dp(10),dp(8));content.addView(piles);
        section(content,"TRANSFER HISTORY");transfers=text("No transfer events yet.",14,0xFF263238);transfers.setPadding(dp(10),dp(8),dp(10),dp(8));content.addView(transfers);
        section(content,"STATUS");status=text("The app will detect the opening deck automatically. No mm calibration or manual 1/2/3-card teaching is required.",12,0xFF52616B);status.setPadding(dp(10),dp(8),dp(10),dp(12));content.addView(status);
        setContentView(root);
    }
    private void pickVideo(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("video/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);try{startActivityForResult(i,PICK_VIDEO);}catch(Exception e){Toast.makeText(this,"Video picker is unavailable.",Toast.LENGTH_LONG).show();}}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode!=PICK_VIDEO||resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        if(analysisStarted&&analyzer!=null)analyzer.cancel();analyzer=new AutomaticAnalyzer(this);analysisStarted=false;selectedUri=data.getData();
        try{getContentResolver().takePersistableUriPermission(selectedUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
        releasePlayer();player=new ExoPlayer.Builder(this).build();playerView.setPlayer(player);player.setMediaItem(MediaItem.fromUri(selectedUri));player.prepare();
        player.addListener(new Player.Listener(){@Override public void onIsPlayingChanged(boolean isPlaying){if(isPlaying&&!analysisStarted)startAnalysis();}});
        playButton.setEnabled(true);progress.setProgress(0);progressLabel.setText("Video loaded. Press PLAY & ANALYZE.");summary.setText("Starting inventory: 416 cards\nWaiting for playback and automatic analysis.");piles.setText("No pile counts yet.");transfers.setText("No transfer events yet.");status.setText("No manual stack selection, physical measurement or teaching step is used.");
    }
    private void playAndAnalyze(){if(player==null)return;player.seekTo(0);player.play();if(!analysisStarted)startAnalysis();}
    private void startAnalysis(){if(selectedUri==null||analysisStarted)return;analysisStarted=true;progress.setProgress(0);status.setText("Analyzing the full video locally. Keep the app open while processing.");
        new Thread(()->analyzer.analyze(selectedUri,new AutomaticAnalyzer.Listener(){
            @Override public void onProgress(int done,int total,String message,AnalysisSnapshot snapshot){runOnUiThread(()->{progress.setProgress((int)(1000.0*done/Math.max(1,total)));progressLabel.setText(String.format(Locale.US,"Processing %d / %d frames",done,total));if(snapshot!=null)renderSnapshot(snapshot);});}
            @Override public void onComplete(AnalysisSnapshot snapshot,String message){runOnUiThread(()->{progress.setProgress(1000);progressLabel.setText("Analysis complete");status.setText(message);if(snapshot!=null)renderSnapshot(snapshot);else analysisStarted=false;});}
            @Override public void onError(String message){runOnUiThread(()->{status.setText(message);progressLabel.setText("Analysis could not complete");analysisStarted=false;});}
        }),"MJ-Phase10-Video-Analysis").start();
    }
    private void renderSnapshot(AnalysisSnapshot s){
        String balance=s.balanced?"Total accounted: "+s.accountedCount+" / "+s.initialCount:"Accounted: "+s.accountedCount+" / "+s.initialCount+" • not yet assigned: "+s.unassignedCount;
        summary.setText("Starting cards: "+s.initialCount+"\n"+balance+"\n"+(s.balanced?"Pile total currently balances.":"Some cards are hidden, in transit or not confidently measured."));
        StringBuilder p=new StringBuilder();for(AnalysisSnapshot.Pile pile:s.piles){p.append(pile.id).append("  •  ").append(pile.count).append(" cards");if(!pile.visible)p.append("  (not currently visible)");p.append("\n");}piles.setText(p.length()==0?"No reliable pile measurements yet.":p.toString());
        StringBuilder t=new StringBuilder();for(TransferEvent e:s.transfers){t.append(String.format(Locale.US,"%s → %s  •  %d cards  •  %.0f%% evidence\n",e.sourcePileId,e.destinationPileId,e.quantity,e.confidence*100));}transfers.setText(t.length()==0?"No matched source-to-destination transfers yet.":t.toString());
    }
    private void releasePlayer(){if(player!=null){player.release();player=null;}if(playerView!=null)playerView.setPlayer(null);}
    private void section(LinearLayout root,String title){TextView t=text(title,13,0xFF334155);t.setTypeface(null,android.graphics.Typeface.BOLD);t.setPadding(dp(2),dp(14),dp(2),dp(5));root.addView(t);}
    private TextView text(String value,float size,int color){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);return t;}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    @Override protected void onDestroy(){if(analyzer!=null)analyzer.cancel();releasePlayer();super.onDestroy();}
}
