package com.mj.stacktracker.automatic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class AnalysisSnapshot {
    public static final class Pile {
        public final String id;
        public final int count;
        public final double confidence;
        public final boolean visible,verified;
        public final float centerX,centerY;
        Pile(String id,int count,double confidence,boolean visible,boolean verified,float x,float y){
            this.id=id;this.count=count;this.confidence=confidence;this.visible=visible;
            this.verified=verified;centerX=x;centerY=y;
        }
    }
    public final List<Pile> piles;
    public final List<TransferEvent> transfers;
    public final int initialCount,accountedCount,unassignedCount;
    public final boolean balanced;
    public final long timestampMs;
    AnalysisSnapshot(List<Pile> p,List<TransferEvent> t,int initial,int accounted,int unassigned,boolean balanced,long ts){
        piles=Collections.unmodifiableList(new ArrayList<>(p));
        transfers=Collections.unmodifiableList(new ArrayList<>(t));
        initialCount=initial;accountedCount=accounted;unassignedCount=unassigned;
        this.balanced=balanced;timestampMs=ts;
    }
}
