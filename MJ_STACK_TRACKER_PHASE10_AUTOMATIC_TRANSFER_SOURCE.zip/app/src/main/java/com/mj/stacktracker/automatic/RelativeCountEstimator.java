package com.mj.stacktracker.automatic;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.List;

/**
 * Counts pieces from the known 416-piece reference using a perspective-normalized,
 * image-derived layer span. It does not use millimetres or a fixed card thickness.
 * The visual measurements must already have passed the CardStackVision quality gates.
 */
public final class RelativeCountEstimator {
    public static final class Estimate {
        public final int count;
        public final double confidence;
        public final double normalizedRatio;
        public final boolean valid;
        Estimate(int count,double confidence,double ratio,boolean valid){
            this.count=count;this.confidence=confidence;this.normalizedRatio=ratio;this.valid=valid;
        }
    }
    private final int initialCount;
    private final Deque<Double> referenceSamples=new ArrayDeque<>();
    private double referenceRatio=Double.NaN;

    public RelativeCountEstimator(int initialCount){
        if(initialCount<1)throw new IllegalArgumentException("Initial count must be positive");
        this.initialCount=initialCount;
    }

    /** Build reference from several stable views of the intact original deck. */
    public synchronized boolean addReference(CardMeasurement m){
        if(!usable(m))return false;
        referenceSamples.addLast(m.normalizedLayerSpan);
        while(referenceSamples.size()> nine())referenceSamples.removeFirst();
        if(referenceSamples.size()<3)return false;
        referenceRatio=median(new ArrayList<>(referenceSamples));
        return Double.isFinite(referenceRatio)&&referenceRatio>1e-5;
    }
    private int nine(){return 9;}

    public synchronized void resetReference(){referenceSamples.clear();referenceRatio=Double.NaN;}
    public synchronized boolean isReady(){return Double.isFinite(referenceRatio)&&referenceRatio>1e-5;}
    public synchronized double getReferenceRatio(){return referenceRatio;}

    public synchronized Estimate estimate(CardMeasurement m){
        if(!isReady()||!usable(m))return new Estimate(0,0,Double.NaN,false);
        double ratio=m.normalizedLayerSpan/referenceRatio;
        if(!Double.isFinite(ratio)||ratio<0.0005||ratio>1.15)return new Estimate(0,0,ratio,false);
        double raw=initialCount*ratio;
        if(raw<0.5||raw>initialCount*1.08)return new Estimate(0,0,ratio,false);
        int count=(int)Math.round(raw);
        double referenceAgreement=1.0-Math.min(1.0,Math.abs(raw-count)/0.5);
        double confidence=0.32*m.confidence+0.24*m.edgePeriodicity+
                0.18*m.sharpness+0.16*m.rectangularity+0.10*referenceAgreement;
        // An exact-looking integer is not enough: low visual evidence must remain unresolved.
        boolean valid=count>=1&&count<=initialCount&&confidence>=0.64;
        return new Estimate(count,clamp(confidence),ratio,valid);
    }

    private boolean usable(CardMeasurement m){
        return m!=null&&Double.isFinite(m.normalizedLayerSpan)&&m.normalizedLayerSpan>0&&
                m.confidence>=0.40&&m.rectangularity>=0.22&&m.sharpness>=0.12&&
                m.edgePeriodicity>=0.08&&m.visibleEdgePeaks>=2;
    }
    private static double median(List<Double> values){
        if(values.isEmpty())return Double.NaN;
        Collections.sort(values);int n=values.size();
        return n%2==1?values.get(n/2):(values.get(n/2-1)+values.get(n/2))*0.5;
    }
    private static double clamp(double x){return Math.max(0,Math.min(1,x));}
}
