package com.mj.stacktracker.automatic;

import android.graphics.Bitmap;
import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.RotatedRect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Automatic full-frame candidate detection and card-layer visual measurement.
 * No manual ROI, millimetre scale, or card-thickness entry is required.
 */
public final class CardStackVision {
    private static final int MAX_WIDTH=1280;
    private final RelativeCountEstimator estimator=new RelativeCountEstimator(416);
    private float referenceCenterX=0.5f,referenceCenterY=0.5f;
    private boolean referenceSelected=false;
    private int referenceStableFrames=0;
    private CardMeasurement previousReference;

    public static final class FrameResult {
        public final List<PileObservation> piles;
        public final boolean referenceReady;
        public final String message;
        FrameResult(List<PileObservation> p,boolean ready,String m){piles=p;referenceReady=ready;message=m;}
    }

    public FrameResult analyze(Bitmap bitmap){return analyze(bitmap,true);}

    public FrameResult analyze(Bitmap bitmap,boolean allowReferenceCalibration){
        if(bitmap==null||bitmap.isRecycled())return new FrameResult(new ArrayList<>(),estimator.isReady(),"Invalid frame.");
        Mat rgba=new Mat(),gray=new Mat(),blur=new Mat(),edges=new Mat(),dilated=new Mat(),mask=new Mat(),hsv=new Mat(),whiteMask=new Mat();
        Mat hierarchy=new Mat();List<MatOfPoint> contours=new ArrayList<>();
        try{
            Utils.bitmapToMat(bitmap,rgba);
            double scale=Math.min(1.0,MAX_WIDTH/(double)Math.max(1,rgba.cols()));
            if(scale<0.999){Mat resized=new Mat();Imgproc.resize(rgba,resized,new Size(Math.max(1,Math.round(rgba.cols()*scale)),Math.max(1,Math.round(rgba.rows()*scale))));rgba.release();rgba=resized;}
            Imgproc.cvtColor(rgba,gray,Imgproc.COLOR_RGBA2GRAY);
            Imgproc.GaussianBlur(gray,blur,new Size(5,5),1.1);
            Imgproc.Canny(blur,edges,38,118);
            Mat kernel=Imgproc.getStructuringElement(Imgproc.MORPH_RECT,new Size(5,5));
            Imgproc.dilate(edges,dilated,kernel);
            Imgproc.morphologyEx(dilated,dilated,Imgproc.MORPH_CLOSE,kernel);
            Imgproc.cvtColor(rgba,hsv,Imgproc.COLOR_RGBA2RGB);
            Imgproc.cvtColor(hsv,hsv,Imgproc.COLOR_RGB2HSV);
            Core.inRange(hsv,new Scalar(0,0,76),new Scalar(180,112,255),whiteMask);
            Imgproc.morphologyEx(whiteMask,whiteMask,Imgproc.MORPH_CLOSE,kernel);
            Core.bitwise_or(dilated,whiteMask,mask);
            kernel.release();
            Imgproc.findContours(mask,contours,hierarchy,Imgproc.RETR_EXTERNAL,Imgproc.CHAIN_APPROX_SIMPLE);
            List<RawCandidate> candidates=new ArrayList<>();
            double imageArea=(double)gray.cols()*gray.rows();
            for(MatOfPoint contour:contours){
                double a=Imgproc.contourArea(contour);if(a<Math.max(110,imageArea*0.00028)||a>imageArea*0.28)continue;
                MatOfPoint2f c2=new MatOfPoint2f(contour.toArray());RotatedRect rr=Imgproc.minAreaRect(c2);c2.release();
                double w=Math.max(rr.size.width,rr.size.height),h=Math.min(rr.size.width,rr.size.height);
                if(w<15||h<8)continue;
                double aspect=h/w;if(aspect<0.035||aspect>0.98)continue;
                Rect b=Imgproc.boundingRect(contour);
                double boxArea=Math.max(1,(double)b.width*b.height);
                double rectangularity=Math.min(1,a/boxArea);
                if(rectangularity<0.18)continue;
                double cx=(b.x+b.width*0.5)/gray.cols(),cy=(b.y+b.height*0.5)/gray.rows();
                double center=Math.hypot(cx-0.5,cy-0.5);
                double sizeScore=Math.min(1,Math.sqrt(a/imageArea)/0.22);
                double centerScore=1-Math.min(1,center/0.72);
                double score=0.50*rectangularity+0.27*sizeScore+0.23*centerScore;
                RawCandidate raw=measure(gray,b,rectangularity,score,scale);
                if(raw!=null)candidates.add(raw);
            }
            candidates.sort(Comparator.comparingDouble((RawCandidate c)->c.score).reversed());
            candidates=suppress(candidates,18);
            if(!estimator.isReady()&&allowReferenceCalibration){
                RawCandidate original=selectOriginal(candidates);
                if(original!=null){
                    if(previousReference!=null&&similar(previousReference,original.measurement))referenceStableFrames++;
                    else {referenceStableFrames=1;estimator.resetReference();}
                    previousReference=original.measurement;
                    referenceCenterX=original.measurement.centerX();referenceCenterY=original.measurement.centerY();
                    // Do not calibrate from a one-frame contour: first require the same
                    // central object and near-identical geometry across stable samples.
                    if(referenceStableFrames>=3)estimator.addReference(original.measurement);
                } else {
                    referenceStableFrames=0;
                    previousReference=null;
                }
                if(!estimator.isReady())return new FrameResult(new ArrayList<>(),false,
                        "Finding the original 416-card deck in stable opening frames…");
            }
            List<PileObservation> observations=new ArrayList<>();
            for(RawCandidate c:candidates){
                RelativeCountEstimator.Estimate e=estimator.estimate(c.measurement);
                if(!e.valid)continue;
                CardMeasurement m=c.measurement;
                observations.add(new PileObservation(m.left,m.top,m.right,m.bottom,e.count,e.confidence,true));
            }
            if(observations.isEmpty())return new FrameResult(observations,true,
                    "Deck reference learned; waiting for clear pile edges.");
            return new FrameResult(observations,true,"Automatic pile measurements active.");
        }catch(Throwable t){
            return new FrameResult(new ArrayList<>(),estimator.isReady(),"Frame rejected: "+t.getClass().getSimpleName());
        }finally{
            for(MatOfPoint c:contours)c.release();
            rgba.release();gray.release();blur.release();edges.release();dilated.release();mask.release();hsv.release();whiteMask.release();hierarchy.release();
        }
    }

    private RawCandidate measure(Mat gray,Rect b,double rectangularity,double detectorScore,double scale){
        if(b.width<8||b.height<8)return null;
        Mat roi=gray.submat(b);
        Mat dx=new Mat(),dy=new Mat(),absX=new Mat(),absY=new Mat();
        try{
            Imgproc.Sobel(roi,dx,CvType.CV_16S,1,0,3);Imgproc.Sobel(roi,dy,CvType.CV_16S,0,1,3);
            Core.convertScaleAbs(dx,absX);Core.convertScaleAbs(dy,absY);
            // Gradient perpendicular to the line family gives the layer-axis profile.
            double[] px=projection(absX,false),py=projection(absY,true);
            Signal sx=signal(px),sy=signal(py);
            // The axis with the stronger repeated layer-edge pattern is treated as the
            // stack-thickness axis. Its ratio to the perpendicular card-face span cancels zoom.
            boolean useY=sy.score>=sx.score;
            double layerSpan=useY?b.height:b.width;
            double faceSpan=useY?b.width:b.height;
            Signal chosen=useY?sy:sx;
            // When repeated card-edge peaks are visible, use their sub-pixel outer span.
            // Otherwise fall back to the full layer-axis geometry and lower the evidence score.
            double measuredSpan=chosen.peakCount>=3&&chosen.peakSpan>1?chosen.peakSpan:layerSpan;
            double edgePeriodicity=Math.max(0,Math.min(1,chosen.regularity*0.65+Math.min(1,chosen.peakCount/12.0)*0.35));
            double sharpness=Math.max(0,Math.min(1,chosen.energy/42.0));
            double norm=(measuredSpan/Math.max(1,faceSpan));
            double quality=0.38*detectorScore+0.25*rectangularity+0.22*edgePeriodicity+0.15*sharpness;
            float l=b.x/(float)gray.cols(),t=b.y/(float)gray.rows(),r=(b.x+b.width)/(float)gray.cols(),bt=(b.y+b.height)/(float)gray.rows();
            CardMeasurement m=new CardMeasurement(l,t,r,bt,norm,edgePeriodicity,sharpness,rectangularity,quality,chosen.peakCount);
            return new RawCandidate(m,detectorScore);
        }finally{roi.release();dx.release();dy.release();absX.release();absY.release();}
    }

    private double[] projection(Mat grad,boolean vertical){
        int n=vertical?grad.rows():grad.cols();double[] out=new double[n];
        int orth=vertical?grad.cols():grad.rows();
        for(int i=0;i<n;i++){
            double sum=0;for(int j=(int)(orth*0.12);j<orth*0.88;j+=Math.max(1,orth/90)){
                double[] v=vertical?grad.get(i,j):grad.get(j,i);if(v!=null&&v.length>0)sum+=v[0];
            }
            int samples=Math.max(1,(int)Math.ceil((orth*0.76)/Math.max(1,orth/90)));
            out[i]=sum/samples;
        }
        return out;
    }
    private Signal signal(double[] p){
        if(p.length<8)return new Signal(0,0,0,0);
        double[] smooth=new double[p.length];
        for(int i=1;i<p.length-1;i++)smooth[i]=(p[i-1]+2*p[i]+p[i+1])*0.25;
        double[] sorted=smooth.clone();java.util.Arrays.sort(sorted);double median=sorted[sorted.length/2];
        double[] dev=new double[sorted.length];for(int i=0;i<dev.length;i++)dev[i]=Math.abs(smooth[i]-median);
        java.util.Arrays.sort(dev);double mad=dev[dev.length/2]+1e-6;
        double threshold=median+Math.max(3.0,2.4*mad);
        int peaks=0,last=-3;double peakSum=0;List<Double> positions=new ArrayList<>();
        for(int i=2;i<smooth.length-2;i++){
            if(smooth[i]>=threshold&&smooth[i]>=smooth[i-1]&&smooth[i]>smooth[i+1]&&i-last>=2){
                peaks++;last=i;peakSum+=smooth[i];
                double ym=smooth[i-1],y0=smooth[i],yp=smooth[i+1];
                double denom=ym-2*y0+yp;double offset=Math.abs(denom)<1e-9?0.0:0.5*(ym-yp)/denom;
                offset=Math.max(-0.5,Math.min(0.5,offset));positions.add(i+offset);
            }
        }
        double regularity=0;double peakSpan=0;
        if(positions.size()>=3){
            List<Double> gaps=new ArrayList<>();for(int i=1;i<positions.size();i++)gaps.add(positions.get(i)-positions.get(i-1));
            peakSpan=Math.max(1,positions.get(positions.size()-1)-positions.get(0));
            double mean=0;for(double g:gaps)mean+=g;mean/=gaps.size();double var=0;for(double g:gaps)var+=(g-mean)*(g-mean);var/=gaps.size();
            regularity=mean<=0?0:Math.max(0,1-Math.sqrt(var)/mean);
        }
        double energy=peakSum/Math.max(1,peaks);
        double score=(Math.min(1,peaks/8.0)*0.45+regularity*0.35+Math.min(1,energy/55.0)*0.20);
        return new Signal(peaks,regularity,energy,score,peakSpan);
    }
    private RawCandidate selectOriginal(List<RawCandidate> list){
        RawCandidate best=null;double bestScore=-1;
        for(RawCandidate c:list){
            CardMeasurement m=c.measurement;
            double d=Math.hypot(m.centerX()-0.5,m.centerY()-0.5);
            double score=c.score*0.72+(1-Math.min(1,d/0.65))*0.28;
            if(score>bestScore){bestScore=score;best=c;}
        }
        return best;
    }
    private boolean similar(CardMeasurement a,CardMeasurement b){
        return Math.hypot(a.centerX()-b.centerX(),a.centerY()-b.centerY())<0.055&&
                Math.abs(a.normalizedLayerSpan-b.normalizedLayerSpan)<Math.max(0.03,a.normalizedLayerSpan*0.20);
    }
    private List<RawCandidate> suppress(List<RawCandidate> in,int max){
        List<RawCandidate> out=new ArrayList<>();
        for(RawCandidate c:in){boolean dup=false;for(RawCandidate p:out){if(iou(c.measurement,p.measurement)>0.55){dup=true;break;}}
            if(!dup)out.add(c);if(out.size()>=max)break;}
        return out;
    }
    private double iou(CardMeasurement a,CardMeasurement b){double l=Math.max(a.left,b.left),t=Math.max(a.top,b.top),r=Math.min(a.right,b.right),bt=Math.min(a.bottom,b.bottom);double inter=Math.max(0,r-l)*Math.max(0,bt-t);double u=a.area()+b.area()-inter;return u<=0?0:inter/u;}
    private static final class Signal{final int peakCount;final double regularity,energy,score,peakSpan;Signal(int p,double r,double e,double s){this(p,r,e,s,0);}Signal(int p,double r,double e,double s,double span){peakCount=p;regularity=r;energy=e;score=s;peakSpan=span;}}
    private static final class RawCandidate{final CardMeasurement measurement;final double score;RawCandidate(CardMeasurement m,double s){measurement=m;score=s;}}
}
