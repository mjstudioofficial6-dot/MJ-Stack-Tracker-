package com.mj.stacktracker.automatic;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import org.opencv.android.OpenCVLoader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** Offline sampled-video analysis. OpenCV runs locally; no network service is used. */
public final class AutomaticAnalyzer {
    public interface Listener {
        void onProgress(int done,int total,String status,AnalysisSnapshot snapshot);
        void onComplete(AnalysisSnapshot snapshot,String status);
        void onError(String message);
    }
    private static final long SAMPLE_INTERVAL_MS=180;
    private static final int MAX_ANALYSIS_WIDTH=1280;
    private final Context appContext;
    private final AtomicBoolean cancelled=new AtomicBoolean(false);
    public AutomaticAnalyzer(Context context){appContext=context.getApplicationContext();}
    public void cancel(){cancelled.set(true);}

    public void analyze(Uri uri,Listener listener){
        if(uri==null){listener.onError("Select a video first.");return;}
        try{if(!OpenCVLoader.initLocal()){listener.onError("On-device image engine could not initialize.");return;}}
        catch(Throwable loadError){listener.onError("On-device image engine could not load: "+loadError.getClass().getSimpleName());return;}
        MediaMetadataRetriever retriever=new MediaMetadataRetriever();
        try{
            retriever.setDataSource(appContext,uri);
            String d=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            long duration=d==null?0:Long.parseLong(d);
            if(duration<500){listener.onError("Video duration could not be read.");return;}
            int total=(int)Math.max(1,Math.ceil(duration/(double)SAMPLE_INTERVAL_MS));
            CardStackVision vision=new CardStackVision();
            AutomaticTransferEngine transferEngine=new AutomaticTransferEngine(416);
            AnalysisSnapshot latest=null;int goodFrames=0;
            for(int i=0;i<total&&!cancelled.get();i++){
                long ts=Math.min(duration-1,i*SAMPLE_INTERVAL_MS);
                Bitmap frame=retriever.getFrameAtTime(ts*1000L,MediaMetadataRetriever.OPTION_CLOSEST);
                if(frame!=null){
                    Bitmap scaled=frame;
                    if(frame.getWidth()>MAX_ANALYSIS_WIDTH){int w=MAX_ANALYSIS_WIDTH;int h=Math.max(1,(int)Math.round(frame.getHeight()*(w/(double)frame.getWidth())));scaled=Bitmap.createScaledBitmap(frame,w,h,true);}
                    try{
                        CardStackVision.FrameResult result=vision.analyze(scaled);
                        if(result.referenceReady&&!result.piles.isEmpty()){
                            latest=transferEngine.update(ts,result.piles);goodFrames++;
                        }
                        if(i%4==0||i==total-1)listener.onProgress(i+1,total,result.message,latest);
                    }finally{
                        if(scaled!=frame&&!scaled.isRecycled())scaled.recycle();
                        if(!frame.isRecycled())frame.recycle();
                    }
                }else if(i%4==0)listener.onProgress(i+1,total,"Decoding video frame…",latest);
            }
            if(cancelled.get()){listener.onComplete(latest,"Analysis stopped by user.");return;}
            if(latest==null||goodFrames<3){listener.onComplete(latest,"Original 416-card deck could not be measured reliably in the opening video frames. No exact quantity was invented.");return;}
            String status=String.format(Locale.US,"Analysis finished. %d usable visual samples. Counts are image-derived estimates; compare the pile totals and transfer history.",goodFrames);
            listener.onComplete(latest,status);
        }catch(Exception e){listener.onError("Video analysis failed: "+e.getClass().getSimpleName()+" — "+String.valueOf(e.getMessage()));}
        finally{try{retriever.release();}catch(Exception ignored){}}
    }
}
