package com.mj.stacktracker.automatic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Temporal pile identity, count stabilization, transfer pairing and conservation.
 * It deliberately keeps hidden/missing cards as unassigned instead of deleting them.
 */
public final class AutomaticTransferEngine {
    private static final int STABLE_SAMPLES=3;
    private static final long TRANSFER_WINDOW_MS=1800;
    private static final class Track {
        String id;float l,t,r,b;float cx,cy;int visibleMisses,seen;
        int committedCount;int candidateCount,candidateRepeats;double confidence;
        boolean countKnown;long lastSeen;
        Track(String id,PileObservation o,long ts,boolean root){
            this.id=id;updateBox(o);lastSeen=ts;seen=1;confidence=o.confidence;
            if(root){committedCount=o.estimatedCount;countKnown=true;candidateCount=o.estimatedCount;candidateRepeats=STABLE_SAMPLES;}
        }
        void updateBox(PileObservation o){l=o.left;t=o.top;r=o.right;b=o.bottom;cx=o.cx();cy=o.cy();}
    }
    private static final class Delta {
        String pileId;int amount;long ts;double confidence;
        Delta(String id,int amount,long ts,double c){pileId=id;this.amount=amount;this.ts=ts;confidence=c;}
    }
    private final int initialCount;
    private final List<Track> tracks=new ArrayList<>();
    private final List<TransferEvent> transfers=new ArrayList<>();
    private final List<Delta> pendingDeltas=new ArrayList<>();
    private int nextPile=2;
    private final List<AnalysisSnapshot.Pile> published=new ArrayList<>();

    public AutomaticTransferEngine(int initialCount){
        if(initialCount<1)throw new IllegalArgumentException("initialCount");
        this.initialCount=initialCount;
    }

    public synchronized AnalysisSnapshot update(long timestampMs,List<PileObservation> observations){
        if(observations==null)observations=Collections.emptyList();
        for(Track t:tracks)t.visibleMisses++;
        List<PileObservation> remaining=new ArrayList<>();
        for(PileObservation o:observations)if(o!=null&&o.confidence>=0.42&&o.area()>0.00008)remaining.add(o);
        // Seed the known intact starting deck as PILE-01. The initial quantity is a
        // user/product invariant (416), not an image guess.
        if(tracks.isEmpty()&&!remaining.isEmpty()){
            PileObservation root=null;double best=-1;
            for(PileObservation o:remaining){
                double countFit=1.0-Math.min(1.0,Math.abs(o.estimatedCount-initialCount)/(double)initialCount);
                double score=0.60*countFit+0.25*o.confidence+0.15*Math.min(1.0,Math.sqrt(o.area())/0.6);
                if(o.countValid&&score>best){best=score;root=o;}
            }
            if(root!=null){
                Track master=new Track("PILE-01",root,timestampMs,true);
                master.committedCount=initialCount;master.candidateCount=initialCount;
                master.candidateRepeats=STABLE_SAMPLES;master.countKnown=true;tracks.add(master);
            }
        }
        // Greedy global association by a combined IoU + normalized centre-distance cost.
        List<Match> matches=new ArrayList<>();
        for(Track t:tracks){
            for(int i=0;i<remaining.size();i++){
                PileObservation o=remaining.get(i);
                double d=Math.hypot(t.cx-o.cx(),t.cy-o.cy());
                double iou=iou(t.l,t.t,t.r,t.b,o.left,o.top,o.right,o.bottom);
                double size=Math.max(o.area(),1e-8)/Math.max(tArea(t),1e-8);
                double sizePenalty=Math.abs(Math.log(Math.max(1e-6,size)));
                // Count continuity is a key identity cue during a split: the parent
                // remains the child pile whose count is closest to its prior quantity.
                double countPenalty=(t.countKnown&&o.countValid)
                        ?Math.min(1.0,Math.abs(t.committedCount-o.estimatedCount)/(double)initialCount):0.35;
                double cost=0.38*(1-iou)+0.24*Math.min(1,d/0.28)+
                        0.25*countPenalty+0.13*Math.min(1,sizePenalty/1.4);
                if((iou>=0.025||d<=0.24)&&size>=0.18&&size<=5.5&&cost<0.90)matches.add(new Match(t,i,cost));
            }
        }
        matches.sort(Comparator.comparingDouble(m->m.cost));
        boolean[] usedTracks=new boolean[tracks.size()];boolean[] usedObs=new boolean[remaining.size()];
        List<Delta> frameDeltas=new ArrayList<>();
        for(Match m:matches){
            int ti=tracks.indexOf(m.track);
            if(ti<0||usedTracks[ti]||usedObs[m.observationIndex])continue;
            usedTracks[ti]=true;usedObs[m.observationIndex]=true;
            PileObservation o=remaining.get(m.observationIndex);
            updateTrack(m.track,o,timestampMs,frameDeltas);
        }
        for(int i=0;i<remaining.size();i++){
            if(usedObs[i])continue;
            PileObservation o=remaining.get(i);
            if(o.countValid){
                Track t=new Track(String.format(java.util.Locale.US,"PILE-%02d",nextPile++),o,timestampMs,false);
                // A child pile must persist for multiple samples before its count is committed.
                t.candidateCount=o.estimatedCount;t.candidateRepeats=1;t.seen=1;
                tracks.add(t);
            }
        }
        for(Track t:tracks){if(t.visibleMisses==0)t.lastSeen=timestampMs;}
        pairTransfers(frameDeltas);
        return snapshot(timestampMs);
    }

    private void updateTrack(Track t,PileObservation o,long ts,List<Delta> deltas){
        t.visibleMisses=0;t.seen++;t.lastSeen=ts;t.updateBox(o);t.confidence=o.confidence;
        if(!o.countValid)return;
        if(o.estimatedCount==t.candidateCount)t.candidateRepeats++;
        else{t.candidateCount=o.estimatedCount;t.candidateRepeats=1;}
        if(t.candidateRepeats>=STABLE_SAMPLES){
            if(!t.countKnown){
                t.committedCount=t.candidateCount;t.countKnown=true;
                if(t.committedCount>0)deltas.add(new Delta(t.id,t.committedCount,ts,t.confidence));
            }else if(t.candidateCount!=t.committedCount){
                int delta=t.candidateCount-t.committedCount;
                t.committedCount=t.candidateCount;
                if(delta!=0)deltas.add(new Delta(t.id,delta,ts,t.confidence));
            }
        }
    }

    private void pairTransfers(List<Delta> deltas){
        List<Delta> decreases=new ArrayList<>(),increases=new ArrayList<>();
        for(Delta d:deltas){if(d.amount<0)decreases.add(d);else if(d.amount>0)increases.add(d);}
        for(Delta dec:decreases){
            int quantity=-dec.amount;
            Delta best=null;int bestError=Integer.MAX_VALUE;
            for(Delta inc:increases){
                if(inc.pileId.equals(dec.pileId)||Math.abs(inc.ts-dec.ts)>TRANSFER_WINDOW_MS)continue;
                int err=Math.abs(inc.amount-quantity);
                // Do not claim a transfer when independently estimated source and
                // destination deltas disagree. Leave it unresolved instead.
                if(err==0&&err<bestError){best=inc;bestError=err;}
            }
            if(best!=null){
                int confirmed=Math.min(quantity,best.amount);
                double c=Math.min(dec.confidence,best.confidence)*(bestError==0?1.0:0.92);
                transfers.add(new TransferEvent(Math.max(dec.ts,best.ts),dec.pileId,best.pileId,confirmed,c));
                increases.remove(best);
            }else{
                pendingDeltas.add(dec);
            }
        }
        // New pile counts may appear slightly after the source decrease; pair against recent source deltas.
        for(Delta inc:increases){
            Delta best=null;int bestError=Integer.MAX_VALUE;
            for(Delta dec:pendingDeltas){
                if(inc.pileId.equals(dec.pileId)||Math.abs(inc.ts-dec.ts)>TRANSFER_WINDOW_MS)continue;
                int err=Math.abs(inc.amount+dec.amount);
                if(err==0&&err<bestError){best=dec;bestError=err;}
            }
            if(best!=null){
                transfers.add(new TransferEvent(Math.max(inc.ts,best.ts),best.pileId,inc.pileId,
                        Math.min(inc.amount,-best.amount),Math.min(inc.confidence,best.confidence)));
                pendingDeltas.remove(best);
            }
        }
        long newest=0;for(Delta d:deltas)newest=Math.max(newest,d.ts);
        final long newestTimestamp=newest;
        if(newestTimestamp>0)pendingDeltas.removeIf(d -> newestTimestamp-d.ts>TRANSFER_WINDOW_MS*3);
    }

    private AnalysisSnapshot snapshot(long ts){
        List<AnalysisSnapshot.Pile> rows=new ArrayList<>();int accounted=0;
        for(Track t:tracks){
            if(!t.countKnown||t.committedCount<0)continue;
            if(t.visibleMisses<=2)accounted+=t.committedCount;
            rows.add(new AnalysisSnapshot.Pile(t.id,t.committedCount,t.confidence,t.visibleMisses<=2,
                    t.candidateRepeats>=STABLE_SAMPLES,t.cx,t.cy));
        }
        rows.sort(Comparator.comparing(p->p.id));
        int unassigned=Math.max(0,initialCount-accounted);
        boolean balanced=accounted==initialCount;
        return new AnalysisSnapshot(rows,transfers,initialCount,accounted,unassigned,balanced,ts);
    }
    private static double tArea(Track t){return Math.max(0,t.r-t.l)*Math.max(0,t.b-t.t);}
    private static double iou(float al,float at,float ar,float ab,float bl,float bt,float br,float bb){
        double l=Math.max(al,bl),t=Math.max(at,bt),r=Math.min(ar,br),b=Math.min(ab,bb);
        double inter=Math.max(0,r-l)*Math.max(0,b-t),union=(ar-al)*(ab-at)+(br-bl)*(bb-bt)-inter;
        return union<=0?0:inter/union;
    }
    private static final class Match{final Track track;final int observationIndex;final double cost;Match(Track t,int i,double c){track=t;observationIndex=i;cost=c;}}
}
