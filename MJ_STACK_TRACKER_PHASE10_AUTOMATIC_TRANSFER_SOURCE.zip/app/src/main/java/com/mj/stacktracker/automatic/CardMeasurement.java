package com.mj.stacktracker.automatic;

/** One visual measurement of a candidate stack in normalized video coordinates. */
public final class CardMeasurement {
    public final float left, top, right, bottom;
    public final double normalizedLayerSpan;
    public final double edgePeriodicity;
    public final double sharpness;
    public final double rectangularity;
    public final double confidence;
    public final int visibleEdgePeaks;

    public CardMeasurement(float left, float top, float right, float bottom,
                           double normalizedLayerSpan, double edgePeriodicity,
                           double sharpness, double rectangularity,
                           double confidence, int visibleEdgePeaks) {
        this.left=left; this.top=top; this.right=right; this.bottom=bottom;
        this.normalizedLayerSpan=normalizedLayerSpan;
        this.edgePeriodicity=edgePeriodicity; this.sharpness=sharpness;
        this.rectangularity=rectangularity; this.confidence=confidence;
        this.visibleEdgePeaks=visibleEdgePeaks;
    }
    public float centerX(){return (left+right)*0.5f;}
    public float centerY(){return (top+bottom)*0.5f;}
    public float width(){return Math.max(0,right-left);}
    public float height(){return Math.max(0,bottom-top);}
    public double area(){return width()*height();}
}
