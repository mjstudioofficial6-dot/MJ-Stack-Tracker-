# MJ Stack Tracker — Phase 10 Automatic Card Quantity & Transfer

- App version: **1.0.0** (`versionCode 16`)
- Package: `com.mj.stacktracker.phase9` (preserved for package identity)
- Platform: native Android / Java 17 / Android SDK 36
- Runtime: offline analysis of a video selected from the phone
- Permissions: no camera or Internet permission; video access is via Android document picker.

## User workflow
1. Tap **SELECT VIDEO** and choose the recorded clip.
2. Tap **PLAY & ANALYZE** (or use the player's Play control).
3. The app samples the full video locally and shows pile-wise quantities, matched transfers and unassigned cards.

No manual object rectangle, millimetre calibration, 0.33 mm/card entry, or Teach 1/2/3 popup is included in the new launcher screen.

## Internal engine structure
- `AutomaticAnalyzer`: sequential local video-frame extraction.
- `CardStackVision`: automatic full-frame pile candidate proposals, directional edge projections, and sub-pixel edge-peak analysis.
- `RelativeCountEstimator`: relative scaling against the known 416-card opening stack; no physical units.
- `AutomaticTransferEngine`: temporal object association, stable count updates, source/destination quantity pairing, and conservation accounting.
- `AutomaticMainActivity`: video selection, playback, progress, pile-wise output and transfer history.

## Accuracy boundary
This is an implementation candidate, not a certified card-counting product. The vision detector and relative layer measurement are classical computer vision and remain dependent on the video making the card stack's layer edges visible. If the opening deck cannot be isolated in the first 3 seconds, or the edge evidence is too weak, the app does not invent an exact count. A one-card change smaller than the available image information cannot be guaranteed by mathematics alone. The Phase 10 workflow runs unit tests and builds the APK; real-video accuracy requires validation against labelled samples from the actual recording.

## GitHub build
Upload this ZIP to the repository root and upload the separate workflow file to `.github/workflows/build-phase10-automatic-transfer.yml`. Then run the **Build MJ Stack Tracker Phase 10 Automatic Transfer** workflow.
