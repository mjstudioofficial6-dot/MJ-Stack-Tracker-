#!/usr/bin/env python3
"""Fast structural sanity checks run before the Android Gradle build."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "settings.gradle",
    "build.gradle",
    "gradle.properties",
    "app/build.gradle",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/mjthakur/stacktracker/MainActivity.java",
    "app/src/main/java/com/mjthakur/stacktracker/StackLedger.java",
    "app/src/main/java/com/mjthakur/stacktracker/StackOverlayView.java",
    "app/src/main/java/com/mjthakur/stacktracker/FrameQualityAnalyzer.java",
    ".github/workflows/build-apk.yml",
]
errors = []
for relative in REQUIRED:
    if not (ROOT / relative).is_file():
        errors.append(f"Missing required file: {relative}")

build_gradle = (ROOT / "app/build.gradle").read_text(encoding="utf-8") if (ROOT / "app/build.gradle").exists() else ""
manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8") if (ROOT / "app/src/main/AndroidManifest.xml").exists() else ""
ledger = (ROOT / "app/src/main/java/com/mjthakur/stacktracker/StackLedger.java").read_text(encoding="utf-8") if (ROOT / "app/src/main/java/com/mjthakur/stacktracker/StackLedger.java").exists() else ""
activity = (ROOT / "app/src/main/java/com/mjthakur/stacktracker/MainActivity.java").read_text(encoding="utf-8") if (ROOT / "app/src/main/java/com/mjthakur/stacktracker/MainActivity.java").exists() else ""

checks = [
    ("AGP version pinned", "version '9.4.0'" in (ROOT / "build.gradle").read_text(encoding="utf-8")),
    ("Media3 version pinned", "media3-exoplayer:1.11.1" in build_gradle and "media3-ui:1.11.1" in build_gradle),
    ("Compile SDK 36", "compileSdk 36" in build_gradle),
    ("No INTERNET permission", "android.permission.INTERNET" not in manifest),
    ("Initial 416 baseline", "INITIAL_TOTAL = 416" in ledger),
    ("Thickness constant", "PIECE_THICKNESS_MM = 0.33" in ledger),
    ("Local video picker present", "ACTION_OPEN_DOCUMENT" in activity and 'setType("video/*")' in activity),
    ("Manual overlay controls present", "Adjust Lines" in activity and "saveCalibration" in activity),
    ("Transfer operation present", "ledger.transfer" in activity),
    ("Analysis-only filter path present", "makeAnalysisFilter" in (ROOT / "app/src/main/java/com/mjthakur/stacktracker/FrameQualityAnalyzer.java").read_text(encoding="utf-8")),
]
for label, passed in checks:
    if not passed:
        errors.append(f"Failed check: {label}")

if errors:
    print("Project validation FAILED:")
    for error in errors:
        print(f" - {error}")
    sys.exit(1)

print(f"Project structure valid: {len(REQUIRED)} required files; {len(checks)} assertions passed.")
print("Note: this check does not replace the Android Gradle build or device testing.")
