package com.mjthakur.stacktracker;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;

/**
 * Relative frame-detail check plus an analysis-only grayscale/contrast/sharpen variant.
 * The scores are not calibrated probabilities and do not estimate piece count.
 */
public final class FrameQualityAnalyzer {
    private FrameQualityAnalyzer() { }

    public static Result analyze(Context context, Uri uri, long positionMs) throws Exception {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        Bitmap frame = null;
        Bitmap reduced = null;
        try {
            retriever.setDataSource(context, uri);
            long positionUs = Math.max(0L, positionMs) * 1000L;
            int sourceWidth = parsePositive(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
            int sourceHeight = parsePositive(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));

            // Prefer a decoder-scaled frame on Android 8.1+ so a 4K clip does not require a full-size
            // bitmap for this lightweight frame-quality check. Older devices use the fallback below.
            if (Build.VERSION.SDK_INT >= 27) {
                frame = retriever.getScaledFrameAtTime(positionUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 320, 320);
            }
            if (frame == null) {
                frame = retriever.getFrameAtTime(positionUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            }
            if (frame == null) throw new IllegalStateException("No frame available at this position.");
            if (sourceWidth <= 0) sourceWidth = frame.getWidth();
            if (sourceHeight <= 0) sourceHeight = frame.getHeight();

            int width = frame.getWidth();
            int height = frame.getHeight();
            if (Math.max(width, height) > 320) {
                float scale = 320f / Math.max(width, height);
                int reducedWidth = Math.max(3, Math.round(width * scale));
                int reducedHeight = Math.max(3, Math.round(height * scale));
                reduced = Bitmap.createScaledBitmap(frame, reducedWidth, reducedHeight, true);
                width = reduced.getWidth();
                height = reduced.getHeight();
            } else {
                reduced = frame;
                frame = null;
            }

            int[] pixels = new int[width * height];
            reduced.getPixels(pixels, 0, width, 0, 0, width, height);
            double originalScore = laplacianVariance(pixels, width, height);
            int[] filteredPixels = makeAnalysisFilter(pixels, width, height);
            double filteredScore = laplacianVariance(filteredPixels, width, height);
            return new Result(sourceWidth, sourceHeight, width, height, originalScore, filteredScore);
        } finally {
            if (reduced != null && !reduced.isRecycled()) reduced.recycle();
            if (frame != null && !frame.isRecycled()) frame.recycle();
            try { retriever.release(); } catch (RuntimeException ignored) { }
        }
    }

    private static int parsePositive(String value) {
        try { int parsed = Integer.parseInt(value == null ? "" : value); return parsed > 0 ? parsed : 0; }
        catch (NumberFormatException ignored) { return 0; }
    }

    private static double laplacianVariance(int[] pixels, int width, int height) {
        double sum = 0.0, sumSquares = 0.0;
        long samples = 0;
        for (int y = 1; y < height - 1; y++) {
            int row = y * width;
            for (int x = 1; x < width - 1; x++) {
                int index = row + x;
                int center = gray(pixels[index]);
                int laplacian = (4 * center)
                        - gray(pixels[index - 1])
                        - gray(pixels[index + 1])
                        - gray(pixels[index - width])
                        - gray(pixels[index + width]);
                sum += laplacian;
                sumSquares += (double) laplacian * laplacian;
                samples++;
            }
        }
        if (samples == 0) return 0.0;
        double mean = sum / samples;
        return Math.max(0.0, (sumSquares / samples) - mean * mean);
    }

    /** Grayscale + gentle contrast + unsharp-mask-like analysis copy. Original pixels are untouched. */
    private static int[] makeAnalysisFilter(int[] pixels, int width, int height) {
        int[] grayPixels = new int[pixels.length];
        int[] enhanced = new int[pixels.length];
        for (int i = 0; i < pixels.length; i++) {
            int g = gray(pixels[i]);
            int contrast = clamp((int) Math.round(128.0 + (g - 128.0) * 1.08));
            grayPixels[i] = ColorUtil.rgb(contrast, contrast, contrast);
        }
        System.arraycopy(grayPixels, 0, enhanced, 0, grayPixels.length);
        for (int y = 1; y < height - 1; y++) {
            int row = y * width;
            for (int x = 1; x < width - 1; x++) {
                int index = row + x;
                int center = gray(grayPixels[index]);
                int neighbors = gray(grayPixels[index - 1]) + gray(grayPixels[index + 1])
                        + gray(grayPixels[index - width]) + gray(grayPixels[index + width]);
                int value = clamp((int) Math.round(center * 1.25 - neighbors * 0.0625));
                enhanced[index] = ColorUtil.rgb(value, value, value);
            }
        }
        return enhanced;
    }

    private static int gray(int color) {
        int r = (color >> 16) & 0xff;
        int g = (color >> 8) & 0xff;
        int b = color & 0xff;
        return (r * 299 + g * 587 + b * 114) / 1000;
    }

    private static int clamp(int value) { return Math.max(0, Math.min(255, value)); }

    private static final class ColorUtil {
        static int rgb(int r, int g, int b) { return 0xff000000 | (r << 16) | (g << 8) | b; }
    }

    public static final class Result {
        public final int originalWidth;
        public final int originalHeight;
        public final int analyzedWidth;
        public final int analyzedHeight;
        public final double originalLaplacianVariance;
        public final double filteredLaplacianVariance;
        Result(int originalWidth, int originalHeight, int analyzedWidth, int analyzedHeight,
               double originalLaplacianVariance, double filteredLaplacianVariance) {
            this.originalWidth = originalWidth;
            this.originalHeight = originalHeight;
            this.analyzedWidth = analyzedWidth;
            this.analyzedHeight = analyzedHeight;
            this.originalLaplacianVariance = originalLaplacianVariance;
            this.filteredLaplacianVariance = filteredLaplacianVariance;
        }
    }
}
