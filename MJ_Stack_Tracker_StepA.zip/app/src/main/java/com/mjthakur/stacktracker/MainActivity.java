package com.mjthakur.stacktracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int REQUEST_PICK_VIDEO = 4101;
    private static final int BG = Color.rgb(16, 19, 24);
    private static final int PANEL = Color.rgb(27, 32, 40);
    private static final int TEXT = Color.rgb(238, 242, 247);
    private static final int MUTED = Color.rgb(167, 178, 192);
    private static final int BLUE = Color.rgb(30, 136, 229);
    private static final int RED = Color.rgb(221, 58, 58);

    private ExoPlayer player;
    private PlayerView playerView;
    private StackOverlayView overlayView;
    private StackLedger ledger;
    private Uri currentVideoUri;
    private TextView videoStatus;
    private TextView totalSummary;
    private TextView qualityStatus;
    private LinearLayout stacksContainer;
    private LinearLayout historyContainer;
    private final ExecutorService background = Executors.newSingleThreadExecutor();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        ledger = new StackLedger(this);
        buildInterface();
        refreshDashboard();
        if (savedInstanceState != null) {
            String uri = savedInstanceState.getString("video_uri");
            if (uri != null) loadVideo(Uri.parse(uri), false);
        }
    }

    private void buildInterface() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), dp(7), dp(12), dp(7));
        header.setBackgroundColor(BG);
        TextView title = text("MJ Stack Tracker", 19, TEXT, true);
        LinearLayout titleBlock = new LinearLayout(this);
        titleBlock.setOrientation(LinearLayout.VERTICAL);
        titleBlock.addView(title);
        titleBlock.addView(text("STEP A · VIDEO + DIGITAL STACK MODEL", 10, MUTED, true));
        header.addView(titleBlock, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button openVideo = button("Open Video", BLUE);
        openVideo.setOnClickListener(v -> pickVideo());
        header.addView(openVideo);
        root.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int videoHeight = Math.max(dp(170), Math.min(dp(280), screenWidth * 9 / 16));
        FrameLayout videoFrame = new FrameLayout(this);
        videoFrame.setBackgroundColor(Color.BLACK);
        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setKeepContentOnPlayerReset(true);
        videoFrame.addView(playerView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        overlayView = new StackOverlayView(this);
        videoFrame.addView(overlayView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(videoFrame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, videoHeight));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(false);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(10), dp(12), dp(18));
        scrollView.addView(content);
        root.addView(scrollView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        videoStatus = text("Video not selected. Tap Open Video to choose a local file.", 12, MUTED, false);
        videoStatus.setPadding(dp(4), dp(3), dp(4), dp(8));
        content.addView(videoStatus);

        LinearLayout lineActions = horizontalRow();
        Button editLines = button("Adjust Lines", PANEL);
        editLines.setOnClickListener(v -> {
            boolean editing = !overlayView.isEditMode();
            overlayView.setEditMode(editing);
            editLines.setText(editing ? "Finish Editing" : "Adjust Lines");
            qualityStatus.setText(editing ? "Drag the white/red corner handles to align the overlay. Save Lines when finished." : "Line editing stopped.");
        });
        Button saveLines = button("Save Lines", BLUE);
        saveLines.setOnClickListener(v -> { overlayView.saveCalibration(); toast("Calibration lines saved on this phone."); });
        Button resetLines = button("Reset", PANEL);
        resetLines.setOnClickListener(v -> { overlayView.resetCalibration(); qualityStatus.setText("Overlay reset to example geometry. Adjust it to fit the current video."); });
        lineActions.addView(editLines, weightedButtonParams());
        lineActions.addView(saveLines, weightedButtonParams());
        lineActions.addView(resetLines, weightedButtonParams());
        content.addView(lineActions);

        Button qualityButton = button("Check Current Frame Quality", BLUE);
        qualityButton.setOnClickListener(v -> analyzeFrameQuality());
        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        qlp.topMargin = dp(7);
        content.addView(qualityButton, qlp);
        qualityStatus = text("Frame quality check compares the original frame with an analysis-only grayscale/contrast/sharpen copy. It does not count pieces or guarantee accuracy.", 11, MUTED, false);
        qualityStatus.setPadding(dp(4), dp(7), dp(4), dp(10));
        content.addView(qualityStatus);

        content.addView(sectionTitle("Inventory overview"));
        totalSummary = text("Total: 416 pieces", 15, TEXT, true);
        totalSummary.setBackground(panelBackground());
        totalSummary.setPadding(dp(12), dp(11), dp(12), dp(11));
        content.addView(totalSummary, fullWidthWrap());
        TextView thickness = text(String.format(Locale.US, "Assumed piece thickness: %.2f mm  |  Initial theoretical total: %.2f cm", StackLedger.PIECE_THICKNESS_MM, StackLedger.INITIAL_TOTAL * StackLedger.PIECE_THICKNESS_MM / 10.0), 12, MUTED, false);
        thickness.setPadding(dp(4), dp(7), dp(4), dp(9));
        content.addView(thickness);

        LinearLayout inventoryActions = horizontalRow();
        Button addStack = button("+ New Stack", PANEL);
        addStack.setOnClickListener(v -> { ledger.addStack(); refreshDashboard(); });
        Button transfer = button("Transfer Pieces", BLUE);
        transfer.setOnClickListener(v -> showTransferDialog());
        Button resetInventory = button("Reset Inventory", PANEL);
        resetInventory.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Reset inventory?")
                .setMessage("This will reset the inventory to one Deck 1 containing 416 pieces. Existing history is retained with a reset event.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Reset", (dialog, which) -> { ledger.resetInventory(); refreshDashboard(); })
                .show());
        inventoryActions.addView(addStack, weightedButtonParams());
        inventoryActions.addView(transfer, weightedButtonParams());
        content.addView(inventoryActions);
        LinearLayout resetRow = horizontalRow();
        resetRow.addView(resetInventory, fullWidthWrap());
        content.addView(resetRow);

        stacksContainer = new LinearLayout(this);
        stacksContainer.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams stackParams = fullWidthWrap(); stackParams.topMargin = dp(7);
        content.addView(stacksContainer, stackParams);

        TextView limitation = text("Important: this Step A build provides video playback, adjustable geometry overlay, frame-quality sampling and a local inventory ledger. Automatic one-piece counting and perspective-aware quantity matching are not yet implemented or validated. Unclear changes must not be treated as confirmed counts.", 12, Color.rgb(255, 205, 125), false);
        limitation.setBackground(panelBackground());
        limitation.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams limParams = fullWidthWrap(); limParams.topMargin = dp(9);
        content.addView(limitation, limParams);

        content.addView(sectionTitle("Change history"));
        historyContainer = new LinearLayout(this);
        historyContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(historyContainer, fullWidthWrap());

        root.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(view.getPaddingLeft(), insets.getSystemWindowInsetTop(),
                    view.getPaddingRight(), insets.getSystemWindowInsetBottom());
            return insets.consumeSystemWindowInsets();
        });
        setContentView(root);
    }

    private void refreshDashboard() {
        if (ledger == null || stacksContainer == null || historyContainer == null) return;
        List<StackEntry> stacks = ledger.getStacks();
        int total = ledger.getInventoryTotal();
        if (totalSummary != null) {
            totalSummary.setText("Total tracked: " + total + " / " + StackLedger.INITIAL_TOTAL + " pieces\n" +
                    "Inventory check: " + (total == StackLedger.INITIAL_TOTAL ? "balanced" : "needs review"));
        }
        if (overlayView != null) overlayView.setModelLayerCount(StackLedger.INITIAL_TOTAL);

        stacksContainer.removeAllViews();
        for (StackEntry entry : stacks) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setBackground(panelBackground());
            row.setPadding(dp(11), dp(9), dp(8), dp(9));
            LinearLayout left = new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL);
            left.addView(text(entry.name, 14, TEXT, true));
            left.addView(text(entry.outOfView ? "Hidden / not currently visible" : "Tracked stack", 10, MUTED, false));
            row.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView count = text(String.valueOf(entry.quantity), 22, entry.outOfView ? Color.rgb(255, 195, 80) : TEXT, true);
            row.addView(count);
            LinearLayout.LayoutParams rowParams = fullWidthWrap(); rowParams.bottomMargin = dp(6);
            stacksContainer.addView(row, rowParams);
        }

        historyContainer.removeAllViews();
        for (String item : ledger.getRecentHistory(20)) {
            TextView event = text(item, 12, TEXT, false);
            event.setBackground(panelBackground()); event.setPadding(dp(10), dp(9), dp(10), dp(9));
            LinearLayout.LayoutParams eventParams = fullWidthWrap(); eventParams.bottomMargin = dp(5);
            historyContainer.addView(event, eventParams);
        }
    }

    private void showTransferDialog() {
        List<StackEntry> entries = ledger.getStacks();
        if (entries.size() < 2) { toast("Create another stack first."); return; }
        LinearLayout form = new LinearLayout(this);
        form.setPadding(dp(20), dp(8), dp(20), dp(4));
        form.setOrientation(LinearLayout.VERTICAL);
        form.addView(text("From stack", 13, TEXT, true));
        Spinner sourceSpinner = new Spinner(this);
        form.addView(sourceSpinner, fullWidthWrap());
        form.addView(text("To stack", 13, TEXT, true));
        Spinner destinationSpinner = new Spinner(this);
        form.addView(destinationSpinner, fullWidthWrap());
        form.addView(text("Number of pieces", 13, TEXT, true));
        EditText amountInput = new EditText(this);
        amountInput.setSingleLine(true);
        amountInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        amountInput.setHint("e.g. 10");
        form.addView(amountInput, fullWidthWrap());
        List<String> names = new ArrayList<>();
        for (StackEntry entry : entries) names.add(entry.name + " (" + entry.quantity + ")");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, names);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sourceSpinner.setAdapter(adapter); destinationSpinner.setAdapter(adapter);
        if (entries.size() > 1) destinationSpinner.setSelection(1);

        new AlertDialog.Builder(this)
                .setTitle("Move pieces between stacks")
                .setView(form)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Transfer", (dialog, which) -> {
                    try {
                        StackEntry source = entries.get(sourceSpinner.getSelectedItemPosition());
                        StackEntry destination = entries.get(destinationSpinner.getSelectedItemPosition());
                        int amount = Integer.parseInt(amountInput.getText().toString().trim());
                        boolean ok = ledger.transfer(source.id, destination.id, amount);
                        if (ok) { refreshDashboard(); toast("Transfer saved. Total quantity conserved."); }
                        else toast("Transfer failed: check source, destination and available quantity.");
                    } catch (RuntimeException ex) { toast("Enter a valid positive quantity."); }
                }).show();
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("video/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQUEST_PICK_VIDEO);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_PICK_VIDEO || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (SecurityException ignored) { /* Some document providers grant only temporary access. */ }
        loadVideo(uri, true);
    }

    private void loadVideo(Uri uri, boolean autoplay) {
        try {
            if (player != null) { player.release(); player = null; }
            currentVideoUri = uri;
            player = new ExoPlayer.Builder(this).build();
            playerView.setPlayer(player);
            player.setMediaItem(MediaItem.fromUri(uri));
            player.prepare();
            if (autoplay) player.play();
            String label = uri.getLastPathSegment();
            videoStatus.setText("Selected local video: " + (label == null ? "video file" : label) + "\nNo network upload is performed by this app.");
        } catch (RuntimeException ex) {
            videoStatus.setText("Could not open this video. Try a standard MP4 file. Details: " + ex.getMessage());
        }
    }

    private void analyzeFrameQuality() {
        if (currentVideoUri == null || player == null) {
            qualityStatus.setText("Select a video and pause near a clear frame first.");
            return;
        }
        qualityStatus.setText("Checking frame detail… This runs locally on the phone.");
        final Uri uri = currentVideoUri;
        final long position = player.getCurrentPosition();
        background.execute(() -> {
            try {
                FrameQualityAnalyzer.Result result = FrameQualityAnalyzer.analyze(getApplicationContext(), uri, position);
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    qualityStatus.setText(String.format(Locale.US,
                            "Nearest sync frame to %s · source %d×%d · original edge-detail score %.1f; filtered score %.1f. Noise and sharpening can increase scores without improving true detail; neither score is a count or confidence value.",
                            formatTime(position), result.originalWidth, result.originalHeight, result.originalLaplacianVariance, result.filteredLaplacianVariance));
                });
            } catch (Exception ex) {
                runOnUiThread(() -> qualityStatus.setText("Frame check failed: " + safeMessage(ex)));
            }
        });
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (currentVideoUri != null) outState.putString("video_uri", currentVideoUri.toString());
    }

    @Override protected void onDestroy() {
        if (player != null) { player.release(); player = null; }
        if (ledger != null) ledger.close();
        background.shutdownNow();
        super.onDestroy();
    }

    private String formatTime(long ms) { return String.format(Locale.US, "%02d:%02d", (ms / 60000) % 60, (ms / 1000) % 60); }
    private String safeMessage(Exception ex) { String message = ex.getMessage(); return message == null ? ex.getClass().getSimpleName() : message; }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String value, float sizeSp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value); view.setTextSize(sizeSp); view.setTextColor(color);
        if (bold) view.setTypeface(view.getTypeface(), android.graphics.Typeface.BOLD);
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }

    private Button button(String label, int color) {
        Button button = new Button(this);
        button.setText(label); button.setTextSize(12); button.setAllCaps(false); button.setTextColor(TEXT);
        button.setBackgroundTintList(ColorStateList.valueOf(color));
        button.setMinHeight(dp(42));
        return button;
    }

    private LinearLayout horizontalRow() {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private LinearLayout.LayoutParams weightedButtonParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(44), 1f);
        params.setMargins(dp(2), dp(2), dp(2), dp(2));
        return params;
    }

    private LinearLayout.LayoutParams fullWidthWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private View sectionTitle(String value) {
        TextView title = text(value, 16, TEXT, true);
        title.setPadding(dp(2), dp(12), dp(2), dp(7));
        return title;
    }

    private android.graphics.drawable.Drawable panelBackground() {
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(PANEL); bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.rgb(46, 55, 67));
        return bg;
    }
}
