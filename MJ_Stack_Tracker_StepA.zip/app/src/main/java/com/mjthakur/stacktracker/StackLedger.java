package com.mjthakur.stacktracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Local-only inventory ledger. Transfers conserve the initial quantity. */
public final class StackLedger extends SQLiteOpenHelper {
    private static final String DB_NAME = "mj_stack_tracker.db";
    private static final int DB_VERSION = 1;
    public static final int INITIAL_TOTAL = 416;
    public static final double PIECE_THICKNESS_MM = 0.33;

    public StackLedger(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE stacks (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity >= 0), is_out_of_view INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE history (id INTEGER PRIMARY KEY AUTOINCREMENT, time_ms INTEGER NOT NULL, event_type TEXT NOT NULL, message TEXT NOT NULL)");
        ContentValues deck = new ContentValues();
        deck.put("name", "Deck 1"); deck.put("quantity", INITIAL_TOTAL); deck.put("is_out_of_view", 0);
        db.insertOrThrow("stacks", null, deck);
        ContentValues hidden = new ContentValues();
        hidden.put("name", "Out of View / Unassigned"); hidden.put("quantity", 0); hidden.put("is_out_of_view", 1);
        db.insertOrThrow("stacks", null, hidden);
        insertEvent(db, "INITIALIZED", "Initial model created: 416 pieces; assumed thickness 0.33 mm per piece.");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Keep user data. Any future schema update must add an explicit migration here.
    }

    private static void insertEvent(SQLiteDatabase db, String type, String message) {
        ContentValues values = new ContentValues();
        values.put("time_ms", System.currentTimeMillis()); values.put("event_type", type); values.put("message", message);
        db.insertOrThrow("history", null, values);
    }

    public synchronized List<StackEntry> getStacks() {
        List<StackEntry> result = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id, name, quantity, is_out_of_view FROM stacks ORDER BY is_out_of_view ASC, id ASC", null)) {
            while (c.moveToNext()) result.add(new StackEntry(c.getLong(0), c.getString(1), c.getInt(2), c.getInt(3) == 1));
        }
        return result;
    }

    public synchronized List<String> getRecentHistory(int limit) {
        List<String> result = new ArrayList<>();
        int safeLimit = Math.max(1, Math.min(200, limit));
        try (Cursor c = getReadableDatabase().rawQuery("SELECT time_ms, event_type, message FROM history ORDER BY id DESC LIMIT " + safeLimit, null)) {
            while (c.moveToNext()) {
                String time = DateFormat.getTimeInstance(DateFormat.SHORT, Locale.getDefault()).format(new Date(c.getLong(0)));
                result.add(time + " | " + c.getString(1) + "\n" + c.getString(2));
            }
        }
        return result;
    }

    public synchronized int getInventoryTotal() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT COALESCE(SUM(quantity), 0) FROM stacks", null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    public synchronized long addStack() {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            int number = 1;
            try (Cursor c = db.rawQuery("SELECT COUNT(*) FROM stacks WHERE is_out_of_view = 0", null)) {
                if (c.moveToFirst()) number = c.getInt(0) + 1;
            }
            String name = "Deck " + number;
            ContentValues values = new ContentValues(); values.put("name", name); values.put("quantity", 0); values.put("is_out_of_view", 0);
            long id = db.insertOrThrow("stacks", null, values);
            insertEvent(db, "STACK_CREATED", name + " created with 0 pieces.");
            db.setTransactionSuccessful();
            return id;
        } finally { db.endTransaction(); }
    }

    public synchronized boolean transfer(long sourceId, long destinationId, int amount) {
        if (sourceId == destinationId || amount <= 0) return false;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            StackRecord source = findStack(db, sourceId);
            StackRecord destination = findStack(db, destinationId);
            if (source == null || destination == null || source.quantity < amount) return false;
            ContentValues sourceValues = new ContentValues(); sourceValues.put("quantity", source.quantity - amount);
            db.update("stacks", sourceValues, "id=?", new String[]{String.valueOf(sourceId)});
            ContentValues destinationValues = new ContentValues(); destinationValues.put("quantity", destination.quantity + amount);
            db.update("stacks", destinationValues, "id=?", new String[]{String.valueOf(destinationId)});
            String message = source.name + " -> " + destination.name + ": " + amount + " piece(s) transferred. New counts: " + (source.quantity - amount) + " / " + (destination.quantity + amount) + ".";
            insertEvent(db, "TRANSFER", message);
            db.setTransactionSuccessful();
            return true;
        } finally { db.endTransaction(); }
    }

    public synchronized void resetInventory() {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("stacks", null, null);
            ContentValues deck = new ContentValues(); deck.put("name", "Deck 1"); deck.put("quantity", INITIAL_TOTAL); deck.put("is_out_of_view", 0);
            db.insertOrThrow("stacks", null, deck);
            ContentValues hidden = new ContentValues(); hidden.put("name", "Out of View / Unassigned"); hidden.put("quantity", 0); hidden.put("is_out_of_view", 1);
            db.insertOrThrow("stacks", null, hidden);
            insertEvent(db, "RESET", "Inventory reset to the initial 416-piece model.");
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    private StackRecord findStack(SQLiteDatabase db, long id) {
        try (Cursor c = db.rawQuery("SELECT id, name, quantity FROM stacks WHERE id=?", new String[]{String.valueOf(id)})) {
            if (c.moveToFirst()) return new StackRecord(c.getLong(0), c.getString(1), c.getInt(2));
        }
        return null;
    }

    private static final class StackRecord {
        final long id; final String name; final int quantity;
        StackRecord(long id, String name, int quantity) { this.id = id; this.name = name; this.quantity = quantity; }
    }
}
