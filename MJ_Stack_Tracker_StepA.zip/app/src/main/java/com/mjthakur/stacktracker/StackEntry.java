package com.mjthakur.stacktracker;

public final class StackEntry {
    public final long id;
    public final String name;
    public final int quantity;
    public final boolean outOfView;

    public StackEntry(long id, String name, int quantity, boolean outOfView) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.outOfView = outOfView;
    }
}
