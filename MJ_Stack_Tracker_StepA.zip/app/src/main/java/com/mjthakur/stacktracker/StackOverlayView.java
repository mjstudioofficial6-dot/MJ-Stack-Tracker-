package com.mjthakur.stacktracker;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.view.MotionEvent;
import android.view.View;

/** Adjustable illustrative cuboid overlay. It annotates geometry; it does not claim automatic counting. */
public final class StackOverlayView extends View {
    private static final String PREFS = "overlay_calibration";
    private static final String POINTS_KEY = "normalized_points";
    // Eight normalized corners: front top-left/right, back top-right/left, front bottom-left/right, back bottom-right/left.
    private final float[] points = {
            0.32f, 0.35f, 0.54f, 0.35f, 0.61f, 0.28f, 0.39f, 0.28f,
            0.32f, 0.70f, 0.54f, 0.70f, 0.61f, 0.63f, 0.39f, 0.63f
    };
    private final Paint red = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint blue = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint guide = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SharedPreferences prefs;
    private boolean editMode = false;
    private int activePoint = -1;
    private int modelLayers = StackLedger.INITIAL_TOTAL;

    public StackOverlayView(Context context) {
        super(context);
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        red.setColor(Color.rgb(255, 54, 54)); red.setStyle(Paint.Style.STROKE); red.setStrokeWidth(dp(2.0f));
        blue.setColor(Color.rgb(63, 157, 255)); blue.setStyle(Paint.Style.STROKE); blue.setStrokeWidth(dp(2.0f));
        guide.setColor(Color.argb(120, 88, 177, 255)); guide.setStyle(Paint.Style.STROKE); guide.setStrokeWidth(dp(0.8f));
        labelPaint.setColor(Color.WHITE); labelPaint.setTextSize(dp(11)); labelPaint.setFakeBoldText(true);
        handlePaint.setColor(Color.WHITE); handlePaint.setStyle(Paint.Style.FILL);
        handlePaint.setStrokeWidth(dp(1.4f));
        loadPoints();
        setWillNotDraw(false);
        setClickable(false);
    }

    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }

    public void setEditMode(boolean enabled) { editMode = enabled; setClickable(enabled); invalidate(); }
    public boolean isEditMode() { return editMode; }
    public void setModelLayerCount(int count) { modelLayers = Math.max(0, count); invalidate(); }

    public void saveCalibration() {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < points.length; i++) { if (i > 0) out.append(','); out.append(points[i]); }
        prefs.edit().putString(POINTS_KEY, out.toString()).apply();
    }

    public void resetCalibration() {
        float[] defaults = {0.32f,0.35f,0.54f,0.35f,0.61f,0.28f,0.39f,0.28f,0.32f,0.70f,0.54f,0.70f,0.61f,0.63f,0.39f,0.63f};
        System.arraycopy(defaults, 0, points, 0, points.length);
        saveCalibration(); invalidate();
    }

    private void loadPoints() {
        String stored = prefs.getString(POINTS_KEY, null);
        if (stored == null) return;
        try {
            String[] parts = stored.split(",");
            if (parts.length != points.length) return;
            float[] loaded = new float[points.length];
            for (int i = 0; i < parts.length; i++) loaded[i] = Math.max(0.02f, Math.min(0.98f, Float.parseFloat(parts[i])));
            System.arraycopy(loaded, 0, points, 0, points.length);
        } catch (RuntimeException ignored) { /* Use defaults if saved data is invalid. */ }
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float[][] p = new float[8][2];
        for (int i = 0; i < 8; i++) { p[i][0] = points[i * 2] * w; p[i][1] = points[i * 2 + 1] * h; }

        // Front and side boundaries (red).
        line(canvas, p[0], p[1], red); line(canvas, p[1], p[5], red); line(canvas, p[5], p[4], red); line(canvas, p[4], p[0], red);
        line(canvas, p[1], p[2], red); line(canvas, p[2], p[6], red); line(canvas, p[6], p[5], red);
        line(canvas, p[0], p[3], red); line(canvas, p[3], p[2], blue); line(canvas, p[3], p[7], blue); line(canvas, p[7], p[6], blue);
        line(canvas, p[0], p[1], blue); line(canvas, p[1], p[2], blue); line(canvas, p[2], p[3], blue); line(canvas, p[3], p[0], blue);

        // Render a screen-resolvable subset of guides. The model quantity remains numeric (416 by default);
        // drawing 416 individual strokes into a small video area would alias into a misleading solid band.
        float faceHeight = Math.max(1, p[4][1] - p[0][1]);
        int visibleGuides = Math.max(6, Math.min(28, (int) (faceHeight / dp(5))));
        for (int i = 1; i < visibleGuides; i++) {
            float t = i / (float) visibleGuides;
            float leftX = p[0][0] + (p[4][0] - p[0][0]) * t;
            float leftY = p[0][1] + (p[4][1] - p[0][1]) * t;
            float rightX = p[1][0] + (p[5][0] - p[1][0]) * t;
            float rightY = p[1][1] + (p[5][1] - p[1][1]) * t;
            canvas.drawLine(leftX, leftY, rightX, rightY, guide);
        }

        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG); bg.setColor(Color.argb(170, 0, 0, 0));
        canvas.drawRoundRect(dp(6), dp(6), dp(224), dp(28), dp(5), dp(5), bg);
        canvas.drawText("BASELINE MODEL: " + modelLayers + " layers", dp(12), dp(21), labelPaint);
        if (editMode) {
            for (int i = 0; i < 8; i++) {
                canvas.drawCircle(p[i][0], p[i][1], dp(5), handlePaint);
                canvas.drawCircle(p[i][0], p[i][1], dp(5), red);
            }
        }
    }

    private void line(Canvas canvas, float[] a, float[] b, Paint paint) { canvas.drawLine(a[0], a[1], b[0], b[1], paint); }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (!editMode) return false;
        float x = event.getX(), y = event.getY();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                activePoint = findNearestPoint(x, y);
                return activePoint >= 0;
            case MotionEvent.ACTION_MOVE:
                if (activePoint >= 0) {
                    points[activePoint * 2] = Math.max(0.02f, Math.min(0.98f, x / Math.max(1f, getWidth())));
                    points[activePoint * 2 + 1] = Math.max(0.02f, Math.min(0.98f, y / Math.max(1f, getHeight())));
                    invalidate(); return true;
                }
                return false;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                boolean changed = activePoint >= 0; activePoint = -1;
                if (changed) invalidate();
                return changed;
            default: return true;
        }
    }

    private int findNearestPoint(float x, float y) {
        float bestDistance = dp(30); int best = -1;
        for (int i = 0; i < 8; i++) {
            float dx = x - points[i * 2] * getWidth();
            float dy = y - points[i * 2 + 1] * getHeight();
            float distance = (float) Math.sqrt(dx * dx + dy * dy);
            if (distance < bestDistance) { bestDistance = distance; best = i; }
        }
        return best;
    }
}
