# Architecture

## Current Step A path

`Local video URI -> Media3 player -> adjustable annotation overlay`

`Current playback position -> MediaMetadataRetriever -> downsample -> Laplacian-variance frame-detail score`

`User-confirmed transfer -> SQLite transaction -> stack table + immutable-style event history`

## Components
- `MainActivity`: main screen, video import/playback, controls, inventory UI and history UI.
- `StackOverlayView`: saved normalized corner points, draggable calibration handles, red side/edge lines, blue top outline and screen-resolvable horizontal guides.
- `FrameQualityAnalyzer`: local still-frame extraction and a relative edge-detail metric; does not estimate count.
- `StackLedger`: SQLite data model; transferring pieces between stacks conserves the inventory total.
- `scripts/validate_project.py`: fast structural checks before Gradle build.

## Target automatic vision design

1. Decode sampled frames around stable/clear moments, not every 4K frame indiscriminately.
2. Locate the table plane and a known physical reference; estimate a homography for the table plane.
3. Detect/track the stack cuboid separately from the table plane because its side is above the table and cannot be corrected merely by tabletop homography.
4. Extract side-face ROI and compare original/enhanced gradients over time.
5. Compare observed measurements against candidate stack states and the known inventory constraint.
6. Confirm a change only when it persists over multiple clear frames and is consistent with inventory conservation; otherwise mark it pending.
7. Record event time, stack IDs, before/after quantities, evidence frame references and measured uncertainty locally.

## Important constraints
- A fixed camera does not guarantee constant pixel scale across the table because of perspective.
- A filter may boost noise or create apparent edges; compare results against the original frame.
- 416 logical layers are not necessarily individually resolvable in the encoded video. The actual video must demonstrate adequate visual signal before claiming single-piece accuracy.
- If a stack is occluded, moved off-screen or lifted, the app must not automatically conclude pieces were removed.
