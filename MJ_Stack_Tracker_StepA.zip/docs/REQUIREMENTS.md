# MJ Stack Tracker — Consolidated Requirements

## Fixed input assumptions
- Starting inventory model: 416 pieces.
- Assumed thickness per piece: 0.33 mm; this is a user-provided working assumption, not independently verified physical metrology.
- Initial theoretical thickness: 416 × 0.33 mm = 137.28 mm = 13.728 cm.
- Input: user manually selects a recorded video from the Android device.
- Runtime: on-device/offline; no camera permission, cloud AI, account or runtime network required.
- Scene assumptions: camera likely fixed after initial zoom; table and camera dimensions are approximate until calibrated from a real clip.

## Required user-visible behavior
1. Local video picker and playback controls (play, pause, seek).
2. Video-local overlay with red side/edge outlines and blue top-surface outlines.
3. Adjustable overlay corner points; save/reset calibration on the phone.
4. 416-piece logical baseline model representation. Rendering is limited to screen-resolvable guide lines; drawing 416 separate strokes into a small video area would alias and must not be presented as 416 individually observed edges.
5. Stack records with stable IDs and quantity values.
6. Split/transfer tracking using explicit source stack, destination stack and amount.
7. Out-of-view/unassigned bucket to avoid treating occlusion as a confirmed loss.
8. Local history for every inventory action.
9. Frame quality sampling: compare relative Laplacian variance on the original frame and an analysis-only grayscale/contrast/sharpen copy to assist frame selection. This is not a quantity estimator or calibrated confidence score.
10. Offline local storage; source-code/build network access is separate from runtime.

## Required future capability, not yet implemented in Step A
- Automatic frame-to-frame stack detection and identity tracking.
- Perspective-aware physical height measurement using tabletop and stack-side calibration.
- Automated layer-edge matching and quantity candidate scoring.
- Multi-frame event verification, confidence calibration and false-positive suppression.
- Filtered-frame comparison and original-versus-enhanced consistency checks.
- CSV/JSON export and undo/audit-edit controls.

These are intentionally listed as future implementation items rather than falsely represented as completed.
