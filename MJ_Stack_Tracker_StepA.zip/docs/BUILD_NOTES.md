# Build notes and known limitations

- This build uses Java instead of Kotlin for the first stable scaffold to reduce language/plugin complexity and avoid repeating the previous unresolved-property/class-reference failure pattern.
- The workflow pins JDK 17, Gradle 9.6.0, Android Gradle Plugin 9.4.0, Android SDK platform/build-tools 36, and Media3 1.11.1.
- The source ZIP deliberately omits a Gradle Wrapper JAR. The GitHub Actions workflow installs the pinned Gradle distribution directly via `gradle/actions/setup-gradle@v6`. This avoids shipping an unverified binary wrapper JAR.
- `scripts/validate_project.py` is a structural guard, not a substitute for a real Android compile.
- The local runtime has no Internet permission. Maven/Gradle dependencies are fetched only during the cloud build.
- The overlay initial coordinates are examples. The user must align them with the actual video before using them for annotations.
- `FrameQualityAnalyzer` returns Laplacian variance from a downscaled original frame and a separate grayscale/contrast/sharpen analysis copy. It is affected by noise, high contrast and sharpening, so it must not be presented as an objective probability of correctness.
- The automatic quantity estimator remains a future module because the current conversation has no known-ground-truth clip and exact one-piece visibility is unresolved.
