# Acceptance and validation plan

## Build checks
- [ ] GitHub Actions can resolve the pinned JDK, Android SDK, Gradle and Media3 dependencies.
- [ ] `gradle clean assembleDebug` succeeds.
- [ ] APK artifact is non-empty and installs on the target Android phone.
- [ ] App starts without crash and requests no camera/network permission.

## Current Step A behavior
- [ ] Select an MP4 file through the system document picker.
- [ ] Play, pause and seek without losing the overlay.
- [ ] Drag all overlay corner handles; save; close/reopen app; calibration remains saved.
- [ ] Reset overlay returns it to the example geometry.
- [ ] Frame quality action reports source dimensions and a relative edge-detail score at the current playback position.
- [ ] Create a new stack; transfer a known amount between two stacks.
- [ ] Sum of all stack quantities (including Out of View / Unassigned) remains 416 after transfers.
- [ ] Restart the app and verify inventory and history persist.
- [ ] Confirm no video or event is uploaded by the app.

## Controlled data needed before automatic-count claims
Use a known physical test stack and independently record each change. Do not use a clip whose removed piece count is unknown as ground truth.

Test events: 0, 1, 5, 10 and 20 pieces removed; transfer between two stacks; split/merge; move stack closer/farther on table; rotate stack; hand occlusion; full occlusion; off-screen movement; blur/noise/compression variants.

Measure exact-count accuracy, mean absolute count error, false change events, missed events, time to update, and confidence calibration. Compare original frames against enhanced frames. Only enable automated quantity updates after these tests demonstrate sufficient accuracy.
