package com.mj.stacktracker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Conservative temporal association. IDs are visual component IDs; when the initial master is locked,
 * all candidate components receive a child ID linked to the stable MASTER-001 lineage.
 */
public final class TrackManager {
    public static final class TrackedBox {
        public final String id;
        public final float left,top,right,bottom,confidence;
        public final boolean matchedFromPrevious;
        TrackedBox(String id,float l,float t,float r,float b,float c,boolean matched){this.id=id;left=l;top=t;right=r;bottom=b;confidence=c;matchedFromPrevious=matched;}
    }
    public static final class Event {
        public final String type,trackId,details;
        public final float confidence;
        Event(String type,String id,float confidence,String details){this.type=type;trackId=id;this.confidence=confidence;this.details=details;}
    }
    public static final class Update {
        public final List<TrackedBox> visible;
        public final List<Event> events;
        public final float frameConfidence;
        Update(List<TrackedBox> visible,List<Event> events,float confidence){this.visible=visible;this.events=events;frameConfidence=confidence;}
    }

    private static final int MAX_MISSED_FRAMES=12;
    private static final int MIN_HITS_TO_CONFIRM=3;
    private final List<Track> tracks=new ArrayList<>();
    private final boolean lockedMasterLineage;
    private int nextId=1;

    public TrackManager(){this(false);}
    public TrackManager(boolean lockedMasterLineage){this.lockedMasterLineage=lockedMasterLineage;}

    public Update update(List<DetectionCandidate> detections){
        List<Event> events=new ArrayList<>();
        List<Track> before=new ArrayList<>();
        for(Track t:tracks)before.add(t.copy());
        boolean[] usedTrack=new boolean[tracks.size()];
        List<TrackedBox> visible=new ArrayList<>();
        List<DetectionCandidate> ordered=new ArrayList<>(detections==null?Collections.emptyList():detections);
        ordered.sort(Comparator.comparingDouble((DetectionCandidate c)->c.detectorScore).reversed());
        int matchedCount=0;

        for(DetectionCandidate d:ordered){
            int bestIndex=-1;float bestScore=0f;
            for(int i=0;i<tracks.size();i++){
                if(usedTrack[i])continue;
                Track t=tracks.get(i);if(t.missed>MAX_MISSED_FRAMES)continue;
                float score=associationScore(d,t);
                if(score>bestScore){bestScore=score;bestIndex=i;}
            }
            Track chosen;boolean matched=bestIndex>=0&&bestScore>=0.30f;
            if(matched){
                usedTrack[bestIndex]=true;chosen=tracks.get(bestIndex);matchedCount++;
                chosen.left=0.40f*chosen.left+0.60f*d.left;chosen.top=0.40f*chosen.top+0.60f*d.top;
                chosen.right=0.40f*chosen.right+0.60f*d.right;chosen.bottom=0.40f*chosen.bottom+0.60f*d.bottom;
                chosen.confidence=clamp(0.75f*d.detectorScore+0.25f*bestScore*100f);
                boolean hadGap=chosen.missed>0;chosen.missed=0;chosen.hits=hadGap?1:chosen.hits+1;
            }else{
                Track possibleParent=findSplitParent(d,before);
                chosen=new Track();chosen.id=makeId(nextId++);chosen.left=d.left;chosen.top=d.top;chosen.right=d.right;chosen.bottom=d.bottom;
                chosen.confidence=clamp(d.detectorScore*0.68f);chosen.missed=0;chosen.hits=1;tracks.add(chosen);
                usedTrack=java.util.Arrays.copyOf(usedTrack,tracks.size());usedTrack[tracks.size()-1]=true;
                if(possibleParent!=null){
                    events.add(new Event("POSSIBLE_SPLIT",chosen.id,chosen.confidence,
                            "New candidate is spatially near component "+possibleParent.id+" in the MASTER-001 lineage. Pending human review; piece counts and ledger were not changed."));
                }
            }
            if(!chosen.confirmed&&chosen.hits>=MIN_HITS_TO_CONFIRM){
                chosen.confirmed=true;
                events.add(new Event("CANDIDATE_CONFIRMED",chosen.id,chosen.confidence,
                        "Candidate persisted across three processed frames. This confirms a visual track only, not a verified physical stack."));
            }
            if(chosen.confirmed){
                String visibleId=lockedMasterLineage?chosen.id:chosen.id;
                visible.add(new TrackedBox(visibleId,chosen.left,chosen.top,chosen.right,chosen.bottom,chosen.confidence,matched));
            }
        }

        for(int i=0;i<tracks.size();i++){
            Track t=tracks.get(i);if(i>=usedTrack.length||!usedTrack[i]){
                t.missed++;
                if(t.confirmed&&t.missed==MAX_MISSED_FRAMES+1){
                    events.add(new Event("TRACK_NOT_VISIBLE",t.id,t.confidence,
                            "Candidate absent for multiple processed frames. It may be occluded or out of view; it is not automatically marked removed."));
                }
            }
        }
        for(int i=tracks.size()-1;i>=0;i--){Track t=tracks.get(i);if((!t.confirmed&&t.missed>3)||(t.confirmed&&t.missed>MAX_MISSED_FRAMES+30))tracks.remove(i);}
        float average=0f;for(TrackedBox b:visible)average+=b.confidence;average=visible.isEmpty()?0f:average/visible.size();
        float continuity=ordered.isEmpty()?0f:(float)matchedCount/ordered.size();
        float frameConfidence=visible.isEmpty()?0f:clamp(average*(0.76f+0.24f*continuity));
        return new Update(Collections.unmodifiableList(visible),events,frameConfidence);
    }

    public void reset(){tracks.clear();nextId=1;}
    private String makeId(int number){return lockedMasterLineage?String.format(Locale.US,"M01-P%02d",number):String.format(Locale.US,"S%02d",number);}

    private Track findSplitParent(DetectionCandidate d,List<Track> previous){
        Track best=null;float bestDistance=Float.MAX_VALUE;float cx=d.centerX(),cy=d.centerY();
        for(Track t:previous){
            if(!t.confirmed||t.missed>2)continue;
            float expand=Math.max(0.025f,Math.max(t.right-t.left,t.bottom-t.top)*0.25f);
            boolean near=cx>=t.left-expand&&cx<=t.right+expand&&cy>=t.top-expand&&cy<=t.bottom+expand;
            float score=iou(d.left,d.top,d.right,d.bottom,t.left,t.top,t.right,t.bottom);
            float dist=(float)Math.hypot(cx-(t.left+t.right)*0.5f,cy-(t.top+t.bottom)*0.5f);
            if((near||score>0.05f)&&dist<bestDistance){best=t;bestDistance=dist;}
        }
        return best;
    }
    private float associationScore(DetectionCandidate d,Track t){
        float overlap=iou(d.left,d.top,d.right,d.bottom,t.left,t.top,t.right,t.bottom);
        float dx=d.centerX()-(t.left+t.right)*0.5f,dy=d.centerY()-(t.top+t.bottom)*0.5f;
        float distance=(float)Math.sqrt(dx*dx+dy*dy);float dw=Math.max(d.width(),t.right-t.left),dh=Math.max(d.height(),t.bottom-t.top);
        float gate=Math.max(0.025f,0.75f*Math.max(dw,dh));
        if(distance>gate*2.5f&&overlap<0.05f)return 0f;
        float distanceScore=Math.max(0f,1f-distance/(gate*2.5f));
        float a1=Math.max(1e-5f,d.area()),a2=Math.max(1e-5f,(t.right-t.left)*(t.bottom-t.top));float ratio=Math.max(a1,a2)/Math.min(a1,a2);
        float sizeScore=ratio>5.0f?0.0f:1f-(ratio-1f)/5f;
        return 0.58f*overlap+0.30f*distanceScore+0.12f*sizeScore;
    }
    private float iou(float al,float at,float ar,float ab,float bl,float bt,float br,float bb){
        float l=Math.max(al,bl),t=Math.max(at,bt),r=Math.min(ar,br),b=Math.min(ab,bb);
        float inter=Math.max(0f,r-l)*Math.max(0f,b-t);float aa=Math.max(0f,ar-al)*Math.max(0f,ab-at),ba=Math.max(0f,br-bl)*Math.max(0f,bb-bt);
        float union=aa+ba-inter;return union<=0f?0f:inter/union;
    }
    private float clamp(float v){return Math.max(0f,Math.min(100f,v));}

    private static final class Track{
        String id;float left,top,right,bottom,confidence;int missed,hits;boolean confirmed;
        Track copy(){Track c=new Track();c.id=id;c.left=left;c.top=top;c.right=right;c.bottom=bottom;c.confidence=confidence;c.missed=missed;c.hits=hits;c.confirmed=confirmed;return c;}
    }
}
