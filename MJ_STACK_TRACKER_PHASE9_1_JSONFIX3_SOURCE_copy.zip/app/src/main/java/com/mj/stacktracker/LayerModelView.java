package com.mj.stacktracker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

import java.util.Locale;

/** Schematic digital clone: conceptual layers only, not recovered physical 3D geometry. */
public final class LayerModelView extends View {
    private final Paint facePaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sidePaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint topPaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private int layers=416;
    private double thicknessMm=0.33;
    private float tiltDegrees=0f;

    public LayerModelView(Context context){super(context);setLayerType(View.LAYER_TYPE_SOFTWARE,null);facePaint.setColor(0xFFF4F6F8);sidePaint.setColor(0xFFD9DEE5);topPaint.setColor(0xFFFFF7E0);linePaint.setColor(0xFF43536A);linePaint.setStrokeWidth(dp(0.7f));textPaint.setColor(0xFF5F6368);textPaint.setTextSize(dp(10));}
    public void setModel(int layerCount,double pieceThicknessMm,float tilt){layers=Math.max(1,Math.min(5000,layerCount));thicknessMm=pieceThicknessMm>0?pieceThicknessMm:0.33;tiltDegrees=Math.max(0,Math.min(60,tilt));invalidate();}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);canvas.drawColor(0xFFF8F9FA);
        float w=getWidth(),h=getHeight();if(w<20||h<20)return;
        float bodyW=w*0.55f,bodyH=h*0.70f,depth=Math.min(w*0.12f,dp(26));
        float tilt=(float)Math.sin(Math.toRadians(tiltDegrees))*bodyH*0.14f;
        float left=(w-bodyW-depth)*0.5f, bottom=h*0.84f, top=bottom-bodyH;
        Path front=new Path();front.moveTo(left+tilt,top);front.lineTo(left+bodyW+tilt,top);front.lineTo(left+bodyW,bottom);front.lineTo(left,bottom);front.close();canvas.drawPath(front,facePaint);
        Path side=new Path();side.moveTo(left+bodyW+tilt,top);side.lineTo(left+bodyW+depth+tilt*0.45f,top-depth*0.55f);side.lineTo(left+bodyW+depth,bottom-depth*0.55f);side.lineTo(left+bodyW,bottom);side.close();canvas.drawPath(side,sidePaint);
        Path topFace=new Path();topFace.moveTo(left+tilt,top);topFace.lineTo(left+bodyW+tilt,top);topFace.lineTo(left+bodyW+depth+tilt*0.45f,top-depth*0.55f);topFace.lineTo(left+depth+tilt*0.45f,top-depth*0.55f);topFace.close();canvas.drawPath(topFace,topPaint);
        // These are illustrative digital layer lines. Their on-screen spacing is not a physical scale.
        for(int i=1;i<layers;i++){
            float f=i/(float)layers;float y=bottom-f*bodyH;float shear=tilt*(1f-f);
            canvas.drawLine(left+shear,y,left+bodyW+shear,y,linePaint);
        }
        String nominal=String.format(Locale.US,"MASTER-001 • %d conceptual layers • %.2f mm each • nominal %.2f mm",layers,thicknessMm,layers*thicknessMm);
        canvas.drawText(nominal,dp(8),dp(15),textPaint);
        canvas.drawText(String.format(Locale.US,"Illustrative model • manual display tilt %.0f° • not automatic 3D measurement",tiltDegrees),dp(8),h-dp(5),textPaint);
    }
    private float dp(float x){return x*getResources().getDisplayMetrics().density;}
}
