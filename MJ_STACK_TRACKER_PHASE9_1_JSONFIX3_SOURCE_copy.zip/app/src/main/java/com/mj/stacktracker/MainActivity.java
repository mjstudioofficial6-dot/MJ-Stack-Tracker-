package com.mj.stacktracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Insets;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.HorizontalScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.VideoSize;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.opencv.android.OpenCVLoader;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * MJ Stack Tracker integrated Phase 9 candidate.
 * It preserves the working video/history foundation while adding a locked master lineage,
 * conservative inventory ledger, manual calibration, review/export, and a conceptual layer model.
 * Classical OpenCV proposals do not constitute verified semantic stack recognition.
 */
public final class MainActivity extends Activity {
    private static final int REQUEST_VIDEO=1001, REQUEST_EXPORT=1002;
    private final Handler mainHandler=new Handler(Looper.getMainLooper());
    private ExoPlayer player;
    private PlayerView playerView;
    private ZoomableVideoViewport videoViewport;
    private android.widget.FrameLayout videoContent;
    private HorizontalScrollView pageScroller;
    private LinearLayout pageStrip;
    private final List<View> panelViews = new ArrayList<>();
    private final List<TextView> panelTabs = new ArrayList<>();
    private int panelWidthPx = 0;
    private int activePanelIndex = 1;
    private FrameOverlayView frameOverlay;
    private LayerModelView layerModelView;
    private TextView statusText,progressText,historyHeading,scaleText,workAreaText,masterText,ledgerText,calibrationText,tiltText;
    private LinearLayout historyRows,eventRows;
    private EditText initialCountInput,thicknessInput,historySearch;
    private LocalHistoryDb historyDb;
    private FrameDetector frameDetector;
    private Uri selectedUri;
    private volatile long activeSessionId=-1;
    private volatile boolean analysisRunning;
    private final AtomicBoolean stopAnalysis=new AtomicBoolean(false);
    private Thread analysisThread;
    private int sourceWidth=16,sourceHeight=9;
    private long lastOverlayTimestamp=-1;
    private long pendingMasterLockTimestampMs=0,masterLockTimestampMs=0;
    private String exportFormat="json";
    private boolean openCvReady,masterLocked;
    private float[] currentWorkArea,currentMasterBox;
    private double tablePixelsPerMm=Double.NaN,sidePixelsPerMm=Double.NaN;
    private float manualTiltDegrees=0f;
    private StackLedger ledger=new StackLedger(416);
    private SharedPreferences preferences;

    private final Runnable overlayPoller=new Runnable(){@Override public void run(){try{updateOverlayForPlaybackPosition();}catch(Exception ignored){}mainHandler.postDelayed(this,300L);}};

    @Override protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        historyDb=new LocalHistoryDb(this);
        preferences=getSharedPreferences("mj_stack_tracker_phase9",MODE_PRIVATE);
        historyDb.markIncompleteSessionsInterrupted();
        try{openCvReady=OpenCVLoader.initLocal();}catch(Throwable e){openCvReady=false;}
        frameDetector=new FrameDetector();
        buildUi();refreshHistory();updateLedgerUi();updateModelUi();updateCalibrationUi();
        if(!openCvReady)statusText.setText("OpenCV did not load. Video playback/history remain available; frame analysis is disabled.");
    }


    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        root.setPadding(dp(8), dp(2), dp(8), dp(8));
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int top, bottom;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars()
                        | WindowInsets.Type.displayCutout());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            view.setPadding(dp(8), top + dp(2), dp(8), bottom + dp(8));
            return insets;
        });

        TextView title = label("MJ Stack Tracker — Integrated Phase 9.1");
        title.setTextSize(18);
        title.setTextColor(0xFF202124);
        title.setGravity(Gravity.CENTER);
        title.setPadding(dp(6), dp(5), dp(6), dp(5));
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(36)));

        // The video viewport is a fixed sibling of the lower panels, never inside a ScrollView.
        int availableScreenWidth = Math.max(dp(280),
                getResources().getDisplayMetrics().widthPixels - dp(16));
        int videoHeight = Math.min(dp(260), Math.round(availableScreenWidth * 9f / 16f));
        videoViewport = new ZoomableVideoViewport(this);
        videoViewport.setBackgroundColor(Color.BLACK);
        videoViewport.setClipChildren(true);
        videoViewport.setClipToPadding(true);
        videoContent = new android.widget.FrameLayout(this);
        videoContent.setBackgroundColor(Color.BLACK);
        videoContent.setPivotX(0f);
        videoContent.setPivotY(0f);

        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerView.setBackgroundColor(Color.BLACK);
        videoContent.addView(playerView, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        frameOverlay = new FrameOverlayView(this);
        frameOverlay.setOnWorkAreaSelectedListener((l, t, r, b) -> {
            videoViewport.setSelectionMode(false);
            currentWorkArea = new float[]{l, t, r, b};
            if (selectedUri != null) saveWorkArea(selectedUri, currentWorkArea);
            workAreaText.setText(areaText("Saved", currentWorkArea));
            statusText.setText("Work area saved. Detection is limited to this movement region.");
            toast("Work area saved.");
        });
        frameOverlay.setOnMasterStackSelectedListener((l, t, r, b) -> {
            videoViewport.setSelectionMode(false);
            int count = parseInt(initialCountInput.getText().toString(), 416);
            double thick = parseDouble(thicknessInput.getText().toString(), 0.33);
            if (count <= 0 || !Double.isFinite(thick) || thick <= 0) {
                Toast.makeText(this, "Enter a valid starting piece count and thickness.",
                        Toast.LENGTH_LONG).show();
                return;
            }
            currentMasterBox = new float[]{l, t, r, b};
            masterLocked = true;
            masterLockTimestampMs = pendingMasterLockTimestampMs;
            ledger.reset(count);
            saveMaster(selectedUri, currentMasterBox, count, thick, masterLockTimestampMs);
            saveLedger();
            frameOverlay.setMasterBox(l, t, r, b, count);
            updateMasterUi();
            updateLedgerUi();
            updateModelUi();
            statusText.setText("MASTER-001 locked at " + formatMs(masterLockTimestampMs)
                    + ". Analysis starts from this video timestamp.");
            Toast.makeText(this, "Initial stack locked as MASTER-001.",
                    Toast.LENGTH_LONG).show();
        });
        frameOverlay.setOnCalibrationLineSelectedListener((x1, y1, x2, y2, side) -> {
            videoViewport.setSelectionMode(false);
            promptCalibration(side, x1, y1, x2, y2);
        });
        videoContent.addView(frameOverlay, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        videoViewport.setVideoContent(videoContent);
        root.addView(videoViewport, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, videoHeight));

        // Fixed panel tabs; swiping is horizontal. Vertical scrolling, if needed, is confined
        // inside the selected lower panel, so the video itself never moves off-screen.
        LinearLayout panelTabsRow = new LinearLayout(this);
        panelTabsRow.setOrientation(LinearLayout.HORIZONTAL);
        panelTabsRow.setGravity(Gravity.CENTER);
        panelTabsRow.setPadding(0, dp(3), 0, dp(3));
        root.addView(panelTabsRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));

        pageScroller = new HorizontalScrollView(this);
        pageScroller.setHorizontalScrollBarEnabled(false);
        pageScroller.setVerticalScrollBarEnabled(false);
        pageScroller.setFillViewport(true);
        pageScroller.setSmoothScrollingEnabled(true);
        pageScroller.setOverScrollMode(View.OVER_SCROLL_NEVER);
        pageStrip = new LinearLayout(this);
        pageStrip.setOrientation(LinearLayout.HORIZONTAL);
        panelViews.clear();
        panelTabs.clear();

        final int panelWidth = availableScreenWidth;
        PanelPage modelPage = createPanelPage("MODEL & INVENTORY");
        PanelPage videoPage = createPanelPage("VIDEO & ANALYSIS");
        PanelPage historyPage = createPanelPage("HISTORY & EXPORT");

        panelViews.add(modelPage.scroll);
        panelViews.add(videoPage.scroll);
        panelViews.add(historyPage.scroll);
        for (View panel : panelViews) {
            pageStrip.addView(panel, new LinearLayout.LayoutParams(
                    panelWidth, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        pageScroller.addView(pageStrip, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pageScroller.setOnScrollChangeListener((v, scrollX, scrollY, oldScrollX, oldScrollY) -> {
            mainHandler.removeCallbacks(panelSnapRunnable);
            mainHandler.postDelayed(panelSnapRunnable, 140L);
        });
        root.addView(pageScroller, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView modelTab = createPanelTab("MODEL", 0);
        TextView videoTab = createPanelTab("VIDEO / ANALYSIS", 1);
        TextView historyTab = createPanelTab("HISTORY", 2);
        for (TextView tab : new TextView[]{modelTab, videoTab, historyTab}) {
            LinearLayout.LayoutParams tabLp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.MATCH_PARENT, 1f);
            tabLp.setMargins(dp(2), 0, dp(2), 0);
            panelTabsRow.addView(tab, tabLp);
            panelTabs.add(tab);
        }

        // LEFT PANEL: everything that describes or changes the model/inventory lives here.
        LinearLayout model = modelPage.content;
        addPanelHint(model, "Draw selections on the fixed video above. Pinch with two fingers to zoom first.");
        LinearLayout areaRow = row(model);
        addButton(areaRow, "MARK WORK AREA", this::beginWorkAreaSelection);
        addButton(areaRow, "RESET AREA", this::resetWorkArea);
        addPanelNote(model, "WORK AREA: draw the outer boundary of every place the stack or its parts may move. Exclude decorations and unrelated objects.");
        workAreaText = label("WORK AREA: NOT SET. Mark the full movement region and exclude unrelated objects.");
        workAreaText.setTextColor(0xFF075985);
        model.addView(workAreaText);

        LinearLayout masterRow = row(model);
        addButton(masterRow, "LOCK INITIAL STACK", this::beginMasterSelection);
        addButton(masterRow, "RESET MASTER", this::resetMaster);
        addPanelNote(model, "MASTER LOCK: pause while the full original stack is intact, set the known count/thickness, then draw around the whole stack. Analysis starts from that timestamp.");
        masterText = label("MASTER-001 NOT LOCKED. Pause on the intact original stack, enter its count, then draw around it.");
        masterText.setTextColor(0xFF8A5200);
        model.addView(masterText);

        LinearLayout configRow = row(model);
        configRow.addView(label("Initial pieces"),
                new LinearLayout.LayoutParams(0, dp(44), 0.8f));
        initialCountInput = numberInput("416", false);
        configRow.addView(initialCountInput, new LinearLayout.LayoutParams(0, dp(44), 0.65f));
        configRow.addView(label("Piece thickness (mm)"),
                new LinearLayout.LayoutParams(0, dp(44), 1.2f));
        thicknessInput = numberInput("0.33", true);
        configRow.addView(thicknessInput, new LinearLayout.LayoutParams(0, dp(44), 0.7f));

        ledgerText = label("Inventory conservation has not been initialized.");
        ledgerText.setTextColor(0xFF245A35);
        model.addView(ledgerText);
        TextView ledgerNote = label(
                "Rule: initial + added = visible + occluded + out-of-view + removed + unassigned. "
                + "Image detections never change piece totals automatically.");
        ledgerNote.setTextSize(11);
        ledgerNote.setTextColor(0xFF5F6368);
        model.addView(ledgerNote);

        addPanelSection(model, "CALIBRATION");
        LinearLayout calRow = row(model);
        addButton(calRow, "CALIBRATE TABLE PLANE", () -> beginCalibration(false));
        addButton(calRow, "CALIBRATE STACK SIDE", () -> beginCalibration(true));
        addPanelNote(model, "TABLE PLANE = a known length lying on the table. STACK SIDE = a known side/height length. Draw the line, then enter its real length in mm.");
        calibrationText = label("Table plane and stack side are calibrated separately.");
        calibrationText.setTextColor(0xFF5F6368);
        model.addView(calibrationText);

        addPanelSection(model, "416-LAYER MODEL (SCHEMATIC)");
        layerModelView = new LayerModelView(this);
        model.addView(layerModelView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(132)));
        tiltText = label("Tilt is illustrative only; automatic 3D pose is not verified.");
        model.addView(tiltText);
        SeekBar tiltSeek = new SeekBar(this);
        tiltSeek.setMax(60);
        tiltSeek.setProgress(0);
        model.addView(tiltSeek, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));
        tiltSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                manualTiltDegrees = progress;
                updateModelUi();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        addPanelSection(model, "INVENTORY / LINEAGE ACTIONS");
        LinearLayout eventRow1 = row(model);
        addButton(eventRow1, "REGISTER SPLIT", this::registerSplit);
        addButton(eventRow1, "REGISTER MERGE", this::registerMerge);
        addPanelNote(model, "SPLIT / MERGE: record how visual child groups separate or join under MASTER-001. These buttons do not infer or invent each child’s piece count.");
        LinearLayout eventRow2 = row(model);
        addButton(eventRow2, "MARK OCCLUDED", () -> changeVisibleBucket("OCCLUDED"));
        addButton(eventRow2, "MARK OUT OF VIEW", () -> changeVisibleBucket("OUT_OF_VIEW"));
        addPanelNote(model, "OCCLUDED = hidden behind a hand/object. OUT OF VIEW = left the camera/work area. Neither status automatically means the pieces were removed.");
        LinearLayout eventRow3 = row(model);
        addButton(eventRow3, "CONFIRM REMOVED", this::confirmRemoved);
        addButton(eventRow3, "ADD PIECES", this::addPieces);
        addPanelNote(model, "CONFIRM REMOVED only when pieces are known to have left the inventory. ADD PIECES records known additions.");
        LinearLayout eventRow4 = row(model);
        addButton(eventRow4, "RETURN TO VIEW", this::returnToView);
        addButton(eventRow4, "ALLOCATE UNKNOWN", this::allocateUnknown);
        addPanelNote(model, "RETURN TO VIEW moves known hidden/out-of-view pieces back to visible. ALLOCATE UNKNOWN assigns unallocated pieces to a chosen bucket.");
        LinearLayout eventRow5 = row(model);
        addButton(eventRow5, "UNDO LEDGER CHANGE", this::undoLedger);
        addPanelNote(model, "UNDO LEDGER CHANGE reverses the last supported manual inventory update.");
        TextView modelLimits = label(
                "M01-Pxx are visual child IDs, not confirmed piece counts. Split/merge changes need review. "
                + "The 416 lines are conceptual, not proof that every physical layer is visible.");
        modelLimits.setTextSize(11);
        modelLimits.setTextColor(0xFF5F6368);
        model.addView(modelLimits);

        // MIDDLE PANEL: selecting and controlling the recorded video is intentionally here.
        LinearLayout videoPanel = videoPage.content;
        addPanelHint(videoPanel, "The video stays pinned above. Swipe left/right to change panels. "
                + "Pinch with two fingers on the video to zoom and pan; then draw a rectangle from MODEL.");
        LinearLayout videoRow1 = row(videoPanel);
        addButton(videoRow1, "SELECT VIDEO", this::openVideoPicker);
        addButton(videoRow1, "ANALYZE FRAMES", this::startAnalysis);
        addPanelNote(videoPanel, "SELECT VIDEO opens a saved video from the phone. ANALYZE FRAMES starts local processing after the work area and MASTER-001 are set.");
        LinearLayout videoRow2 = row(videoPanel);
        addButton(videoRow2, "STOP ANALYSIS", this::stopAnalysis);
        addButton(videoRow2, "CLEAR VIDEO", this::clearVideo);
        LinearLayout videoRow3 = row(videoPanel);
        addButton(videoRow3, "RESET VIDEO ZOOM", this::resetVideoZoom);
        TextView zoomNote = label("Zoom range 1×–5×. Two-finger pinch zooms; moving both fingers pans. "
                + "Reset zoom before re-calibrating if you change the framing.");
        zoomNote.setTextColor(0xFF345B75);
        videoPanel.addView(zoomNote);
        statusText = label("Select a recorded video from this phone. The video remains visible while you use the panels below.");
        statusText.setTextColor(0xFF202124);
        videoPanel.addView(statusText);
        progressText = label("Analysis: not started");
        videoPanel.addView(progressText);
        scaleText = label("Measurement: no calibrated mm dimensions or verified 3D pose yet.");
        videoPanel.addView(scaleText);
        TextView confidenceNote = label(
                "Tracking confidence is a heuristic score, not measured accuracy. Ambiguous events remain pending. "
                + "Automatic exact piece counts are not claimed.");
        confidenceNote.setTextColor(0xFF8B3A00);
        confidenceNote.setTextSize(12);
        videoPanel.addView(confidenceNote);

        // RIGHT PANEL: history review and both export formats live together.
        LinearLayout history = historyPage.content;
        historyHeading = label("Saved analysis history (local database)");
        historyHeading.setTextSize(16);
        historyHeading.setTextColor(0xFF202124);
        history.addView(historyHeading);
        historySearch = new EditText(this);
        historySearch.setSingleLine(true);
        historySearch.setHint("Search by video name, status or ID");
        historySearch.setTextSize(13);
        history.addView(historySearch, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
        historySearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                refreshHistory();
            }
            @Override public void afterTextChanged(Editable e) { }
        });
        LinearLayout exportRow = row(history);
        addButton(exportRow, "EXPORT JSON", () -> startExport("json"));
        addButton(exportRow, "EXPORT CSV", () -> startExport("csv"));
        addPanelNote(history, "EXPORT JSON keeps structured values; EXPORT CSV opens as a table. Choose a local destination in the save dialog.");
        historyRows = new LinearLayout(this);
        historyRows.setOrientation(LinearLayout.VERTICAL);
        history.addView(historyRows);
        addPanelSection(history, "CANDIDATE EVENTS");
        TextView eventsHint = label("Tap an event to open its timestamp, confirm/reject it, or delete the record.");
        history.addView(eventsHint);
        eventRows = new LinearLayout(this);
        eventRows.setOrientation(LinearLayout.VERTICAL);
        history.addView(eventRows);
        TextView historyLimits = label(
                "History is stored locally on this phone. Export writes a file that you choose. "
                + "Confidence is heuristic; it is not a measured accuracy percentage.");
        historyLimits.setTextSize(11);
        historyLimits.setTextColor(0xFF5F6368);
        history.addView(historyLimits);

        setContentView(root);
        panelWidthPx = panelWidth;
        selectPanelTabs(1);
        pageScroller.post(() -> {
            int measured = pageScroller.getWidth();
            if (measured > 0 && measured != panelWidthPx) {
                panelWidthPx = measured;
                for (View panel : panelViews) {
                    panel.setLayoutParams(new LinearLayout.LayoutParams(
                            panelWidthPx, ViewGroup.LayoutParams.MATCH_PARENT));
                }
            }
            pageScroller.scrollTo(panelWidthPx, 0); // open on the middle video/analysis panel
            selectPanelTabs(1);
        });
    }

    private PanelPage createPanelPage(String heading) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundColor(Color.WHITE);
        content.setPadding(dp(3), dp(2), dp(3), dp(14));
        scroll.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView headingView = label(heading);
        headingView.setTextSize(16);
        headingView.setTextColor(0xFF202124);
        headingView.setPadding(dp(8), dp(5), dp(8), dp(5));
        content.addView(headingView);
        return new PanelPage(scroll, content);
    }

    private void addPanelHint(LinearLayout target, String text) {
        TextView hint = label(text);
        hint.setTextSize(12);
        hint.setTextColor(0xFF345B75);
        hint.setBackgroundColor(0xFFF0F7FB);
        hint.setPadding(dp(8), dp(8), dp(8), dp(8));
        target.addView(hint, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void addPanelNote(LinearLayout target, String text) {
        TextView note = label(text);
        note.setTextSize(11);
        note.setTextColor(0xFF5F6368);
        note.setPadding(dp(8), dp(1), dp(8), dp(5));
        target.addView(note, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void addPanelSection(LinearLayout target, String text) {
        TextView section = label(text);
        section.setTextSize(13);
        section.setTextColor(0xFF374151);
        section.setPadding(dp(8), dp(8), dp(8), dp(3));
        section.setTypeface(null, android.graphics.Typeface.BOLD);
        target.addView(section);
    }

    private TextView createPanelTab(String text, int panelIndex) {
        TextView tab = new TextView(this);
        tab.setText(text);
        tab.setTextSize(11);
        tab.setGravity(Gravity.CENTER);
        tab.setTextColor(0xFF374151);
        tab.setPadding(dp(3), dp(3), dp(3), dp(3));
        tab.setOnClickListener(v -> navigateToPanel(panelIndex));
        return tab;
    }

    private void navigateToPanel(int panelIndex) {
        if (panelIndex < 0 || panelIndex >= panelViews.size()) return;
        activePanelIndex = panelIndex;
        selectPanelTabs(panelIndex);
        if (pageScroller != null && panelWidthPx > 0) {
            pageScroller.smoothScrollTo(panelIndex * panelWidthPx, 0);
        }
    }

    private void selectPanelTabs(int panelIndex) {
        activePanelIndex = panelIndex;
        for (int i = 0; i < panelTabs.size(); i++) {
            TextView tab = panelTabs.get(i);
            boolean selected = i == panelIndex;
            tab.setBackgroundColor(selected ? 0xFFDCEEF9 : 0xFFF3F4F6);
            tab.setTextColor(selected ? 0xFF075985 : 0xFF4B5563);
            tab.setTypeface(null, selected ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        }
    }

    private final class PanelPage {
        final ScrollView scroll;
        final LinearLayout content;
        PanelPage(ScrollView scroll, LinearLayout content) {
            this.scroll = scroll;
            this.content = content;
        }
    }

    private final Runnable panelSnapRunnable = new Runnable() {
        @Override public void run() {
            if (pageScroller == null || panelWidthPx <= 0) return;
            int index = Math.round(pageScroller.getScrollX() / (float) panelWidthPx);
            index = Math.max(0, Math.min(2, index));
            int target = index * panelWidthPx;
            selectPanelTabs(index);
            if (Math.abs(target - pageScroller.getScrollX()) > dp(3)) {
                pageScroller.smoothScrollTo(target, 0);
            }
        }
    };

    private void resetVideoZoom() {
        if (videoViewport != null) videoViewport.resetZoom();
        if (statusText != null) {
            statusText.setText("Video zoom reset to 1×. Pinch with two fingers on the fixed video to zoom again.");
        }
    }

    /**
     * Rebuilds the local session and event lists from SQLite.
     * It is safe to call before the views exist and is intentionally bounded
     * to recent rows so frequent progress refreshes do not build an unbounded UI.
     */
    private void refreshHistory() {
        if (historyDb == null || historyRows == null || eventRows == null) return;

        String query = historySearch == null
                ? ""
                : historySearch.getText().toString().trim().toLowerCase(Locale.US);

        historyRows.removeAllViews();
        List<LocalHistoryDb.SessionSummary> sessions = historyDb.getRecentSessions(50);
        int shownSessions = 0;
        for (LocalHistoryDb.SessionSummary session : sessions) {
            String searchable = (session.id + " " + session.name + " " + session.status + " "
                    + session.note).toLowerCase(Locale.US);
            if (!query.isEmpty() && !searchable.contains(query)) continue;

            String created = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                    .format(new Date(session.createdAt));
            String text = String.format(Locale.US,
                    "#%d • %s • %s\nCreated: %s • Frames: %d/%d • Heuristic confidence: %.0f%%\n%s",
                    session.id, session.name, session.status, created, session.processed,
                    session.total, session.confidence, session.note == null ? "" : session.note);
            TextView item = label(text);
            item.setTextSize(12);
            item.setTextColor(0xFF202124);
            item.setBackgroundColor((shownSessions % 2 == 0) ? 0xFFF5F7FA : Color.WHITE);
            item.setPadding(dp(8), dp(7), dp(8), dp(7));
            item.setClickable(true);
            item.setFocusable(true);
            item.setOnClickListener(v -> {
                if (analysisRunning) {
                    toast("Stop the current analysis before switching to a saved session.");
                    return;
                }
                String savedUri = historyDb.getSessionUri(session.id);
                if (savedUri == null || savedUri.trim().isEmpty()) {
                    toast("The video URI is missing from this saved session.");
                    return;
                }
                Uri uri = Uri.parse(savedUri);
                if (selectedUri == null || !selectedUri.toString().equals(savedUri)) {
                    playVideo(uri);
                }
                activeSessionId = session.id;
                if (player != null) player.pause();
                statusText.setText("Reviewing saved session #" + session.id
                        + ". Tap one of its event rows below to seek to that event timestamp.");
                refreshHistory();
            });
            historyRows.addView(item, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            shownSessions++;
        }
        if (shownSessions == 0) {
            historyRows.addView(label(query.isEmpty()
                    ? "No saved analysis sessions yet. Select a video and run frame analysis."
                    : "No saved sessions match this search."));
        }
        if (historyHeading != null) {
            historyHeading.setText("Saved analysis history (local database) • "
                    + shownSessions + " shown");
        }

        eventRows.removeAllViews();
        List<LocalHistoryDb.EventSummary> events = historyDb.getRecentEvents(100);
        int shownEvents = 0;
        for (LocalHistoryDb.EventSummary event : events) {
            String searchable = (event.sessionId + " " + event.sourceName + " " + event.type + " "
                    + event.trackId + " " + event.status + " " + event.details)
                    .toLowerCase(Locale.US);
            if (!query.isEmpty() && !searchable.contains(query)) continue;

            String detail = event.details == null ? "" : event.details.trim();
            if (detail.length() > 220) detail = detail.substring(0, 217) + "...";
            String text = String.format(Locale.US,
                    "#%d • %s • %s\nSession: %d • Video: %s\nTimestamp: %s • Heuristic confidence: %.0f%%\n%s",
                    event.id, event.type, event.status, event.sessionId, event.sourceName,
                    formatMs(event.timestampMs), event.confidence, detail);
            TextView item = label(text);
            item.setTextSize(12);
            item.setTextColor(0xFF30343B);
            item.setBackgroundColor((shownEvents % 2 == 0) ? 0xFFF8F9FA : Color.WHITE);
            item.setPadding(dp(8), dp(7), dp(8), dp(7));
            item.setClickable(true);
            item.setFocusable(true);
            item.setOnClickListener(v -> reviewEvent(event));
            eventRows.addView(item, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            shownEvents++;
        }
        if (shownEvents == 0) {
            eventRows.addView(label(query.isEmpty()
                    ? "No candidate events saved yet."
                    : "No candidate events match this search."));
        }
    }

    private LinearLayout row(LinearLayout parent){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER);r.setPadding(0,dp(2),0,dp(2));parent.addView(r,new LinearLayout.LayoutParams(-1,-2));return r;}
    private void addButton(LinearLayout row,String text,Runnable action){Button b=new Button(this);b.setText(text);b.setTextSize(10);b.setAllCaps(false);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(45),1f);lp.setMargins(dp(2),0,dp(2),0);row.addView(b,lp);b.setOnClickListener(v->action.run());}
    private TextView label(String value){TextView t=new TextView(this);t.setText(value);t.setTextColor(0xFF5F6368);t.setTextSize(13);t.setPadding(dp(8),dp(4),dp(8),dp(4));return t;}
    private EditText numberInput(String value,boolean decimal){EditText e=new EditText(this);e.setSingleLine(true);e.setText(value);e.setTextSize(14);e.setGravity(Gravity.CENTER);e.setInputType(decimal?(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED):(InputType.TYPE_CLASS_NUMBER));return e;}
    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}

    private void openVideoPicker(){
        Intent intent;if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.TIRAMISU){intent=new Intent(MediaStore.ACTION_PICK_IMAGES);intent.setType("video/*");}
        else{intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("video/*");intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);}
        try{startActivityForResult(intent,REQUEST_VIDEO);}catch(Exception e){Toast.makeText(this,"Video picker unavailable.",Toast.LENGTH_LONG).show();}
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQUEST_EXPORT){if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)writeExport(data.getData());return;}
        if(requestCode!=REQUEST_VIDEO||resultCode!=RESULT_OK||data==null)return;
        Uri uri=data.getData();if(uri==null){statusText.setText("No video selected.");return;}
        try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
        playVideo(uri);
    }

    private void playVideo(Uri uri){
        if(analysisRunning){Toast.makeText(this,"Stop the current analysis before switching video.",Toast.LENGTH_LONG).show();return;}
        releasePlayer();selectedUri=uri;videoViewport.setSelectionMode(false);videoViewport.resetZoom();frameOverlay.cancelSelection();frameOverlay.clearBoxes();lastOverlayTimestamp=-1;
        player=new ExoPlayer.Builder(this).build();
        player.addListener(new androidx.media3.common.Player.Listener(){
            @Override public void onVideoSizeChanged(VideoSize v){if(v.width>0&&v.height>0){sourceWidth=v.width;sourceHeight=v.height;frameOverlay.setSourceSize(sourceWidth,sourceHeight);}}
            @Override public void onPlayerError(PlaybackException e){statusText.setText("Could not open video; it may have moved, been deleted or access expired. Select it again.");Toast.makeText(MainActivity.this,"Video access failed.",Toast.LENGTH_LONG).show();}
        });
        playerView.setPlayer(player);player.setMediaItem(MediaItem.fromUri(uri));player.prepare();player.pause();
        activeSessionId=historyDb.findLatestSessionForUri(uri.toString());
        currentWorkArea=loadWorkArea(uri);frameOverlay.clearWorkArea();if(currentWorkArea!=null)frameOverlay.setWorkArea(currentWorkArea[0],currentWorkArea[1],currentWorkArea[2],currentWorkArea[3]);
        currentMasterBox=loadMasterBox(uri);masterLocked=currentMasterBox!=null;
        if(masterLocked)frameOverlay.setMasterBox(currentMasterBox[0],currentMasterBox[1],currentMasterBox[2],currentMasterBox[3],loadInitialCount(uri));else frameOverlay.clearMasterBox();
        int initial=loadInitialCount(uri);double thickness=loadThickness(uri);
        initialCountInput.setText(String.valueOf(initial));thicknessInput.setText(String.format(Locale.US,"%.3f",thickness));
        ledger=StackLedger.fromJson(preferences.getString(ledgerKey(uri),null),initial);
        masterLockTimestampMs=preferences.getLong(lockTimeKey(uri),0L);
        tablePixelsPerMm=loadScale(uri,false);sidePixelsPerMm=loadScale(uri,true);frameOverlay.setSideScalePixelsPerMm(sidePixelsPerMm);
        updateAreaUi();updateMasterUi();updateLedgerUi();updateCalibrationUi();updateModelUi();
        statusText.setText("Video loaded and paused. Mark the movement area, pause on the intact original stack, and lock MASTER-001.");
    }

    private void beginWorkAreaSelection(){if(selectedUri==null){toast("Select a recorded video first.");return;}if(analysisRunning){toast("Stop analysis before changing the work area.");return;}if(player!=null)player.pause();videoViewport.setSelectionMode(true);frameOverlay.setSelectionMode(true);statusText.setText("Drag a rectangle covering the full region where descendants may move. Exclude the clock/decorations and unrelated bright objects.");toast("Drag the work-area rectangle on the video.");}
    private void resetWorkArea(){if(analysisRunning){toast("Stop analysis first.");return;}videoViewport.setSelectionMode(false);frameOverlay.cancelSelection();if(selectedUri!=null)preferences.edit().remove(workAreaKey(selectedUri)).apply();currentWorkArea=null;frameOverlay.clearWorkArea();updateAreaUi();statusText.setText("Work area cleared. Mark it again before analysis.");}
    private void beginMasterSelection(){
        if(selectedUri==null){toast("Select a recorded video first.");return;}if(analysisRunning){toast("Stop analysis before changing the master lock.");return;}
        int count=parseInt(initialCountInput.getText().toString(),-1);double thickness=parseDouble(thicknessInput.getText().toString(),Double.NaN);
        if(count<=0||count>100000||!Double.isFinite(thickness)||thickness<=0||thickness>1000){toast("Enter valid initial count and thickness first.");return;}
        if(player!=null){player.pause();pendingMasterLockTimestampMs=player.getCurrentPosition();}else pendingMasterLockTimestampMs=0;
        frameOverlay.setMasterCount(count);videoViewport.setSelectionMode(true);frameOverlay.setMasterSelectionMode(true);
        statusText.setText("LOCK STEP: pause on the intact original stack before it splits, then drag one rectangle around that entire stack. Start analysis uses this timestamp.");toast("Drag around the entire original stack to lock MASTER-001.");
    }
    private void resetMaster(){
        if(analysisRunning){toast("Stop analysis before resetting the master.");return;}
        new AlertDialog.Builder(this).setTitle("Reset MASTER-001?").setMessage("This clears the saved master lock and ledger for this video. Already saved video-history records remain in the database.")
                .setNegativeButton("Cancel",(d,w)->{}).setPositiveButton("Reset",(d,w)->{
                    videoViewport.setSelectionMode(false);frameOverlay.cancelSelection();if(selectedUri!=null)preferences.edit().remove(masterBoxKey(selectedUri)).remove(masterLockedKey(selectedUri)).remove(lockTimeKey(selectedUri)).remove(ledgerKey(selectedUri)).apply();
                    currentMasterBox=null;masterLocked=false;masterLockTimestampMs=0;frameOverlay.clearMasterBox();ledger=new StackLedger(parseInt(initialCountInput.getText().toString(),416));saveLedger();updateMasterUi();updateLedgerUi();updateModelUi();statusText.setText("Master lock reset. Mark the initial full stack again before analysis.");
                }).show();
    }

    private void beginCalibration(boolean side){if(selectedUri==null){toast("Select a video first.");return;}if(analysisRunning){toast("Stop analysis before calibration.");return;}if(player!=null)player.pause();videoViewport.setSelectionMode(true);frameOverlay.setCalibrationSelectionMode(side);statusText.setText(side?"Draw a line along a known vertical/side dimension of the stack for local side-scale calibration.":"Draw a line along a known physical length on the table plane.");toast("Drag the calibration line along a dimension whose real length you know.");}
    private void promptCalibration(boolean side,float x1,float y1,float x2,float y2){
        EditText length=numberInput("100",true);new AlertDialog.Builder(this).setTitle(side?"Known stack-side length (mm)":"Known table-plane length (mm)").setMessage("Enter the real length in millimetres of the line you just marked. This scale is local to that plane/view; it does not by itself solve 3D pose.").setView(length)
                .setNegativeButton("Cancel",(d,w)->{}).setPositiveButton("Save calibration",(d,w)->{
                    double mm=parseDouble(length.getText().toString(),Double.NaN);double px=Math.hypot((x2-x1)*sourceWidth,(y2-y1)*sourceHeight);
                    if(!Double.isFinite(mm)||mm<=0||px<3){toast("Invalid calibration line or length.");return;}double pxmm=px/mm;
                    if(side)sidePixelsPerMm=pxmm;else tablePixelsPerMm=pxmm;
                    if(selectedUri!=null)preferences.edit().putString(scaleKey(selectedUri,side),Double.toString(pxmm)).apply();frameOverlay.setSideScalePixelsPerMm(sidePixelsPerMm);updateCalibrationUi();
                    statusText.setText(String.format(Locale.US,"Saved %s scale: %.3f pixels/mm. Recalibrate after zoom/crop/camera angle changes.",side?"stack-side":"table-plane",pxmm));
                }).show();
    }

    private void startAnalysis(){
        if(selectedUri==null){toast("Select a recorded video first.");return;}
        if(currentWorkArea==null||!frameOverlay.hasWorkArea()){toast("First mark the work area where the stack parts can move.");return;}
        if(!masterLocked||currentMasterBox==null||!frameOverlay.hasMasterBox()){toast("First lock the intact original stack as MASTER-001.");return;}
        if(currentMasterBox[0]<currentWorkArea[0]||currentMasterBox[1]<currentWorkArea[1]||currentMasterBox[2]>currentWorkArea[2]||currentMasterBox[3]>currentWorkArea[3]){toast("The initial stack lock must be fully inside the marked work area. Reset and mark the work area wider if needed.");return;}
        if(!openCvReady){toast("OpenCV did not initialize. Check the build diagnostics artifact.");return;}
        if(analysisRunning){toast("Analysis is already running.");return;}
        int initial=parseInt(initialCountInput.getText().toString(),416);double thickness=parseDouble(thicknessInput.getText().toString(),0.33);
        if(initial<=0||!Double.isFinite(thickness)||thickness<=0){toast("Invalid initial piece count/thickness.");return;}
        if(ledger.getInitialCount()!=initial){ledger.reset(initial);saveLedger();updateLedgerUi();}
        saveMaster(selectedUri,currentMasterBox,initial,thickness,masterLockTimestampMs);
        stopAnalysis.set(false);String name=displayName(selectedUri);long sessionId=historyDb.createSession(selectedUri.toString(),name);activeSessionId=sessionId;analysisRunning=true;if(player!=null)player.pause();
        flushPendingEvents(sessionId);
        historyDb.saveEvent(sessionId,masterLockTimestampMs,"MASTER_LOCKED","MASTER-001",100,"CONFIRMED","Initial stack lock rectangle stored. Initial pieces="+initial+", nominal thickness="+thickness+" mm. Master ID is a lineage root, not a count detected by vision.");
        historyDb.saveEvent(sessionId,masterLockTimestampMs,"LEDGER_INITIALIZED","MASTER-001",100,"CONFIRMED",ledger.summary());
        statusText.setText("Analysis started from the locked master timestamp. Candidate detections are linked to MASTER-001 lineage; split/count changes remain pending/manual.");progressText.setText("Analysis: preparing decoder…");refreshHistory();
        final Uri uri=selectedUri;final float[] roi=currentWorkArea.clone(),master=currentMasterBox.clone();final int initialCount=initial;final long startMs=masterLockTimestampMs;
        analysisThread=new Thread(()->runAnalysis(sessionId,uri,roi,master,startMs,initialCount),"MJ-phase9-analysis");analysisThread.start();
    }

    private void runAnalysis(long sessionId,Uri uri,float[] workArea,float[] masterBox,long startTimestampMs,int initialCount){
        MediaMetadataRetriever retriever=new MediaMetadataRetriever();int processed=0,total=0,width=0,height=0;long durationMs=0;double confidenceSum=0;String finalStatus="COMPLETED";
        String note="Integrated candidate: ROI contour proposals, master-lineage visual IDs, local ledger; automatic exact count and true 3D pose are not verified.";
        TrackManager manager=new TrackManager(true);
        try{
            retriever.setDataSource(getApplicationContext(),uri);
            durationMs=parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION),0);
            width=(int)parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH),0);height=(int)parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT),0);
            int reported=(int)parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT),0);
            int fps=Math.max(1,(int)Math.round(parseDouble(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE),30.0)));
            boolean indexed=Build.VERSION.SDK_INT>=Build.VERSION_CODES.P&&reported>0;
            int sourceTotal=indexed?reported:(int)Math.min(120000,Math.max(1,(durationMs*fps)/1000L));
            long startMs=Math.max(0,Math.min(startTimestampMs,durationMs));
            int startSourceIndex=indexed&&durationMs>0&&sourceTotal>1?(int)Math.max(0,Math.min(sourceTotal-1,Math.round(startMs/(double)durationMs*(sourceTotal-1)))):(int)Math.max(0,Math.min(sourceTotal-1,Math.round(startMs*fps/1000.0)));
            total=Math.max(1,sourceTotal-startSourceIndex);
            historyDb.updateMetadata(sessionId,Math.max(0,durationMs-startMs),width,height,total,"RUNNING");
            final int ww=width,hh=height;mainHandler.post(()->{sourceWidth=ww>0?ww:16;sourceHeight=hh>0?hh:9;frameOverlay.setSourceSize(sourceWidth,sourceHeight);updateCalibrationUi();});
            boolean masterSeeded=false;
            for(int frameIndex=0;frameIndex<total;frameIndex++){
                if(stopAnalysis.get()||Thread.currentThread().isInterrupted()){finalStatus="STOPPED";break;}
                long sourceIndex=startSourceIndex+frameIndex;long timestampMs;Bitmap frame=null;
                try{
                    if(indexed){frame=retriever.getFrameAtIndex((int)sourceIndex);timestampMs=durationMs>0&&sourceTotal>1?Math.round((sourceIndex/(double)(sourceTotal-1))*durationMs):Math.round(sourceIndex*1000.0/fps);}
                    else{timestampMs=Math.min(durationMs,startMs+Math.round(frameIndex*1000.0/fps));frame=retriever.getFrameAtTime(timestampMs*1000L,MediaMetadataRetriever.OPTION_CLOSEST);}
                }catch(Exception e){frame=null;timestampMs=durationMs>0&&sourceTotal>1?Math.round((sourceIndex/(double)(sourceTotal-1))*durationMs):Math.round(sourceIndex*1000.0/fps);}
                if(frame!=null&&frameIndex==0){final int fw=frame.getWidth(),fh=frame.getHeight();mainHandler.post(()->{sourceWidth=fw;sourceHeight=fh;frameOverlay.setSourceSize(fw,fh);});}
                List<DetectionCandidate> candidates;
                boolean manualSeedFrame=false;
                if(frame!=null&&!masterSeeded){
                    // The user's locked rectangle is the actual seed. Do not depend on the
                    // weak contour detector rediscovering the same pixels; after this first
                    // seed frame, normal detections may move anywhere inside the work area.
                    candidates=new ArrayList<>();
                    candidates.add(new DetectionCandidate(masterBox[0],masterBox[1],masterBox[2],masterBox[3],100f));
                    masterSeeded=true;
                    manualSeedFrame=true;
                }else{
                    candidates=frame==null?new ArrayList<>():frameDetector.detect(frame,workArea);
                }
                if(frame!=null&&!frame.isRecycled())frame.recycle();
                TrackManager.Update update=manager.update(candidates);JSONArray json=toJson(update.visible);
                String frameStatus=frame==null?"FRAME_DECODE_FAILED":(candidates.isEmpty()?"NO_TARGET_CANDIDATE":(manualSeedFrame?"MANUAL_MASTER_SEED":"CANDIDATES_FOUND"));
                historyDb.saveFrame(sessionId,frameIndex,timestampMs,update.visible.size(),update.frameConfidence,frameStatus,json);confidenceSum+=update.frameConfidence;
                for(TrackManager.Event event:update.events)historyDb.saveEvent(sessionId,timestampMs,event.type,event.trackId,event.confidence,"PENDING_REVIEW",event.details);
                processed=frameIndex+1;
                if(processed%5==0||processed==total){double avg=confidenceSum/processed;String state=finalStatus.equals("STOPPED")?"STOPPED":"RUNNING";historyDb.updateProgress(sessionId,processed,total,avg,state,note);final int p=processed,t=total;final double conf=avg;mainHandler.post(()->{progressText.setText(String.format(Locale.US,"Analysis: %d / %d frames • heuristic tracking confidence %.0f%%",p,t,conf));if(p%25==0||p==t)refreshHistory();});}
            }
            if(!masterSeeded&&processed>0){note+=" The decoder did not return any frame for the locked start region; no initial visual seed could be created.";historyDb.saveEvent(sessionId,startMs,"MASTER_SEED_FRAME_UNAVAILABLE","MASTER-001",0,"PENDING_REVIEW","The selected source frame could not be decoded. Reselect the source or try a supported video file.");}
            if(stopAnalysis.get()&&processed<total)finalStatus="STOPPED";
        }catch(Exception e){finalStatus="ERROR";note="Analysis error: "+e.getClass().getSimpleName()+" — "+String.valueOf(e.getMessage());}
        finally{
            try{retriever.release();}catch(Exception ignored){}
            double avg=processed>0?confidenceSum/processed:0;historyDb.updateProgress(sessionId,processed,total,avg,finalStatus,note);
            final int p=processed,t=total;final String fs=finalStatus,fn=note;final double conf=avg;
            mainHandler.post(()->{analysisRunning=false;statusText.setText(fs.equals("COMPLETED")?"Analysis complete. Scrub the source video to review timestamp-matched boxes/events.":fs.equals("STOPPED")?"Analysis stopped. Already saved frames/history remain available.":"Analysis failed: "+fn);progressText.setText(String.format(Locale.US,"Analysis: %d / %d processed frames • heuristic confidence %.0f%% • %s",p,t,conf,fs));refreshHistory();});
        }
    }

    private JSONArray toJson(List<TrackManager.TrackedBox> boxes){JSONArray arr=new JSONArray();for(TrackManager.TrackedBox b:boxes){try{JSONObject o=new JSONObject();o.put("id",b.id);o.put("parentId",masterLocked?"MASTER-001":"");o.put("left",b.left);o.put("top",b.top);o.put("right",b.right);o.put("bottom",b.bottom);o.put("confidence",b.confidence);o.put("matched",b.matchedFromPrevious);arr.put(o);}catch(Exception ignored){}}return arr;}

    private void updateOverlayForPlaybackPosition(){
        if(player==null||activeSessionId<=0||selectedUri==null)return;
        LocalHistoryDb.Observation obs=historyDb.getObservationAtOrBefore(activeSessionId,player.getCurrentPosition());
        if(obs==null){if(lastOverlayTimestamp!=-1){lastOverlayTimestamp=-1;frameOverlay.clearBoxes();}return;}
        if(obs.timestampMs==lastOverlayTimestamp)return;
        lastOverlayTimestamp=obs.timestampMs;List<TrackManager.TrackedBox> boxes=new ArrayList<>();
        try{JSONArray arr=new JSONArray(obs.json);for(int i=0;i<arr.length();i++){JSONObject o=arr.getJSONObject(i);boxes.add(new TrackManager.TrackedBox(o.optString("id","M01-P?"),(float)o.optDouble("left",0),(float)o.optDouble("top",0),(float)o.optDouble("right",0),(float)o.optDouble("bottom",0),(float)o.optDouble("confidence",0),o.optBoolean("matched",false)));}}catch(Exception ignored){boxes.clear();}
        frameOverlay.setBoxes(boxes,obs.timestampMs);
    }

    private void registerSplit(){if(!ensureMaster())return;EditText parent=numberInput(String.valueOf(Math.max(1,ledger.getVisibleCount())),false);EditText childCounts=new EditText(this);childCounts.setSingleLine(true);childCounts.setTextSize(14);childCounts.setHint("Known child counts e.g. 200,216; blank = unknown");LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.addView(label("Piece count in the parent stack"));box.addView(parent);box.addView(label("Child piece counts (must sum to parent count). Leave blank only if unknown."));box.addView(childCounts);
        new AlertDialog.Builder(this).setTitle("Register split — MASTER-001 lineage").setView(box).setNegativeButton("Cancel",(d,w)->{}).setPositiveButton("Save split",(d,w)->{int p=parseInt(parent.getText().toString(),-1);String raw=childCounts.getText().toString().trim();int[] vals=null;boolean known=!raw.isEmpty();if(known){vals=parseCounts(raw);if(vals==null){toast("Child counts must be comma-separated non-negative integers.");return;}}if(!ledger.registerSplit(p,vals)){toast("Split rejected: child counts must sum exactly to parent count, and the count must exist in visible/unassigned inventory.");return;}saveLedger();String details=known?"Parent count="+p+"; child counts="+raw+"; total conserved.":"Parent count="+p+"; child counts unknown; moved to UNASSIGNED pending allocation.";logManualEvent(known?"SPLIT_CONFIRMED":"SPLIT_PENDING_ALLOCATION","MASTER-001",details,known?"CONFIRMED":"PENDING_REVIEW");updateLedgerUi();refreshHistory();}).show();}

    private void registerMerge(){if(!ensureMaster())return;EditText ids=new EditText(this);ids.setSingleLine(true);ids.setTextSize(14);ids.setHint("M01-P01,M01-P02");EditText total=new EditText(this);total.setSingleLine(true);total.setTextSize(14);total.setInputType(InputType.TYPE_CLASS_NUMBER);total.setHint("Merged piece count (if known)");LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.addView(label("IDs of components being merged"));box.addView(ids);box.addView(label("Merged count; optional but verify against component counts"));box.addView(total);new AlertDialog.Builder(this).setTitle("Register merge").setView(box).setNegativeButton("Cancel",(d,w)->{}).setPositiveButton("Record",(d,w)->{String details="Components="+ids.getText().toString().trim()+"; merged count="+(total.getText().toString().trim().isEmpty()?"UNKNOWN":total.getText().toString().trim())+"; ledger unchanged pending validation.";logManualEvent("MERGE_PENDING_REVIEW","MASTER-001",details,"PENDING_REVIEW");toast("Merge event saved as pending; total inventory was not changed.");refreshHistory();}).show();}

    private void changeVisibleBucket(String type){if(!ensureMaster())return;promptCount("Piece count to mark "+type.toLowerCase(Locale.US).replace('_',' '),Math.max(1,ledger.getVisibleCount()),count->{boolean ok=type.equals("OCCLUDED")?ledger.markOccluded(count):ledger.markOutOfView(count);if(!ok){toast("Count exceeds the visible assigned inventory.");return;}saveLedger();logManualEvent(type.equals("OCCLUDED")?"OCCLUDED_CONFIRMED":"OUT_OF_VIEW_CONFIRMED","MASTER-001","Count="+count+"; moved from visible to "+type+".","CONFIRMED");updateLedgerUi();refreshHistory();});}
    private void confirmRemoved(){if(!ensureMaster())return;promptCount("Confirm how many pieces were physically removed",1,count->{if(!ledger.confirmRemoved(count)){toast("Removal count exceeds visible inventory. Confirm the quantity first.");return;}saveLedger();logManualEvent("REMOVAL_CONFIRMED","MASTER-001","Pieces removed="+count,"CONFIRMED");updateLedgerUi();refreshHistory();});}
    private void addPieces(){if(!ensureMaster())return;promptCount("How many new pieces were added?",1,count->{if(!ledger.addPieces(count)){toast("Invalid addition count.");return;}saveLedger();logManualEvent("ADDITION_CONFIRMED","MASTER-001","Pieces added="+count,"CONFIRMED");updateLedgerUi();updateModelUi();refreshHistory();});}
    private void returnToView(){if(!ensureMaster())return;new AlertDialog.Builder(this).setTitle("Return pieces to visible").setMessage("Choose the previous state for the returning pieces.").setNegativeButton("Cancel",(d,w)->{}).setPositiveButton("From occluded",(d,w)->promptCount("Count returning from occlusion",Math.max(1,ledger.getOccludedCount()),c->{if(!ledger.returnFromOcclusion(c)){toast("Not enough pieces recorded as occluded.");return;}saveLedger();logManualEvent("RETURNED_FROM_OCCLUSION","MASTER-001","Count="+c,"CONFIRMED");updateLedgerUi();refreshHistory();})).setNeutralButton("From out-of-view",(d,w)->promptCount("Count returning from out-of-view",Math.max(1,ledger.getOutOfViewCount()),c->{if(!ledger.returnFromOutOfView(c)){toast("Not enough pieces recorded out-of-view.");return;}saveLedger();logManualEvent("RETURNED_FROM_OUT_OF_VIEW","MASTER-001","Count="+c,"CONFIRMED");updateLedgerUi();refreshHistory();})).show();}
    private void allocateUnknown(){if(!ensureMaster())return;int unknown=ledger.getUnassignedCount();if(unknown<=0){toast("No unassigned pieces. Use Register Split with known child counts when possible.");return;}EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Counts summing to "+unknown+", e.g. 200,216");new AlertDialog.Builder(this).setTitle("Allocate unknown child counts").setMessage("Every count must be non-negative and the sum must equal all unassigned pieces: "+unknown+".").setView(input).setNegativeButton("Cancel",(d,w)->{}).setPositiveButton("Allocate",(d,w)->{int[] values=parseCounts(input.getText().toString());if(values==null||!ledger.allocateUnassigned(values)){toast("Allocation failed: counts must sum exactly to "+unknown+".");return;}saveLedger();logManualEvent("COUNTS_ALLOCATED","MASTER-001","Allocated child counts="+input.getText().toString().trim(),"CONFIRMED");updateLedgerUi();refreshHistory();}).show();}
    private void undoLedger(){if(!ledger.undoLastLedgerChange()){toast("No ledger change to undo in the saved undo history.");return;}saveLedger();logManualEvent("LEDGER_UNDO","MASTER-001",ledger.summary(),"CONFIRMED");updateLedgerUi();refreshHistory();}
    private interface CountAction{void apply(int count);}
    private void promptCount(String title,int initial,CountAction action){EditText input=numberInput(String.valueOf(Math.max(1,initial)),false);new AlertDialog.Builder(this).setTitle(title).setView(input).setNegativeButton("Cancel",(d,w)->{}).setPositiveButton("Save",(d,w)->{int count=parseInt(input.getText().toString(),-1);if(count<=0){toast("Enter a positive whole number.");return;}action.apply(count);}).show();}
    private int[] parseCounts(String raw){try{String[] parts=raw.split(",");if(parts.length==0)return null;int[] values=new int[parts.length];for(int i=0;i<parts.length;i++){values[i]=Integer.parseInt(parts[i].trim());if(values[i]<=0)return null;}return values;}catch(Exception e){return null;}}
    private boolean ensureMaster(){if(!masterLocked||selectedUri==null){toast("Lock MASTER-001 first.");return false;}return true;}

    private void logManualEvent(String type,String trackId,String details,String status){
        long ts=player!=null?player.getCurrentPosition():masterLockTimestampMs;
        if(activeSessionId>0){historyDb.saveEvent(activeSessionId,ts,type,trackId,100,status,details);return;}
        if(selectedUri==null)return;
        String key=pendingEventsKey(selectedUri);JSONArray queued;
        try{queued=new JSONArray(preferences.getString(key,"[]"));}catch(Exception e){queued=new JSONArray();}
        try{JSONObject event=new JSONObject();event.put("timestampMs",ts);event.put("type",type);event.put("trackId",trackId);event.put("confidence",100);event.put("status",status);event.put("details",details);queued.put(event);preferences.edit().putString(key,queued.toString()).apply();}catch(Exception ignored){}
    }

    private void flushPendingEvents(long sessionId){
        if(selectedUri==null)return;String key=pendingEventsKey(selectedUri);String raw=preferences.getString(key,"[]");
        try{JSONArray queued=new JSONArray(raw);for(int i=0;i<queued.length();i++){JSONObject o=queued.optJSONObject(i);if(o==null)continue;historyDb.saveEvent(sessionId,o.optLong("timestampMs",masterLockTimestampMs),o.optString("type","MANUAL_EVENT"),o.optString("trackId","MASTER-001"),o.optDouble("confidence",100),o.optString("status","PENDING_REVIEW"),o.optString("details",""));}preferences.edit().remove(key).apply();}catch(Exception ignored){}
    }

    private void startExport(String format){if(selectedUri==null){toast("Select a video/model before exporting.");return;}exportFormat=format;Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(format.equals("csv")?"text/csv":"application/json");intent.putExtra(Intent.EXTRA_TITLE,"mj-stack-tracker-"+System.currentTimeMillis()+"."+format);try{startActivityForResult(intent,REQUEST_EXPORT);}catch(Exception e){toast("File save picker is unavailable.");}}
    private void writeExport(Uri destination){try(OutputStream out=getContentResolver().openOutputStream(destination,"wt")){if(out==null)throw new IllegalStateException("Could not open output file");String content=exportFormat.equals("csv")?buildCsvExport():buildJsonExport();out.write(content.getBytes(StandardCharsets.UTF_8));out.flush();toast("Export saved. You can open or share it from the selected folder.");}catch(Exception e){toast("Export failed: "+e.getClass().getSimpleName());}}
    private String buildJsonExport(){try{JSONObject root=new JSONObject();root.put("app","MJ Stack Tracker Phase 9.1 integrated candidate");root.put("exportedAt",System.currentTimeMillis());root.put("sourceUri",selectedUri==null?"":selectedUri.toString());root.put("masterId","MASTER-001");root.put("masterLocked",masterLocked);root.put("masterBox",floatArrayJson(currentMasterBox));root.put("workArea",floatArrayJson(currentWorkArea));root.put("initialCount",ledger.getInitialCount());root.put("pieceThicknessMm",parseDouble(thicknessInput.getText().toString(),0.33));root.put("nominalInitialHeightMm",ledger.getInitialCount()*parseDouble(thicknessInput.getText().toString(),0.33));if(Double.isFinite(tablePixelsPerMm))root.put("tablePixelsPerMm",tablePixelsPerMm);else root.put("tablePixelsPerMm",JSONObject.NULL);if(Double.isFinite(sidePixelsPerMm))root.put("sidePixelsPerMm",sidePixelsPerMm);else root.put("sidePixelsPerMm",JSONObject.NULL);root.put("ledger",new JSONObject(ledger.toJson()));root.put("currentSessionId",activeSessionId);JSONArray events=new JSONArray();if(activeSessionId>0){for(LocalHistoryDb.EventSummary e:historyDb.getRecentEvents(1000)){if(e.sessionId!=activeSessionId)continue;JSONObject o=new JSONObject();o.put("id",e.id);o.put("timestampMs",e.timestampMs);o.put("type",e.type);o.put("trackId",e.trackId);o.put("confidenceHeuristic",e.confidence);o.put("status",e.status);o.put("details",e.details);events.put(o);}}root.put("events",events);root.put("limits","Visual IDs and confidence are heuristic. Piece counts are only manual/ledger values; true measured accuracy and automatic 3D pose are not verified.");return root.toString(2);}catch(Exception e){return "{\"error\":\"export failed\"}";}}

    /**
     * Creates a CSV export with session metadata and events for the current video.
     * Values are quoted and embedded quotes are escaped so commas/newlines remain valid CSV.
     */
    private String buildCsvExport() {
        StringBuilder csv = new StringBuilder();
        appendCsvRow(csv,
                "record_type", "exported_at_epoch_ms", "source_uri", "session_id",
                "event_id", "timestamp_ms", "video_timestamp", "event_type", "track_id",
                "confidence_heuristic_pct", "status", "details", "master_id", "master_locked",
                "initial_count", "piece_thickness_mm", "nominal_initial_height_mm",
                "table_pixels_per_mm", "side_pixels_per_mm", "ledger_json");

        long exportedAt = System.currentTimeMillis();
        String source = selectedUri == null ? "" : selectedUri.toString();
        double thickness = parseDouble(
                thicknessInput == null ? "0.33" : thicknessInput.getText().toString(), 0.33);
        int initialCount = ledger == null ? 416 : ledger.getInitialCount();
        String tableScale = Double.isFinite(tablePixelsPerMm)
                ? String.format(Locale.US, "%.6f", tablePixelsPerMm) : "";
        String sideScale = Double.isFinite(sidePixelsPerMm)
                ? String.format(Locale.US, "%.6f", sidePixelsPerMm) : "";
        String ledgerJson = ledger == null ? "" : ledger.toJson();

        appendCsvRow(csv,
                "METADATA", Long.toString(exportedAt), source, Long.toString(activeSessionId),
                "", "", "", "", "", "", "INFO",
                "Session metadata and starting inventory", "MASTER-001",
                Boolean.toString(masterLocked), Integer.toString(initialCount),
                String.format(Locale.US, "%.6f", thickness),
                String.format(Locale.US, "%.6f", initialCount * thickness),
                tableScale, sideScale, ledgerJson);

        if (activeSessionId > 0 && historyDb != null) {
            for (LocalHistoryDb.EventSummary event : historyDb.getRecentEvents(10000)) {
                if (event.sessionId != activeSessionId) continue;
                appendCsvRow(csv,
                        "EVENT", Long.toString(exportedAt), source, Long.toString(event.sessionId),
                        Long.toString(event.id), Long.toString(event.timestampMs),
                        formatMs(event.timestampMs), event.type, event.trackId,
                        String.format(Locale.US, "%.1f", event.confidence), event.status,
                        event.details, "MASTER-001", "", "", "", "", "", "", "");
            }
        } else if (selectedUri != null && preferences != null) {
            // Include manual events queued before a full analysis session exists.
            String raw = preferences.getString(pendingEventsKey(selectedUri), "[]");
            try {
                JSONArray pending = new JSONArray(raw);
                for (int i = 0; i < pending.length(); i++) {
                    JSONObject event = pending.optJSONObject(i);
                    if (event == null) continue;
                    long timestamp = event.optLong("timestampMs", 0L);
                    appendCsvRow(csv,
                            "PENDING_EVENT", Long.toString(exportedAt), source, "",
                            "", Long.toString(timestamp), formatMs(timestamp),
                            event.optString("type", "MANUAL_EVENT"),
                            event.optString("trackId", "MASTER-001"),
                            String.format(Locale.US, "%.1f", event.optDouble("confidence", 100.0)),
                            event.optString("status", "PENDING_REVIEW"),
                            event.optString("details", ""), "MASTER-001", "", "", "", "", "", "", "");
                }
            } catch (Exception ignored) {
                appendCsvRow(csv, "WARNING", Long.toString(exportedAt), source, "", "", "", "",
                        "", "", "", "PENDING_EVENT_PARSE_FAILED",
                        "Pending local events could not be read as JSON.", "", "", "", "", "", "", "", "");
            }
        }
        return csv.toString();
    }

    private void appendCsvRow(StringBuilder csv, String... cells) {
        for (int i = 0; i < cells.length; i++) {
            if (i > 0) csv.append(',');
            csv.append(csvCell(cells[i]));
        }
        csv.append('\n');
    }

    private String csvCell(String value) {
        String safe = value == null ? "" : value;
        return "\"" + safe.replace("\"", "\"\"") + "\"";
    }

    private JSONArray floatArrayJson(float[] v) {
        JSONArray array = new JSONArray();
        if (v == null) return array;
        for (float value : v) {
            if (Float.isFinite(value)) {
                // Use JSONArray.put(Object), which does not declare JSONException.
                array.put((Object) Double.valueOf((double) value));
            } else {
                array.put(JSONObject.NULL);
            }
        }
        return array;
    }
    private void reviewEvent(LocalHistoryDb.EventSummary e){
        if(analysisRunning){toast("Stop analysis before opening a saved event.");return;}
        String savedUri=historyDb.getSessionUri(e.sessionId);
        if(savedUri!=null&&!savedUri.trim().isEmpty()){
            if(selectedUri==null||!selectedUri.toString().equals(savedUri))playVideo(Uri.parse(savedUri));
            activeSessionId=e.sessionId;
            if(player!=null){player.pause();player.seekTo(Math.max(0L,e.timestampMs));lastOverlayTimestamp=-1;}
        }
        new AlertDialog.Builder(this).setTitle(e.type+" • "+e.trackId).setMessage("Video seek requested: "+formatMs(e.timestampMs)+"\nStatus: "+e.status+"\nHeuristic confidence: "+Math.round(e.confidence)+"%\n\n"+e.details).setPositiveButton("CONFIRM",(d,w)->{historyDb.updateEventStatus(e.id,"CONFIRMED");refreshHistory();}).setNegativeButton("REJECT",(d,w)->{historyDb.updateEventStatus(e.id,"REJECTED");refreshHistory();}).setNeutralButton("DELETE",(d,w)->new AlertDialog.Builder(this).setMessage("Delete this event from local history?").setNegativeButton("Cancel",(d2,w2)->{}).setPositiveButton("Delete",(d2,w2)->{historyDb.deleteEvent(e.id);refreshHistory();}).show()).show();
    }

    private void clearVideo(){if(analysisRunning){toast("Stop analysis before clearing the video.");return;}videoViewport.setSelectionMode(false);videoViewport.resetZoom();frameOverlay.cancelSelection();releasePlayer();selectedUri=null;activeSessionId=-1;currentWorkArea=null;currentMasterBox=null;masterLocked=false;tablePixelsPerMm=Double.NaN;sidePixelsPerMm=Double.NaN;frameOverlay.clearBoxes();frameOverlay.cancelSelection();frameOverlay.clearWorkArea();frameOverlay.clearMasterBox();ledger=new StackLedger(416);updateAreaUi();updateMasterUi();updateLedgerUi();updateCalibrationUi();updateModelUi();statusText.setText("No video selected. Saved history and per-video settings remain on the phone.");progressText.setText("Analysis: not started");}

    private void updateAreaUi(){workAreaText.setText(currentWorkArea==null?"WORK AREA: NOT SET. Draw a rectangle around the entire movement region and exclude unrelated background objects.":areaText("Saved",currentWorkArea));}
    private String areaText(String prefix,float[] a){return String.format(Locale.US,"%s work area: x %.0f%%–%.0f%%, y %.0f%%–%.0f%%.",prefix,a[0]*100,a[2]*100,a[1]*100,a[3]*100);}
    private void updateMasterUi(){if(masterText==null)return;if(masterLocked&&currentMasterBox!=null){masterText.setText(String.format(Locale.US,"MASTER-001 LOCKED • initial %d pieces • %.3f mm/piece • start %s. Child tracks are M01-Pxx.",ledger.getInitialCount(),parseDouble(thicknessInput.getText().toString(),0.33),formatMs(masterLockTimestampMs)));masterText.setTextColor(0xFF245A35);}else{masterText.setText("MASTER-001 NOT LOCKED. Pause on the intact original stack, enter 416 (or the known count), then draw one rectangle around the full stack.");masterText.setTextColor(0xFF8A5200);}}
    private void updateLedgerUi(){if(ledgerText!=null)ledgerText.setText(ledger.summary());}
    private void updateCalibrationUi(){if(calibrationText==null||scaleText==null)return;String p=Double.isFinite(tablePixelsPerMm)?String.format(Locale.US,"table plane %.3f px/mm",tablePixelsPerMm):"table plane not calibrated";String s=Double.isFinite(sidePixelsPerMm)?String.format(Locale.US,"stack side %.3f px/mm",sidePixelsPerMm):"stack side not calibrated";calibrationText.setText("Calibration: "+p+" • "+s+". Recalibrate after zoom, crop, camera movement or orientation changes.");scaleText.setText("Measurement status: "+p+"; "+s+". Side-height labels are local projected estimates only; raised 3D geometry is not automatically solved.");if(frameOverlay!=null)frameOverlay.setSideScalePixelsPerMm(sidePixelsPerMm);}
    private void updateModelUi(){if(layerModelView!=null)layerModelView.setModel(ledger.getInitialCount(),parseDouble(thicknessInput==null?"0.33":thicknessInput.getText().toString(),0.33),manualTiltDegrees);if(tiltText!=null)tiltText.setText(String.format(Locale.US,"Model tilt: %.0f° manual schematic only; automatic 3D pose is not verified.",manualTiltDegrees));}

    private void saveWorkArea(Uri uri,float[] a){if(uri==null||a==null||a.length<4)return;preferences.edit().putString(workAreaKey(uri),String.format(Locale.US,"%.7f,%.7f,%.7f,%.7f",a[0],a[1],a[2],a[3])).apply();}
    private float[] loadWorkArea(Uri uri){return loadRect(preferences.getString(workAreaKey(uri),null));}
    private float[] loadMasterBox(Uri uri){if(!preferences.getBoolean(masterLockedKey(uri),false))return null;return loadRect(preferences.getString(masterBoxKey(uri),null));}
    private float[] loadRect(String raw){if(raw==null)return null;try{String[] p=raw.split(",");if(p.length!=4)return null;float l=Float.parseFloat(p[0]),t=Float.parseFloat(p[1]),r=Float.parseFloat(p[2]),b=Float.parseFloat(p[3]);if(!Float.isFinite(l)||!Float.isFinite(t)||!Float.isFinite(r)||!Float.isFinite(b)||l<0||t<0||r>1||b>1||r-l<0.01f||b-t<0.01f)return null;return new float[]{l,t,r,b};}catch(Exception e){return null;}}
    private void saveMaster(Uri uri,float[] box,int count,double thick,long timestamp){if(uri==null||box==null)return;preferences.edit().putString(masterBoxKey(uri),String.format(Locale.US,"%.7f,%.7f,%.7f,%.7f",box[0],box[1],box[2],box[3])).putBoolean(masterLockedKey(uri),true).putInt(initialCountKey(uri),count).putString(thicknessKey(uri),Double.toString(thick)).putLong(lockTimeKey(uri),timestamp).apply();}
    private int loadInitialCount(Uri uri){return Math.max(1,preferences.getInt(initialCountKey(uri),416));}
    private double loadThickness(Uri uri){return parseDouble(preferences.getString(thicknessKey(uri),"0.33"),0.33);}
    private double loadScale(Uri uri,boolean side){return parseDouble(preferences.getString(scaleKey(uri,side),"NaN"),Double.NaN);}
    private void saveLedger(){if(selectedUri!=null)preferences.edit().putString(ledgerKey(selectedUri),ledger.toJson()).apply();}
    private String pendingEventsKey(Uri u){return "pendingEvents:"+u.toString();}private String workAreaKey(Uri u){return "roi:"+u.toString();}private String masterBoxKey(Uri u){return "masterBox:"+u.toString();}private String masterLockedKey(Uri u){return "masterLocked:"+u.toString();}private String initialCountKey(Uri u){return "initialCount:"+u.toString();}private String thicknessKey(Uri u){return "thickness:"+u.toString();}private String ledgerKey(Uri u){return "ledger:"+u.toString();}private String lockTimeKey(Uri u){return "lockTime:"+u.toString();}private String scaleKey(Uri u,boolean side){return (side?"sidePxMm:":"planePxMm:")+u.toString();}

    private String displayName(Uri uri){String s=uri.getLastPathSegment();if(s==null||s.trim().isEmpty())s=uri.toString();if(s.length()>60)s=s.substring(s.length()-60);return s;}
    private String formatMs(long ms){long seconds=Math.max(0,ms)/1000;return String.format(Locale.US,"%02d:%02d.%03d",seconds/60,seconds%60,Math.max(0,ms)%1000);}
    private int parseInt(String s,int fallback){try{return s==null?fallback:Integer.parseInt(s.trim());}catch(Exception e){return fallback;}}
    private long parseLong(String s,long fallback){try{return s==null?fallback:Long.parseLong(s);}catch(Exception e){return fallback;}}
    private double parseDouble(String s,double fallback){try{return s==null?fallback:Double.parseDouble(s.trim());}catch(Exception e){return fallback;}}
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}

    private void stopAnalysis(){if(!analysisRunning){statusText.setText("No analysis is running.");return;}stopAnalysis.set(true);statusText.setText("Stop requested. Completed frame records remain saved.");}
    @Override protected void onResume(){super.onResume();mainHandler.post(overlayPoller);}
    @Override protected void onPause(){mainHandler.removeCallbacks(overlayPoller);super.onPause();}
    @Override protected void onStop(){super.onStop();if(player!=null)player.pause();}
    @Override protected void onDestroy(){mainHandler.removeCallbacks(overlayPoller);if(analysisRunning)stopAnalysis.set(true);releasePlayer();super.onDestroy();}

    /**
     * Fixed, clipped video viewport. Multi-touch is intercepted here instead of by a
     * page scroll container, so pinch-zoom/pan never moves the app or loses a selection drag.
     * The video and overlay share one transformed content view, keeping drawn rectangles aligned.
     */
    private final class ZoomableVideoViewport extends android.widget.FrameLayout {
        private View zoomTarget;
        private boolean selectionMode;
        private boolean pinchActive;
        private float zoomScale = 1f;
        private float translateX = 0f;
        private float translateY = 0f;
        private float lastDistance = 0f;
        private float lastFocusX = 0f;
        private float lastFocusY = 0f;

        ZoomableVideoViewport(android.content.Context context) {
            super(context);
            setClipChildren(true);
            setClipToPadding(true);
            setBackgroundColor(Color.BLACK);
            setFocusable(false);
        }

        void setVideoContent(View content) {
            zoomTarget = content;
            content.setPivotX(0f);
            content.setPivotY(0f);
            addView(content, new android.widget.FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            applyTransform();
        }

        void setSelectionMode(boolean enabled) {
            selectionMode = enabled;
            if (enabled && pinchActive) {
                pinchActive = false;
                lastDistance = 0f;
                requestDisallowInterceptTouchEvent(false);
            }
        }

        void resetZoom() {
            zoomScale = 1f;
            translateX = 0f;
            translateY = 0f;
            lastDistance = 0f;
            applyTransform();
        }

        @Override public boolean onInterceptTouchEvent(MotionEvent event) {
            if (selectionMode) return false;
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_POINTER_DOWN && event.getPointerCount() >= 2) {
                pinchActive = true;
                requestDisallowInterceptTouchEvent(true);
                return true;
            }
            return pinchActive;
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            if (selectionMode) return false;
            if (!pinchActive) return super.onTouchEvent(event);
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_POINTER_DOWN:
                    if (event.getPointerCount() >= 2) {
                        lastDistance = pointerDistance(event);
                        lastFocusX = pointerCenterX(event);
                        lastFocusY = pointerCenterY(event);
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (event.getPointerCount() >= 2) {
                        float newDistance = pointerDistance(event);
                        float newFocusX = pointerCenterX(event);
                        float newFocusY = pointerCenterY(event);
                        if (lastDistance > 1f && newDistance > 1f) {
                            float oldScale = zoomScale;
                            float localFocusX = (lastFocusX - translateX) / oldScale;
                            float localFocusY = (lastFocusY - translateY) / oldScale;
                            float factor = newDistance / lastDistance;
                            zoomScale = Math.max(1f, Math.min(5f, zoomScale * factor));
                            if (zoomScale <= 1.001f) {
                                zoomScale = 1f;
                                translateX = 0f;
                                translateY = 0f;
                            } else {
                                translateX = newFocusX - localFocusX * zoomScale;
                                translateY = newFocusY - localFocusY * zoomScale;
                                clampTranslation();
                            }
                            applyTransform();
                        }
                        lastDistance = newDistance;
                        lastFocusX = newFocusX;
                        lastFocusY = newFocusY;
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    pinchActive = false;
                    lastDistance = 0f;
                    requestDisallowInterceptTouchEvent(false);
                    return true;
                default:
                    return true;
            }
        }

        private float pointerDistance(MotionEvent event) {
            return (float) Math.hypot(event.getX(0) - event.getX(1),
                    event.getY(0) - event.getY(1));
        }

        private float pointerCenterX(MotionEvent event) {
            return (event.getX(0) + event.getX(1)) * 0.5f;
        }

        private float pointerCenterY(MotionEvent event) {
            return (event.getY(0) + event.getY(1)) * 0.5f;
        }

        private void clampTranslation() {
            float minX = getWidth() * (1f - zoomScale);
            float minY = getHeight() * (1f - zoomScale);
            translateX = Math.max(minX, Math.min(0f, translateX));
            translateY = Math.max(minY, Math.min(0f, translateY));
        }

        private void applyTransform() {
            if (zoomTarget == null) return;
            zoomTarget.setPivotX(0f);
            zoomTarget.setPivotY(0f);
            zoomTarget.setScaleX(zoomScale);
            zoomTarget.setScaleY(zoomScale);
            zoomTarget.setTranslationX(translateX);
            zoomTarget.setTranslationY(translateY);
        }
    }

    private void releasePlayer(){if(player!=null){if(playerView!=null)playerView.setPlayer(null);player.release();player=null;}}
}
